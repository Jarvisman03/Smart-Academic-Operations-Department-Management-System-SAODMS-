const express = require('express');
const Meeting = require('../models/Meeting');
const crudFactory = require('../controllers/crudFactory');
const notificationService = require('../services/notificationService');
const asyncHandler = require('../utils/asyncHandler');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Meeting, {
  populate: 'organizer attendees room',
  searchFields: ['title', 'agenda'],
  filterFields: ['status', 'mode'],
  entity: 'Meeting',
});

router.use(authenticate);
router.get('/', requirePermission(PERMISSIONS.MEETING_MANAGE), ctrl.list);
router.get('/:id', requirePermission(PERMISSIONS.MEETING_MANAGE), ctrl.getOne);

router.post(
  '/',
  requirePermission(PERMISSIONS.MEETING_MANAGE),
  (req, res, next) => { req.body.organizer = req.user._id; next(); },
  ctrl.createOne,
);

// Notify attendees after creation is handled via a wrapper on create result.
router.post('/:id/notify', requirePermission(PERMISSIONS.MEETING_MANAGE), asyncHandler(async (req, res) => {
  const m = await Meeting.findById(req.params.id);
  if (m && m.attendees?.length) {
    await notificationService.notifyMany(m.attendees, {
      type: 'meeting', title: `Meeting: ${m.title}`, message: m.agenda, link: '/meetings', createdBy: req.user._id,
    });
  }
  res.json({ success: true, message: 'Attendees notified' });
}));

router.put('/:id', requirePermission(PERMISSIONS.MEETING_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.MEETING_MANAGE), ctrl.removeOne);

module.exports = router;
