const express = require('express');
const ctrl = require('../controllers/timetableController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', requirePermission(PERMISSIONS.TIMETABLE_VIEW), ctrl.list);
router.get('/my/weekly', ctrl.myWeekly); // any authenticated faculty member
router.get('/weekly/:sectionId', requirePermission(PERMISSIONS.TIMETABLE_VIEW), ctrl.weekly);
router.get('/faculty/:facultyId/weekly', requirePermission(PERMISSIONS.TIMETABLE_VIEW), ctrl.facultyWeekly);
router.get('/room/:roomId/weekly', requirePermission(PERMISSIONS.TIMETABLE_VIEW), ctrl.roomWeekly);
router.post('/check-conflict', requirePermission(PERMISSIONS.TIMETABLE_VIEW), ctrl.checkConflict);
router.get('/:id/substitutes', requirePermission(PERMISSIONS.TIMETABLE_VIEW), ctrl.substitutes);

router.post('/', requirePermission(PERMISSIONS.TIMETABLE_MANAGE), ctrl.create);
router.post('/generate', requirePermission(PERMISSIONS.TIMETABLE_MANAGE), ctrl.generate);
router.put('/:id', requirePermission(PERMISSIONS.TIMETABLE_MANAGE), ctrl.update);
router.post('/:id/substitution', requirePermission(PERMISSIONS.TIMETABLE_MANAGE), ctrl.applySubstitution);
router.delete('/:id', requirePermission(PERMISSIONS.TIMETABLE_MANAGE), ctrl.remove);

module.exports = router;
