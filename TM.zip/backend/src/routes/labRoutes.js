const express = require('express');
const Lab = require('../models/Lab');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Lab, {
  populate: 'room labInCharge labAssistant equipment',
  searchFields: ['name', 'specialization'],
  entity: 'Lab',
});

router.use(authenticate);
router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.removeOne);

module.exports = router;
