const express = require('express');
const Building = require('../models/Building');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Building, { searchFields: ['name', 'code'], entity: 'Building' });

router.use(authenticate);
router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.removeOne);

module.exports = router;
