const express = require('express');
const Equipment = require('../models/Equipment');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Equipment, {
  populate: 'room lab',
  searchFields: ['name', 'tag'],
  filterFields: ['category', 'status', 'room', 'lab'],
  entity: 'Equipment',
});

router.use(authenticate);
router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.removeOne);

module.exports = router;
