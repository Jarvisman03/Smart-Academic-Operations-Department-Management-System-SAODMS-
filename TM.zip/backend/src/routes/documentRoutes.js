const express = require('express');
const Document = require('../models/Document');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const { upload, fileUrl } = require('../middleware/upload');
const auditService = require('../services/auditService');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', requirePermission(PERMISSIONS.DOCUMENT_VIEW), asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {};
  if (req.query.category) filter.category = req.query.category;
  if (req.query.department) filter.department = req.query.department;
  if (req.query.search) filter.$text = { $search: req.query.search };
  const [items, total] = await Promise.all([
    Document.find(filter).populate('uploadedBy', 'name role').sort('-createdAt').skip(skip).limit(limit),
    Document.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
}));

router.post(
  '/',
  requirePermission(PERMISSIONS.DOCUMENT_MANAGE),
  upload.single('file'),
  asyncHandler(async (req, res) => {
    if (!req.file) throw new ApiError(400, 'File is required');
    const doc = await Document.create({
      name: req.body.name || req.file.originalname,
      description: req.body.description,
      category: req.body.category,
      department: req.body.department,
      subject: req.body.subject || undefined,
      visibility: req.body.visibility ? JSON.parse(req.body.visibility) : ['all'],
      tags: req.body.tags ? req.body.tags.split(',').map((t) => t.trim()) : [],
      url: fileUrl(req, req.file),
      fileType: req.file.mimetype,
      size: req.file.size,
      uploadedBy: req.user._id,
    });
    await auditService.log(req, { action: 'document.upload', entity: 'Document', entityId: doc._id });
    return created(res, { data: doc, message: 'Document uploaded' });
  })
);

router.get('/:id/download', requirePermission(PERMISSIONS.DOCUMENT_VIEW), asyncHandler(async (req, res) => {
  const doc = await Document.findByIdAndUpdate(req.params.id, { $inc: { downloads: 1 } }, { new: true });
  if (!doc) throw new ApiError(404, 'Document not found');
  return success(res, { data: { url: doc.url } });
}));

router.delete('/:id', requirePermission(PERMISSIONS.DOCUMENT_MANAGE), asyncHandler(async (req, res) => {
  await Document.findByIdAndDelete(req.params.id);
  return success(res, { message: 'Document deleted' });
}));

module.exports = router;
