const express = require('express');
const ctrl = require('../controllers/studentController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', requirePermission(PERMISSIONS.STUDENT_VIEW), ctrl.list);
router.get('/:id', requirePermission(PERMISSIONS.STUDENT_VIEW), ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.STUDENT_MANAGE), ctrl.create);
router.put('/:id', requirePermission(PERMISSIONS.STUDENT_MANAGE), ctrl.update);
router.delete('/:id', requirePermission(PERMISSIONS.STUDENT_MANAGE), ctrl.remove);

module.exports = router;
