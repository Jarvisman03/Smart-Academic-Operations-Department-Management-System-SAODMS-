const express = require('express');
const { permissionsForRole, MATRIX } = require('../config/permissions');
const constants = require('../config/constants');

const router = express.Router();

// Public meta endpoints (no auth) - useful for the frontend bootstrap.
router.get('/meta/constants', (req, res) => {
  res.json({
    success: true,
    data: {
      roles: constants.ROLES,
      roleLabels: constants.ROLE_LABELS,
      periods: constants.PERIODS,
      days: constants.DAYS,
      workingDays: constants.WORKING_DAYS,
      college: constants.COLLEGE,
      facultyStatus: constants.FACULTY_STATUS,
      roomStatus: constants.ROOM_STATUS,
      thresholds: constants.ATTENDANCE_THRESHOLDS,
    },
  });
});

router.get('/meta/permissions', (req, res) => {
  res.json({ success: true, data: { matrix: MATRIX } });
});

// Feature routers.
router.use('/auth', require('./authRoutes'));
router.use('/users', require('./userRoutes'));
router.use('/faculty', require('./facultyRoutes'));
router.use('/students', require('./studentRoutes'));
router.use('/departments', require('./departmentRoutes'));
router.use('/subjects', require('./subjectRoutes'));
router.use('/semesters', require('./semesterRoutes'));
router.use('/sections', require('./sectionRoutes'));
router.use('/buildings', require('./buildingRoutes'));
router.use('/floors', require('./floorRoutes'));
router.use('/rooms', require('./roomRoutes'));
router.use('/labs', require('./labRoutes'));
router.use('/equipment', require('./equipmentRoutes'));
router.use('/timetable', require('./timetableRoutes'));
router.use('/attendance', require('./attendanceRoutes'));
router.use('/faculty-attendance', require('./facultyAttendanceRoutes'));
router.use('/self-attendance', require('./selfAttendanceRoutes'));
router.use('/bookings', require('./bookingRoutes'));
router.use('/maintenance', require('./maintenanceRoutes'));
router.use('/assignments', require('./assignmentRoutes'));
router.use('/tasks', require('./taskRoutes'));
router.use('/meetings', require('./meetingRoutes'));
router.use('/events', require('./eventRoutes'));
router.use('/announcements', require('./announcementRoutes'));
router.use('/documents', require('./documentRoutes'));
router.use('/calendar', require('./calendarRoutes'));
router.use('/leaves', require('./leaveRoutes'));
router.use('/notifications', require('./notificationRoutes'));
router.use('/dashboard', require('./dashboardRoutes'));
router.use('/reports', require('./reportRoutes'));
router.use('/search', require('./searchRoutes'));
router.use('/ai', require('./aiRoutes'));
router.use('/chat', require('./chatRoutes'));
router.use('/settings', require('./settingsRoutes'));
router.use('/audit', require('./auditRoutes'));

module.exports = router;
