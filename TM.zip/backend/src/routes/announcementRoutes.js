const express = require('express');
const Announcement = require('../models/Announcement');
const asyncHandler = require('../utils/asyncHandler');
const { success, created } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const notificationService = require('../services/notificationService');
const auditService = require('../services/auditService');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {};
  if (req.query.department) filter.department = req.query.department;
  const [items, total] = await Promise.all([
    Announcement.find(filter).populate('author', 'name role').sort('-pinned -createdAt').skip(skip).limit(limit),
    Announcement.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
}));

router.post('/', requirePermission(PERMISSIONS.ANNOUNCEMENT_MANAGE), asyncHandler(async (req, res) => {
  const ann = await Announcement.create({ ...req.body, author: req.user._id });
  await auditService.log(req, { action: 'announcement.create', entity: 'Announcement', entityId: ann._id });

  // Map audience -> roles for notification fan-out.
  const audience = req.body.audience || ['all'];
  const roles = [];
  if (audience.includes('all') || audience.includes('faculty')) roles.push('faculty', 'hod', 'co_hod');
  if (audience.includes('all') || audience.includes('students')) roles.push('student');
  await notificationService.notifyByAudience({
    roles: roles.length ? roles : ['faculty', 'student'],
    department: req.body.department || req.user.department,
    type: 'notice', title: ann.title, message: ann.body, link: '/announcements', priority: ann.priority, createdBy: req.user._id,
  });

  return created(res, { data: ann, message: 'Announcement published' });
}));

router.put('/:id', requirePermission(PERMISSIONS.ANNOUNCEMENT_MANAGE), asyncHandler(async (req, res) => {
  const ann = await Announcement.findByIdAndUpdate(req.params.id, req.body, { new: true });
  return success(res, { data: ann, message: 'Announcement updated' });
}));

router.delete('/:id', requirePermission(PERMISSIONS.ANNOUNCEMENT_MANAGE), asyncHandler(async (req, res) => {
  await Announcement.findByIdAndDelete(req.params.id);
  return success(res, { message: 'Announcement deleted' });
}));

module.exports = router;
