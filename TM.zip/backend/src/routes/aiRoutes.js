const express = require('express');
const aiService = require('../services/aiService');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);
router.use(requirePermission(PERMISSIONS.AI_USE));

// Whether a real AI provider is wired up (for the UI badge).
router.get('/status', asyncHandler(async (req, res) => {
  return success(res, { data: aiService.status() });
}));

router.post('/chat', asyncHandler(async (req, res) => {
  const reply = await aiService.chat(req.body.message, {
    departmentId: req.body.department || req.user.department,
    role: req.user.role,
    history: req.body.history,
  });
  return success(res, { data: { reply, ...aiService.status() } });
}));

router.get('/predict/attendance', asyncHandler(async (req, res) => {
  return success(res, { data: await aiService.predictAttendance(req.query.department) });
}));

router.get('/predict/workload', asyncHandler(async (req, res) => {
  return success(res, { data: await aiService.predictWorkload(req.query.department) });
}));

router.get('/predict/rooms', asyncHandler(async (req, res) => {
  return success(res, { data: await aiService.predictRoomUtilization() });
}));

router.get('/risks', asyncHandler(async (req, res) => {
  return success(res, { data: await aiService.detectRisks(req.query.department) });
}));

module.exports = router;
