const express = require('express');
const ctrl = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

const router = express.Router();

router.post(
  '/register',
  validate({ body: { name: { required: true }, email: { required: true, type: 'email' }, password: { required: true, min: 6 }, role: { required: true } } }),
  ctrl.register
);
router.post(
  '/login',
  validate({ body: { email: { required: true, type: 'email' }, password: { required: true } } }),
  ctrl.login
);
router.post('/refresh', ctrl.refresh);
router.post('/logout', authenticate, ctrl.logout);
router.get('/me', authenticate, ctrl.me);
router.put('/profile', authenticate, ctrl.updateProfile);
router.post(
  '/change-password',
  authenticate,
  validate({ body: { currentPassword: { required: true }, newPassword: { required: true, min: 6 } } }),
  ctrl.changePassword
);

module.exports = router;
