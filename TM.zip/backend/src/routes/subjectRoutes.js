const express = require('express');
const Subject = require('../models/Subject');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Subject, {
  populate: 'department',
  searchFields: ['name', 'code'],
  filterFields: ['year', 'semester', 'type', 'department'],
  entity: 'Subject',
});

router.use(authenticate);
router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.SUBJECT_MANAGE), ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.SUBJECT_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.SUBJECT_MANAGE), ctrl.removeOne);

module.exports = router;
