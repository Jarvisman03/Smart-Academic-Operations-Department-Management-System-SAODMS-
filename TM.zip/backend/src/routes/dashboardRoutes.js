const express = require('express');
const ctrl = require('../controllers/dashboardController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

// Command center endpoints require command dashboard permission.
router.get('/overview', requirePermission(PERMISSIONS.DASHBOARD_COMMAND), ctrl.overview);
router.get('/faculty-monitor', requirePermission(PERMISSIONS.DASHBOARD_COMMAND), ctrl.facultyMonitor);
router.get('/running', requirePermission(PERMISSIONS.DASHBOARD_COMMAND), ctrl.running);
router.get('/lab-monitor', requirePermission(PERMISSIONS.DASHBOARD_COMMAND), ctrl.labMonitor);
router.get('/attendance-summary', requirePermission(PERMISSIONS.DASHBOARD_COMMAND), ctrl.attendanceSummary);

module.exports = router;
