const express = require('express');
const ctrl = require('../controllers/reportController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);
router.use(requirePermission(PERMISSIONS.REPORT_GENERATE));

router.get('/generate', ctrl.generate);
router.get('/history', ctrl.history);

module.exports = router;
