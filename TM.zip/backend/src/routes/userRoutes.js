const express = require('express');
const ctrl = require('../controllers/userController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', requirePermission(PERMISSIONS.USER_MANAGE), ctrl.list);
router.post('/', requirePermission(PERMISSIONS.USER_MANAGE), ctrl.create);
router.get('/:id', requirePermission(PERMISSIONS.USER_MANAGE), ctrl.getOne);
router.put('/:id', requirePermission(PERMISSIONS.USER_MANAGE), ctrl.update);
router.patch('/:id/active', requirePermission(PERMISSIONS.USER_MANAGE), ctrl.setActive);
router.post('/:id/reset-password', requirePermission(PERMISSIONS.USER_MANAGE), ctrl.resetPassword);
router.delete('/:id', requirePermission(PERMISSIONS.USER_MANAGE), ctrl.remove);

module.exports = router;
