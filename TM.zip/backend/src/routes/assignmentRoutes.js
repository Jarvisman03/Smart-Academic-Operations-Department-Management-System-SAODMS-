const express = require('express');
const Assignment = require('../models/Assignment');
const Faculty = require('../models/Faculty');
const crudFactory = require('../controllers/crudFactory');
const asyncHandler = require('../utils/asyncHandler');
const { success, ApiError } = require('../utils/apiResponse');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Assignment, {
  populate: 'subject section',
  searchFields: ['title'],
  filterFields: ['subject', 'section', 'year', 'faculty'],
  entity: 'Assignment',
});

router.use(authenticate);
router.get('/', requirePermission(PERMISSIONS.ASSIGNMENT_VIEW), ctrl.list);
router.get('/:id', requirePermission(PERMISSIONS.ASSIGNMENT_VIEW), ctrl.getOne);

router.post(
  '/',
  requirePermission(PERMISSIONS.ASSIGNMENT_MANAGE),
  asyncHandler(async (req, res, next) => {
    if (!req.body.faculty) {
      const fac = await Faculty.findOne({ user: req.user._id });
      if (fac) req.body.faculty = fac._id;
    }
    return next();
  }),
  ctrl.createOne
);
router.put('/:id', requirePermission(PERMISSIONS.ASSIGNMENT_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.ASSIGNMENT_MANAGE), ctrl.removeOne);

// Student submission.
router.post('/:id/submit', asyncHandler(async (req, res) => {
  const a = await Assignment.findById(req.params.id);
  if (!a) throw new ApiError(404, 'Assignment not found');
  a.submissions.push({ student: req.body.student, fileUrl: req.body.fileUrl });
  await a.save();
  return success(res, { message: 'Submitted' });
}));

module.exports = router;
