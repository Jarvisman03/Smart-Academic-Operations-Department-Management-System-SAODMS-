const express = require('express');
const Chat = require('../models/Chat');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// List my conversations.
router.get('/', asyncHandler(async (req, res) => {
  const chats = await Chat.find({ participants: req.user._id })
    .populate('participants', 'name avatar role')
    .sort('-lastMessageAt')
    .select('-messages');
  return success(res, { data: chats });
}));

// Get one conversation with messages.
router.get('/:id', asyncHandler(async (req, res) => {
  const chat = await Chat.findById(req.params.id).populate('participants', 'name avatar role').populate('messages.sender', 'name avatar');
  if (!chat) throw new ApiError(404, 'Chat not found');
  return success(res, { data: chat });
}));

// Start or fetch a direct chat with another user.
router.post('/direct', asyncHandler(async (req, res) => {
  const { userId } = req.body;
  let chat = await Chat.findOne({ type: 'direct', participants: { $all: [req.user._id, userId], $size: 2 } });
  if (!chat) chat = await Chat.create({ type: 'direct', participants: [req.user._id, userId] });
  return created(res, { data: chat });
}));

// Create a group chat.
router.post('/group', asyncHandler(async (req, res) => {
  const chat = await Chat.create({
    type: 'group', name: req.body.name, department: req.user.department,
    participants: [...new Set([req.user._id.toString(), ...(req.body.participants || [])])],
  });
  return created(res, { data: chat });
}));

module.exports = router;
