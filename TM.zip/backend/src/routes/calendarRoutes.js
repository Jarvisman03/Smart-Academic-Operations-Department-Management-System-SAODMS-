const express = require('express');
const Event = require('../models/Event');
const Meeting = require('../models/Meeting');
const Assignment = require('../models/Assignment');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// Unified calendar feed for a date range.
router.get('/', asyncHandler(async (req, res) => {
  const from = req.query.from ? new Date(req.query.from) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const to = req.query.to ? new Date(req.query.to) : new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
  const dept = req.query.department;

  const [events, meetings, assignments] = await Promise.all([
    Event.find({ startDate: { $gte: from, $lte: to }, ...(dept && { department: dept }) }),
    Meeting.find({ date: { $gte: from, $lte: to }, ...(dept && { department: dept }) }),
    Assignment.find({ dueDate: { $gte: from, $lte: to }, ...(dept && { department: dept }) }).populate('subject', 'name'),
  ]);

  const items = [
    ...events.map((e) => ({ id: e._id, type: 'event', title: e.title, date: e.startDate, category: e.category, color: 'indigo' })),
    ...meetings.map((m) => ({ id: m._id, type: 'meeting', title: m.title, date: m.date, color: 'amber' })),
    ...assignments.map((a) => ({ id: a._id, type: 'assignment', title: `${a.title} (${a.subject?.name || ''})`, date: a.dueDate, color: 'rose' })),
  ].sort((x, y) => new Date(x.date) - new Date(y.date));

  return success(res, { data: items });
}));

module.exports = router;
