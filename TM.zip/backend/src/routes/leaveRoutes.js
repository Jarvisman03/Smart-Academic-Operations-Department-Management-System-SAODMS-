const express = require('express');
const Leave = require('../models/Leave');
const Faculty = require('../models/Faculty');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const notificationService = require('../services/notificationService');
const auditService = require('../services/auditService');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.department) filter.department = req.query.department;
  if (req.query.mine === 'true') filter.applicant = req.user._id;
  const [items, total] = await Promise.all([
    Leave.find(filter).populate('applicant', 'name role').sort('-createdAt').skip(skip).limit(limit),
    Leave.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
}));

router.post('/', requirePermission(PERMISSIONS.LEAVE_APPLY), asyncHandler(async (req, res) => {
  const faculty = await Faculty.findOne({ user: req.user._id });
  const days = Math.max(1, Math.ceil((new Date(req.body.toDate) - new Date(req.body.fromDate)) / 86400000) + 1);
  const leave = await Leave.create({
    ...req.body, applicant: req.user._id, faculty: faculty?._id, department: req.user.department, days,
  });
  await auditService.log(req, { action: 'leave.apply', entity: 'Leave', entityId: leave._id });
  // Notify approvers.
  await notificationService.notifyByAudience({
    roles: ['hod', 'co_hod', 'dean'], department: req.user.department,
    type: 'faculty_leave', title: 'New leave request', message: `${req.user.name} applied for leave`, link: '/leaves', createdBy: req.user._id,
  });
  return created(res, { data: leave, message: 'Leave applied' });
}));

router.patch('/:id/status', requirePermission(PERMISSIONS.LEAVE_APPROVE), asyncHandler(async (req, res) => {
  const leave = await Leave.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status, approvedBy: req.user._id, approverRemarks: req.body.remarks },
    { new: true }
  );
  if (!leave) throw new ApiError(404, 'Leave not found');
  await auditService.log(req, { action: `leave.${req.body.status}`, entity: 'Leave', entityId: leave._id });
  await notificationService.notify({
    recipient: leave.applicant, type: 'faculty_leave',
    title: `Leave ${req.body.status}`, message: req.body.remarks || '', link: '/leaves', createdBy: req.user._id,
  });
  return success(res, { data: leave, message: `Leave ${req.body.status}` });
}));

module.exports = router;
