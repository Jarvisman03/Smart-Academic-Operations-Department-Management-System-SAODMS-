const express = require('express');
const Task = require('../models/Task');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Task, {
  populate: 'assignedBy assignedTo',
  searchFields: ['title', 'tags'],
  filterFields: ['status', 'priority'],
  entity: 'Task',
});

router.use(authenticate);
router.get('/', requirePermission(PERMISSIONS.TASK_MANAGE), ctrl.list);
router.get('/:id', requirePermission(PERMISSIONS.TASK_MANAGE), ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.TASK_MANAGE), (req, res, next) => { req.body.assignedBy = req.user._id; next(); }, ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.TASK_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.TASK_MANAGE), ctrl.removeOne);

module.exports = router;
