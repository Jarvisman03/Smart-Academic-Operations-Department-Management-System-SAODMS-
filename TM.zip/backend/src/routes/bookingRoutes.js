const express = require('express');
const ctrl = require('../controllers/bookingController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', requirePermission(PERMISSIONS.RESOURCE_VIEW), ctrl.list);
router.post('/', requirePermission(PERMISSIONS.RESOURCE_BOOK), ctrl.create);
router.patch('/:id/status', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.updateStatus);
router.delete('/:id', requirePermission(PERMISSIONS.RESOURCE_BOOK), ctrl.remove);

module.exports = router;
