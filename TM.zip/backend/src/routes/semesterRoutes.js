const express = require('express');
const Semester = require('../models/Semester');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Semester, {
  searchFields: ['name', 'academicYear'],
  filterFields: ['type', 'isCurrent', 'number'],
  entity: 'Semester',
});

router.use(authenticate);
router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.DEPARTMENT_MANAGE), ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.DEPARTMENT_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.DEPARTMENT_MANAGE), ctrl.removeOne);

module.exports = router;
