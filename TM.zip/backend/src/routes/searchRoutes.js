const express = require('express');
const User = require('../models/User');
const Faculty = require('../models/Faculty');
const Student = require('../models/Student');
const Subject = require('../models/Subject');
const Room = require('../models/Room');
const Lab = require('../models/Lab');
const Event = require('../models/Event');
const Assignment = require('../models/Assignment');
const Meeting = require('../models/Meeting');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);
router.use(requirePermission(PERMISSIONS.SEARCH));

// Global search across major entities. `type` narrows the scope.
router.get('/', asyncHandler(async (req, res) => {
  const q = (req.query.q || '').trim();
  const type = req.query.type || 'all';
  if (!q) return success(res, { data: {} });
  const rx = { $regex: q, $options: 'i' };
  const limit = 8;
  const results = {};

  const want = (t) => type === 'all' || type === t;

  if (want('faculty')) {
    const users = await User.find({ name: rx, role: { $in: ['faculty', 'hod', 'co_hod'] } }).select('_id');
    results.faculty = await Faculty.find({ user: { $in: users.map((u) => u._id) } })
      .populate('user', 'name avatar').limit(limit);
  }
  if (want('student')) {
    const users = await User.find({ name: rx, role: 'student' }).select('_id');
    results.students = await Student.find({ $or: [{ user: { $in: users.map((u) => u._id) } }, { enrollmentNo: rx }] })
      .populate('user', 'name avatar').limit(limit);
  }
  if (want('subject')) results.subjects = await Subject.find({ $or: [{ name: rx }, { code: rx }] }).limit(limit);
  if (want('room')) results.rooms = await Room.find({ roomNumber: rx, type: { $ne: 'lab' } }).limit(limit);
  if (want('lab')) results.labs = await Lab.find({ name: rx }).populate('room', 'roomNumber').limit(limit);
  if (want('event')) results.events = await Event.find({ title: rx }).limit(limit);
  if (want('assignment')) results.assignments = await Assignment.find({ title: rx }).limit(limit);
  if (want('meeting')) results.meetings = await Meeting.find({ title: rx }).limit(limit);

  return success(res, { data: results });
}));

module.exports = router;
