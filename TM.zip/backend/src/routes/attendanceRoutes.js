const express = require('express');
const ctrl = require('../controllers/attendanceController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

// Read/analytics
router.get('/', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.list);
router.get('/stats', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.stats);
router.get('/analytics', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.analytics);
router.get('/low', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.low);
router.get('/roster/:sectionId', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.roster);
router.get('/student/:studentId', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.studentHistory);
router.get('/:id', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.getOne);

// Marking
router.post('/mark', requirePermission(PERMISSIONS.ATTENDANCE_MARK), ctrl.mark);
router.post('/qr/generate', requirePermission(PERMISSIONS.ATTENDANCE_MARK), ctrl.generateQr);
router.post('/qr/scan', ctrl.scanQr); // student self-scan (any authenticated user)

// Correction & approval
router.post('/:id/correction', requirePermission(PERMISSIONS.ATTENDANCE_CORRECT), ctrl.requestCorrection);
router.put('/:id/correct', requirePermission(PERMISSIONS.ATTENDANCE_CORRECT), ctrl.correct);
router.post('/:id/approve', requirePermission(PERMISSIONS.ATTENDANCE_APPROVE), ctrl.approve);

module.exports = router;
