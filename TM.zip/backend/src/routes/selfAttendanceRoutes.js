const express = require('express');
const ctrl = require('../controllers/selfAttendanceController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

// Any authenticated user can enroll their own face and read their status.
router.post('/enroll-face', ctrl.enrollFace);
router.get('/status', ctrl.status);

// Marking one's own presence requires the self-attendance permission.
router.post('/check-in', requirePermission(PERMISSIONS.ATTENDANCE_SELF), ctrl.checkIn);

module.exports = router;
