const express = require('express');
const AuditLog = require('../models/AuditLog');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);
router.use(requirePermission(PERMISSIONS.AUDIT_VIEW));

router.get('/', asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {};
  if (req.query.action) filter.action = { $regex: req.query.action, $options: 'i' };
  if (req.query.actor) filter.actor = req.query.actor;
  const [items, total] = await Promise.all([
    AuditLog.find(filter).populate('actor', 'name role').sort('-createdAt').skip(skip).limit(limit),
    AuditLog.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
}));

module.exports = router;
