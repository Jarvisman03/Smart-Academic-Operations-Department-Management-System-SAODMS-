const express = require('express');
const Event = require('../models/Event');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Event, {
  populate: 'organizer room',
  searchFields: ['title', 'description'],
  filterFields: ['category', 'department'],
  entity: 'Event',
});

router.use(authenticate);
router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.EVENT_MANAGE), (req, res, next) => { req.body.organizer = req.user._id; next(); }, ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.EVENT_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.EVENT_MANAGE), ctrl.removeOne);

module.exports = router;
