const express = require('express');
const ctrl = require('../controllers/notificationController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', ctrl.myNotifications);
router.patch('/:id/read', ctrl.markRead);
router.patch('/read-all', ctrl.markAllRead);
router.post('/broadcast', requirePermission(PERMISSIONS.NOTIFICATION_SEND), ctrl.broadcast);

module.exports = router;
