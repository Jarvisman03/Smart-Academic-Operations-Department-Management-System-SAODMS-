const express = require('express');
const ctrl = require('../controllers/facultyAttendanceController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.list);
router.get('/today', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), ctrl.today);
router.post('/check-in', ctrl.checkIn);
router.post('/check-out', ctrl.checkOut);

module.exports = router;
