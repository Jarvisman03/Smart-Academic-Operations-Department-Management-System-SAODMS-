const express = require('express');
const Maintenance = require('../models/Maintenance');
const Room = require('../models/Room');
const crudFactory = require('../controllers/crudFactory');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Maintenance, {
  populate: 'room lab equipment reportedBy assignedTo',
  filterFields: ['status', 'priority', 'room', 'lab'],
  entity: 'Maintenance',
});

router.use(authenticate);
router.get('/', requirePermission(PERMISSIONS.RESOURCE_VIEW), ctrl.list);
router.get('/:id', requirePermission(PERMISSIONS.RESOURCE_VIEW), ctrl.getOne);

// Reporting maintenance also flips the room to maintenance status.
router.post(
  '/',
  requirePermission(PERMISSIONS.RESOURCE_VIEW),
  asyncHandler(async (req, res, next) => {
    if (req.body.room) await Room.findByIdAndUpdate(req.body.room, { status: 'maintenance' });
    return next();
  }),
  (req, res, next) => { req.body.reportedBy = req.user._id; return next(); },
  ctrl.createOne
);

router.put(
  '/:id',
  requirePermission(PERMISSIONS.RESOURCE_MANAGE),
  asyncHandler(async (req, res, next) => {
    // When resolved, free the room again.
    if (req.body.status === 'resolved' || req.body.status === 'closed') {
      const m = await Maintenance.findById(req.params.id);
      if (m && m.room) await Room.findByIdAndUpdate(m.room, { status: 'free' });
    }
    return next();
  }),
  ctrl.updateOne
);

router.delete('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.removeOne);

module.exports = router;
