const express = require('express');
const ctrl = require('../controllers/roomController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', ctrl.list);
router.get('/map/:buildingId', ctrl.buildingMap);
router.get('/map', ctrl.buildingMap);
router.get('/availability', ctrl.availability);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.create);
router.put('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.update);
router.patch('/:id/status', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.setStatus);
router.delete('/:id', requirePermission(PERMISSIONS.RESOURCE_MANAGE), ctrl.remove);

module.exports = router;
