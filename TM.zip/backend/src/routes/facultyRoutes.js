const express = require('express');
const ctrl = require('../controllers/facultyController');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

router.get('/', requirePermission(PERMISSIONS.FACULTY_VIEW), ctrl.list);
router.get('/:id', requirePermission(PERMISSIONS.FACULTY_VIEW), ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.FACULTY_MANAGE), ctrl.create);
router.put('/:id', requirePermission(PERMISSIONS.FACULTY_MANAGE), ctrl.update);
router.delete('/:id', requirePermission(PERMISSIONS.FACULTY_MANAGE), ctrl.remove);

module.exports = router;
