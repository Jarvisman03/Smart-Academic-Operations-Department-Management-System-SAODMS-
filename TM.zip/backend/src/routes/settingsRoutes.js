const express = require('express');
const Settings = require('../models/Settings');
const asyncHandler = require('../utils/asyncHandler');
const { success, ApiError } = require('../utils/apiResponse');
const auditService = require('../services/auditService');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS, hasPermission } = require('../config/permissions');

const router = express.Router();
router.use(authenticate);

// HODs manage their own department's settings; admin/dean manage global settings.
function isDeptScoped(user) {
  return user.role === 'hod' && !!user.department;
}

// Resolve the settings document that applies to this user, creating it (seeded
// from global defaults) when missing.
async function resolveSettings(user, { create } = {}) {
  if (isDeptScoped(user)) {
    let dept = await Settings.findOne({ department: user.department });
    if (!dept && create) {
      const global = (await Settings.findOne({ scope: 'global' })) || (await Settings.create({ scope: 'global' }));
      dept = await Settings.create({
        scope: 'department',
        department: user.department,
        college: global.college,
        thresholds: global.thresholds,
        attendanceRules: global.attendanceRules,
        lateThresholdMinutes: global.lateThresholdMinutes,
        features: global.features,
        workingDays: global.workingDays,
        facultyWorkingDays: global.facultyWorkingDays,
      });
    }
    if (dept) return dept;
  }
  let global = await Settings.findOne({ scope: 'global' });
  if (!global && create) global = await Settings.create({ scope: 'global' });
  return global;
}

// Read the applicable settings (page is gated by settings:manage).
router.get('/', requirePermission(PERMISSIONS.SETTINGS_MANAGE), asyncHandler(async (req, res) => {
  const settings = await resolveSettings(req.user, { create: true });
  return success(res, {
    data: settings,
    meta: {
      scope: settings.scope,
      canEditFeatures: hasPermission(req.user.role, PERMISSIONS.SETTINGS_FEATURES),
      canEditAttendance: hasPermission(req.user.role, PERMISSIONS.SETTINGS_ATTENDANCE),
    },
  });
}));

// Update, filtered by field-level permissions.
router.put('/', requirePermission(PERMISSIONS.SETTINGS_MANAGE), asyncHandler(async (req, res) => {
  const settings = await resolveSettings(req.user, { create: true });
  if (!settings) throw new ApiError(404, 'Settings not found');

  const allowed = {};
  if (hasPermission(req.user.role, PERMISSIONS.SETTINGS_ATTENDANCE)) {
    ['thresholds', 'attendanceRules', 'lateThresholdMinutes'].forEach((k) => {
      if (k in req.body) allowed[k] = req.body[k];
    });
  }
  if (hasPermission(req.user.role, PERMISSIONS.SETTINGS_FEATURES)) {
    ['college', 'features', 'workingDays', 'facultyWorkingDays', 'geofence'].forEach((k) => {
      if (k in req.body) allowed[k] = req.body[k];
    });
  }

  if (Object.keys(allowed).length === 0) throw new ApiError(403, 'You cannot edit any of the submitted settings');

  Object.assign(settings, allowed);
  await settings.save();
  await auditService.log(req, { action: 'settings.update', entity: 'Settings', entityId: settings._id, meta: { scope: settings.scope, fields: Object.keys(allowed) } });
  return success(res, { data: settings, message: 'Settings updated' });
}));

module.exports = router;
