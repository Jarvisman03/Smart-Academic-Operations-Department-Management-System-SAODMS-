const express = require('express');
const Section = require('../models/Section');
const crudFactory = require('../controllers/crudFactory');
const { authenticate, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();
const ctrl = crudFactory(Section, {
  populate: 'classTeacher homeRoom',
  searchFields: ['name', 'batch'],
  filterFields: ['year', 'semester', 'department'],
  entity: 'Section',
});

router.use(authenticate);
router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);
router.post('/', requirePermission(PERMISSIONS.SECTION_MANAGE), ctrl.createOne);
router.put('/:id', requirePermission(PERMISSIONS.SECTION_MANAGE), ctrl.updateOne);
router.delete('/:id', requirePermission(PERMISSIONS.SECTION_MANAGE), ctrl.removeOne);

module.exports = router;
