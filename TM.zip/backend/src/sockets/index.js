const { verifyAccessToken } = require('../utils/jwt');
const notificationService = require('../services/notificationService');
const Chat = require('../models/Chat');

// ============================================================
// Socket.IO namespaces:
//   /dashboard     - live faculty/room/lab/attendance/timetable events
//   /notifications - per-user notification delivery
//   /chat          - department messaging
// ============================================================
function initSockets(io) {
  // Shared JWT auth for all namespaces.
  const authMiddleware = (socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.query?.token;
      if (!token) return next(new Error('Auth token required'));
      const decoded = verifyAccessToken(token);
      socket.user = { id: decoded.sub, role: decoded.role };
      return next();
    } catch (e) {
      return next(new Error('Invalid token'));
    }
  };

  const dashboard = io.of('/dashboard');
  dashboard.use(authMiddleware);
  dashboard.on('connection', (socket) => {
    socket.join(`role:${socket.user.role}`);
    socket.emit('dashboard:connected', { message: 'Live dashboard connected' });

    // Client can subscribe to a specific building/section room for scoped events.
    socket.on('subscribe', ({ building, section }) => {
      if (building) socket.join(`building:${building}`);
      if (section) socket.join(`section:${section}`);
    });
    socket.on('unsubscribe', ({ building, section }) => {
      if (building) socket.leave(`building:${building}`);
      if (section) socket.leave(`section:${section}`);
    });
  });

  const notifications = io.of('/notifications');
  notifications.use(authMiddleware);
  notifications.on('connection', (socket) => {
    socket.join(`user:${socket.user.id}`);
  });
  // Allow the notification service to emit into this namespace.
  notificationService.setIo(io);

  const chat = io.of('/chat');
  chat.use(authMiddleware);
  chat.on('connection', (socket) => {
    socket.join(`user:${socket.user.id}`);

    socket.on('chat:join', ({ chatId }) => socket.join(`chat:${chatId}`));

    socket.on('chat:message', async ({ chatId, text, attachment }) => {
      try {
        const message = { sender: socket.user.id, text, attachment, createdAt: new Date() };
        const conv = await Chat.findByIdAndUpdate(
          chatId,
          { $push: { messages: message }, lastMessageAt: new Date() },
          { new: true }
        );
        chat.to(`chat:${chatId}`).emit('chat:message', { chatId, message });
        // Notify offline participants.
        if (conv) {
          conv.participants
            .filter((p) => p.toString() !== socket.user.id)
            .forEach((p) => notifications.to(`user:${p}`).emit('notification:new', {
              type: 'general', title: 'New message', message: text, link: '/chat',
            }));
        }
      } catch (e) {
        socket.emit('chat:error', { message: 'Failed to send message' });
      }
    });

    socket.on('chat:typing', ({ chatId }) => {
      socket.to(`chat:${chatId}`).emit('chat:typing', { chatId, userId: socket.user.id });
    });
  });

  return io;
}

module.exports = { initSockets };
