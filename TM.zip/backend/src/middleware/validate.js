const { ApiError } = require('../utils/apiResponse');

// Lightweight schema validation middleware.
// schema: { body: {field: {required, type, enum, min, max}}, query: {...}, params: {...} }
function validate(schema = {}) {
  return (req, res, next) => {
    const errors = [];

    for (const location of ['body', 'query', 'params']) {
      const rules = schema[location];
      if (!rules) continue;
      const data = req[location] || {};

      for (const [field, rule] of Object.entries(rules)) {
        const value = data[field];
        const present = value !== undefined && value !== null && value !== '';

        if (rule.required && !present) {
          errors.push({ field, message: `${field} is required` });
          continue;
        }
        if (!present) continue;

        if (rule.type === 'number' && Number.isNaN(Number(value))) {
          errors.push({ field, message: `${field} must be a number` });
        }
        if (rule.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          errors.push({ field, message: `${field} must be a valid email` });
        }
        if (rule.enum && !rule.enum.includes(value)) {
          errors.push({ field, message: `${field} must be one of: ${rule.enum.join(', ')}` });
        }
        if (rule.min !== undefined && String(value).length < rule.min) {
          errors.push({ field, message: `${field} must be at least ${rule.min} characters` });
        }
        if (rule.max !== undefined && String(value).length > rule.max) {
          errors.push({ field, message: `${field} must be at most ${rule.max} characters` });
        }
      }
    }

    if (errors.length) return next(new ApiError(422, 'Validation failed', errors));
    return next();
  };
}

module.exports = { validate };
