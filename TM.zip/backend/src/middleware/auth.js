const { verifyAccessToken } = require('../utils/jwt');
const { ApiError } = require('../utils/apiResponse');
const { hasPermission, permissionsForRole } = require('../config/permissions');
const User = require('../models/User');

// Authenticate: verify JWT from Authorization header or cookie, attach req.user.
async function authenticate(req, res, next) {
  try {
    let token;
    const header = req.headers.authorization;
    if (header && header.startsWith('Bearer ')) {
      token = header.split(' ')[1];
    } else if (req.cookies && req.cookies.accessToken) {
      token = req.cookies.accessToken;
    }
    if (!token) throw new ApiError(401, 'Authentication required');

    const decoded = verifyAccessToken(token);
    const user = await User.findById(decoded.sub).select('-password -refreshTokens');
    if (!user) throw new ApiError(401, 'User no longer exists');
    if (!user.isActive) throw new ApiError(403, 'Account is deactivated');

    req.user = user;
    req.permissions = permissionsForRole(user.role);
    return next();
  } catch (err) {
    return next(err);
  }
}

// Authorize by role list.
function authorizeRoles(...roles) {
  return (req, res, next) => {
    if (!req.user) return next(new ApiError(401, 'Authentication required'));
    if (!roles.includes(req.user.role)) {
      return next(new ApiError(403, 'You do not have permission to perform this action'));
    }
    return next();
  };
}

// Authorize by permission(s). Requires ALL listed permissions.
function requirePermission(...perms) {
  return (req, res, next) => {
    if (!req.user) return next(new ApiError(401, 'Authentication required'));
    const ok = perms.every((p) => hasPermission(req.user.role, p));
    if (!ok) return next(new ApiError(403, 'Insufficient permissions'));
    return next();
  };
}

module.exports = { authenticate, authorizeRoles, requirePermission };
