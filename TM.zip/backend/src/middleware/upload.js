const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const { cloudinary, enabled } = require('../config/cloudinary');

// Local uploads directory fallback when Cloudinary is not configured.
const uploadDir = path.join(__dirname, '..', '..', 'uploads');
if (!enabled && !fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = enabled
  ? new CloudinaryStorage({
      cloudinary,
      params: {
        folder: 'saodms',
        resource_type: 'auto',
      },
    })
  : multer.diskStorage({
      destination: (req, file, cb) => cb(null, uploadDir),
      filename: (req, file, cb) => {
        const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${unique}${path.extname(file.originalname)}`);
      },
    });

const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 }, // 15 MB
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|pdf|docx?|xlsx?|pptx?|txt|csv/;
    const ok = allowed.test(path.extname(file.originalname).toLowerCase());
    if (ok) return cb(null, true);
    return cb(new Error('Unsupported file type'));
  },
});

// Normalize file location into a URL usable by the client.
function fileUrl(req, file) {
  if (!file) return null;
  if (enabled) return file.path; // Cloudinary secure URL
  return `${req.protocol}://${req.get('host')}/uploads/${file.filename}`;
}

module.exports = { upload, fileUrl, cloudinaryEnabled: enabled };
