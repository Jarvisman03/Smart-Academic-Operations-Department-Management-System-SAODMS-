const env = require('../config/env');
const { fail } = require('../utils/apiResponse');

// 404 handler for unmatched routes.
function notFound(req, res) {
  return fail(res, { status: 404, message: `Route not found: ${req.method} ${req.originalUrl}` });
}

// Central error handler.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let status = err.status || 500;
  let message = err.message || 'Internal Server Error';
  let errors = err.errors || null;

  // Mongoose validation errors
  if (err.name === 'ValidationError') {
    status = 422;
    message = 'Validation failed';
    errors = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
  }
  // Mongoose duplicate key
  if (err.code === 11000) {
    status = 409;
    const field = Object.keys(err.keyValue || {})[0];
    message = `Duplicate value for field: ${field}`;
    errors = err.keyValue;
  }
  // Mongoose cast (bad ObjectId)
  if (err.name === 'CastError') {
    status = 400;
    message = `Invalid ${err.path}: ${err.value}`;
  }
  // JWT
  if (err.name === 'JsonWebTokenError') {
    status = 401;
    message = 'Invalid token';
  }
  if (err.name === 'TokenExpiredError') {
    status = 401;
    message = 'Token expired';
  }

  if (status >= 500) {
    // eslint-disable-next-line no-console
    console.error('[ERROR]', err);
  }

  const body = { success: false, message };
  if (errors) body.errors = errors;
  if (env.nodeEnv !== 'production' && status >= 500) body.stack = err.stack;

  return res.status(status).json(body);
}

module.exports = { notFound, errorHandler };
