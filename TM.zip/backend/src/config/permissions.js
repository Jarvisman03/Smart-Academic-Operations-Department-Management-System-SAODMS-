const { ROLES } = require('./constants');

// ============================================================
// Permission Matrix (RBAC)
// Each permission is "resource:action". "*" grants all.
// ============================================================

const P = {
  // Users & people
  USER_MANAGE: 'user:manage',
  FACULTY_MANAGE: 'faculty:manage',
  FACULTY_VIEW: 'faculty:view',
  STUDENT_MANAGE: 'student:manage',
  STUDENT_VIEW: 'student:view',

  // Academic structure
  DEPARTMENT_MANAGE: 'department:manage',
  SUBJECT_MANAGE: 'subject:manage',
  SECTION_MANAGE: 'section:manage',

  // Timetable
  TIMETABLE_MANAGE: 'timetable:manage',
  TIMETABLE_VIEW: 'timetable:view',

  // Attendance
  ATTENDANCE_MARK: 'attendance:mark',
  ATTENDANCE_VIEW: 'attendance:view',
  ATTENDANCE_APPROVE: 'attendance:approve',
  ATTENDANCE_CORRECT: 'attendance:correct',
  ATTENDANCE_SELF: 'attendance:self', // mark one's own presence via GPS+face

  // Resources
  RESOURCE_MANAGE: 'resource:manage',
  RESOURCE_VIEW: 'resource:view',
  RESOURCE_BOOK: 'resource:book',

  // Academic ops
  MEETING_MANAGE: 'meeting:manage',
  ASSIGNMENT_MANAGE: 'assignment:manage',
  ASSIGNMENT_VIEW: 'assignment:view',
  TASK_MANAGE: 'task:manage',
  EVENT_MANAGE: 'event:manage',
  ANNOUNCEMENT_MANAGE: 'announcement:manage',
  DOCUMENT_MANAGE: 'document:manage',
  DOCUMENT_VIEW: 'document:view',

  // Leaves
  LEAVE_APPLY: 'leave:apply',
  LEAVE_APPROVE: 'leave:approve',

  // Dashboard & analytics
  DASHBOARD_COMMAND: 'dashboard:command',
  ANALYTICS_VIEW: 'analytics:view',
  REPORT_GENERATE: 'report:generate',

  // System
  SETTINGS_MANAGE: 'settings:manage', // access the Settings page
  SETTINGS_FEATURES: 'settings:features', // edit feature toggles + college info (admin only)
  SETTINGS_ATTENDANCE: 'settings:attendance', // edit thresholds + per-year attendance rules
  AUDIT_VIEW: 'audit:view',
  AI_USE: 'ai:use',
  SEARCH: 'search:global',
  NOTIFICATION_SEND: 'notification:send',
};

const ALL = Object.values(P);

const MATRIX = {
  [ROLES.ADMIN]: ['*'],

  [ROLES.DEAN]: [
    P.FACULTY_VIEW, P.STUDENT_VIEW, P.DEPARTMENT_MANAGE, P.SUBJECT_MANAGE, P.SECTION_MANAGE,
    P.TIMETABLE_VIEW, P.ATTENDANCE_VIEW, P.ATTENDANCE_APPROVE,
    P.RESOURCE_VIEW, P.RESOURCE_MANAGE, P.RESOURCE_BOOK,
    P.MEETING_MANAGE, P.ASSIGNMENT_VIEW, P.EVENT_MANAGE, P.ANNOUNCEMENT_MANAGE,
    P.DOCUMENT_MANAGE, P.DOCUMENT_VIEW, P.LEAVE_APPROVE,
    P.DASHBOARD_COMMAND, P.ANALYTICS_VIEW, P.REPORT_GENERATE,
    P.AUDIT_VIEW, P.AI_USE, P.SEARCH, P.NOTIFICATION_SEND, P.SETTINGS_MANAGE, P.SETTINGS_ATTENDANCE,
  ],

  [ROLES.HOD]: [
    P.FACULTY_MANAGE, P.FACULTY_VIEW, P.STUDENT_MANAGE, P.STUDENT_VIEW,
    P.SUBJECT_MANAGE, P.SECTION_MANAGE,
    P.TIMETABLE_MANAGE, P.TIMETABLE_VIEW,
    P.ATTENDANCE_VIEW, P.ATTENDANCE_APPROVE, P.ATTENDANCE_CORRECT,
    P.RESOURCE_MANAGE, P.RESOURCE_VIEW, P.RESOURCE_BOOK,
    P.MEETING_MANAGE, P.ASSIGNMENT_MANAGE, P.ASSIGNMENT_VIEW, P.TASK_MANAGE,
    P.EVENT_MANAGE, P.ANNOUNCEMENT_MANAGE, P.DOCUMENT_MANAGE, P.DOCUMENT_VIEW,
    P.LEAVE_APPROVE, P.LEAVE_APPLY,
    P.DASHBOARD_COMMAND, P.ANALYTICS_VIEW, P.REPORT_GENERATE,
    P.AUDIT_VIEW, P.AI_USE, P.SEARCH, P.NOTIFICATION_SEND, P.SETTINGS_MANAGE, P.SETTINGS_ATTENDANCE,
  ],

  [ROLES.CO_HOD]: [
    P.FACULTY_VIEW, P.STUDENT_MANAGE, P.STUDENT_VIEW, P.SECTION_MANAGE,
    P.TIMETABLE_MANAGE, P.TIMETABLE_VIEW,
    P.ATTENDANCE_VIEW, P.ATTENDANCE_APPROVE, P.ATTENDANCE_CORRECT,
    P.RESOURCE_VIEW, P.RESOURCE_BOOK,
    P.MEETING_MANAGE, P.ASSIGNMENT_MANAGE, P.ASSIGNMENT_VIEW, P.TASK_MANAGE,
    P.EVENT_MANAGE, P.ANNOUNCEMENT_MANAGE, P.DOCUMENT_MANAGE, P.DOCUMENT_VIEW,
    P.LEAVE_APPROVE, P.LEAVE_APPLY,
    P.DASHBOARD_COMMAND, P.ANALYTICS_VIEW, P.REPORT_GENERATE,
    P.AI_USE, P.SEARCH, P.NOTIFICATION_SEND,
  ],

  [ROLES.FACULTY]: [
    P.STUDENT_VIEW, P.TIMETABLE_VIEW,
    P.ATTENDANCE_MARK, P.ATTENDANCE_VIEW, P.ATTENDANCE_CORRECT, P.ATTENDANCE_SELF,
    P.RESOURCE_VIEW, P.RESOURCE_BOOK,
    P.ASSIGNMENT_MANAGE, P.ASSIGNMENT_VIEW, P.TASK_MANAGE,
    P.DOCUMENT_MANAGE, P.DOCUMENT_VIEW,
    P.LEAVE_APPLY, P.ANALYTICS_VIEW, P.REPORT_GENERATE,
    P.AI_USE, P.SEARCH,
  ],

  [ROLES.LAB_ASSISTANT]: [
    P.TIMETABLE_VIEW, P.ATTENDANCE_VIEW, P.ATTENDANCE_SELF,
    P.RESOURCE_VIEW, P.RESOURCE_BOOK, P.RESOURCE_MANAGE,
    P.DOCUMENT_VIEW, P.LEAVE_APPLY, P.SEARCH,
  ],

  [ROLES.STUDENT]: [
    P.TIMETABLE_VIEW, P.ATTENDANCE_VIEW, P.ATTENDANCE_SELF,
    P.ASSIGNMENT_VIEW, P.DOCUMENT_VIEW,
    P.RESOURCE_VIEW, P.AI_USE, P.SEARCH,
  ],
};

function permissionsForRole(role) {
  const perms = MATRIX[role] || [];
  if (perms.includes('*')) return ALL;
  return perms;
}

function hasPermission(role, permission) {
  const perms = MATRIX[role] || [];
  return perms.includes('*') || perms.includes(permission);
}

module.exports = { PERMISSIONS: P, MATRIX, ALL, permissionsForRole, hasPermission };
