const { v2: cloudinary } = require('cloudinary');
const env = require('./env');

if (env.cloudinary.enabled) {
  cloudinary.config({
    cloud_name: env.cloudinary.cloudName,
    api_key: env.cloudinary.apiKey,
    api_secret: env.cloudinary.apiSecret,
  });
}

module.exports = { cloudinary, enabled: env.cloudinary.enabled };
