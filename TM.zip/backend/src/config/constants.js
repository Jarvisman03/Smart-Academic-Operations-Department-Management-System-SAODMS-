// ============================================================
// SAODMS Domain Constants - SIRT CSE
// ============================================================

const ROLES = Object.freeze({
  ADMIN: 'admin',
  DEAN: 'dean',
  HOD: 'hod',
  CO_HOD: 'co_hod',
  FACULTY: 'faculty',
  STUDENT: 'student',
  LAB_ASSISTANT: 'lab_assistant',
});

const ROLE_LABELS = Object.freeze({
  admin: 'Administrator',
  dean: 'Dean',
  hod: 'Head of Department',
  co_hod: 'Co-HOD',
  faculty: 'Faculty',
  student: 'Student',
  lab_assistant: 'Lab Assistant',
});

// Roles that see the Command Center dashboard fully
const COMMAND_ROLES = Object.freeze([ROLES.ADMIN, ROLES.DEAN, ROLES.HOD, ROLES.CO_HOD]);

const FACULTY_STATUS = Object.freeze({
  AVAILABLE: 'available',
  TEACHING: 'teaching',
  MEETING: 'meeting',
  ON_LEAVE: 'on_leave',
  EXAM_DUTY: 'exam_duty',
  LAB_DUTY: 'lab_duty',
});

const ROOM_STATUS = Object.freeze({
  OCCUPIED: 'occupied',
  FREE: 'free',
  RESERVED: 'reserved',
  MAINTENANCE: 'maintenance',
});

const ROOM_TYPES = Object.freeze({
  CLASSROOM: 'classroom',
  LAB: 'lab',
  SEMINAR: 'seminar',
  OFFICE: 'office',
});

const ATTENDANCE_STATUS = Object.freeze({
  PRESENT: 'present',
  ABSENT: 'absent',
  LATE: 'late',
  LEAVE: 'leave',
});

const ATTENDANCE_METHODS = Object.freeze({
  MANUAL: 'manual',
  QR: 'qr',
  GPS: 'gps',
  FACE: 'face',
});

const LEAVE_STATUS = Object.freeze({
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
});

const DAYS = Object.freeze(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']);
const WORKING_DAYS = Object.freeze(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']);
// Days shown in the timetable grid (classes can be scheduled any day, incl. weekends).
const TIMETABLE_DAYS = Object.freeze(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);

// College timing divided into lecture slots (extended into the afternoon).
const PERIODS = Object.freeze([
  { period: 1, start: '08:30', end: '09:25', label: 'Period 1' },
  { period: 2, start: '09:25', end: '10:20', label: 'Period 2' },
  { period: 3, start: '10:20', end: '11:15', label: 'Period 3' },
  { period: 0, start: '11:15', end: '11:35', label: 'Short Break', isBreak: true },
  { period: 4, start: '11:35', end: '12:30', label: 'Period 4' },
  { period: 5, start: '12:30', end: '13:25', label: 'Period 5' },
  { period: -1, start: '13:25', end: '13:55', label: 'Lunch Break', isBreak: true },
  { period: 6, start: '13:55', end: '14:50', label: 'Period 6' },
  { period: 7, start: '14:50', end: '15:45', label: 'Period 7' },
  { period: 8, start: '15:45', end: '16:40', label: 'Period 8' },
]);

const COLLEGE = Object.freeze({
  name: 'Sagar Institute of Research And Technology',
  shortName: 'SIRT',
  department: 'Computer Science & Engineering',
  departmentCode: 'CSE',
  floors: 4,
  startTime: '08:30',
  endTime: '15:00',
});

// Attendance shortage thresholds
const ATTENDANCE_THRESHOLDS = Object.freeze({
  MINIMUM: 75,
  WARNING: 65,
  CRITICAL: 50,
});

// Default per-year attendance rules (also stored/overridable in Settings collection)
const DEFAULT_YEAR_RULES = Object.freeze({
  1: { mandatory: true, countsTowardShortage: true },
  2: { mandatory: true, countsTowardShortage: true },
  3: { mandatory: true, countsTowardShortage: true },
  4: { mandatory: false, countsTowardShortage: false }, // recorded but excluded from shortage
});

const NOTIFICATION_TYPES = Object.freeze({
  CLASS_CANCELLED: 'class_cancelled',
  FACULTY_LEAVE: 'faculty_leave',
  ROOM_CHANGE: 'room_change',
  LAB_CHANGE: 'lab_change',
  MEETING: 'meeting',
  NOTICE: 'notice',
  EXAM: 'exam',
  PLACEMENT: 'placement',
  ATTENDANCE_ALERT: 'attendance_alert',
  SUBSTITUTE: 'substitute',
  GENERAL: 'general',
});

module.exports = {
  ROLES,
  ROLE_LABELS,
  COMMAND_ROLES,
  FACULTY_STATUS,
  ROOM_STATUS,
  ROOM_TYPES,
  ATTENDANCE_STATUS,
  ATTENDANCE_METHODS,
  LEAVE_STATUS,
  DAYS,
  WORKING_DAYS,
  TIMETABLE_DAYS,
  PERIODS,
  COLLEGE,
  ATTENDANCE_THRESHOLDS,
  DEFAULT_YEAR_RULES,
  NOTIFICATION_TYPES,
};
