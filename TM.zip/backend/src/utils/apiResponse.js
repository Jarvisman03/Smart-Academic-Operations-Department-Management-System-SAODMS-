// Standard API response envelope helpers.

function success(res, { data = null, message = 'Success', meta = null, status = 200 } = {}) {
  const body = { success: true, message, data };
  if (meta) body.meta = meta;
  return res.status(status).json(body);
}

function created(res, opts = {}) {
  return success(res, { ...opts, status: 201, message: opts.message || 'Created' });
}

function fail(res, { message = 'Error', status = 400, errors = null } = {}) {
  const body = { success: false, message };
  if (errors) body.errors = errors;
  return res.status(status).json(body);
}

// Custom error class carrying an HTTP status code.
class ApiError extends Error {
  constructor(status, message, errors = null) {
    super(message);
    this.status = status;
    this.errors = errors;
    this.isOperational = true;
  }
}

module.exports = { success, created, fail, ApiError };
