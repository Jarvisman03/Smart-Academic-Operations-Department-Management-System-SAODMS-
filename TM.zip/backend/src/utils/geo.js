// Geospatial helpers for GPS-based attendance (campus geofencing).

// Haversine distance between two lat/lng points, in metres.
function distanceMeters(lat1, lng1, lat2, lng2) {
  const toRad = (deg) => (deg * Math.PI) / 180;
  const R = 6371000; // Earth radius in metres
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// Is a point within `radiusMeters` of a centre point?
function withinRadius(center, point, radiusMeters) {
  if (!center || center.lat == null || center.lng == null) return { ok: true, distance: 0 };
  if (!point || point.lat == null || point.lng == null) return { ok: false, distance: Infinity };
  const distance = distanceMeters(center.lat, center.lng, point.lat, point.lng);
  return { ok: distance <= radiusMeters, distance: Math.round(distance) };
}

module.exports = { distanceMeters, withinRadius };
