const { DAYS, PERIODS } = require('../config/constants');

// Convert "HH:MM" to minutes since midnight.
function toMinutes(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

// Day name for a JS Date (Sunday=0). Returns e.g. "Monday".
function dayName(date = new Date()) {
  const names = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return names[date.getDay()];
}

function isWorkingDay(date = new Date()) {
  const name = dayName(date);
  return DAYS.includes(name); // Mon-Sat
}

function isStudentDay(date = new Date()) {
  const name = dayName(date);
  return name !== 'Saturday' && name !== 'Sunday'; // students Mon-Fri
}

// Current time as minutes since midnight.
function nowMinutes(date = new Date()) {
  return date.getHours() * 60 + date.getMinutes();
}

// Find the current teaching period based on time-of-day.
function currentPeriod(date = new Date()) {
  const mins = nowMinutes(date);
  return (
    PERIODS.find((p) => mins >= toMinutes(p.start) && mins < toMinutes(p.end)) || null
  );
}

// Start-of-day / end-of-day helpers for range queries.
function startOfDay(date = new Date()) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

function endOfDay(date = new Date()) {
  const d = new Date(date);
  d.setHours(23, 59, 59, 999);
  return d;
}

function startOfWeek(date = new Date()) {
  const d = startOfDay(date);
  const day = d.getDay(); // 0 Sun
  const diff = day === 0 ? -6 : 1 - day; // Monday as week start
  d.setDate(d.getDate() + diff);
  return d;
}

function startOfMonth(date = new Date()) {
  const d = startOfDay(date);
  d.setDate(1);
  return d;
}

function formatDate(date = new Date()) {
  return new Date(date).toISOString().slice(0, 10);
}

module.exports = {
  toMinutes,
  dayName,
  isWorkingDay,
  isStudentDay,
  nowMinutes,
  currentPeriod,
  startOfDay,
  endOfDay,
  startOfWeek,
  startOfMonth,
  formatDate,
};
