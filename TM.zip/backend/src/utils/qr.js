const crypto = require('crypto');
const QRCode = require('qrcode');

// Generate a short-lived signed token for QR attendance.
function generateQrToken(payload, ttlSeconds = 300) {
  const data = { ...payload, exp: Date.now() + ttlSeconds * 1000, nonce: crypto.randomBytes(6).toString('hex') };
  const raw = Buffer.from(JSON.stringify(data)).toString('base64url');
  return raw;
}

function parseQrToken(token) {
  try {
    const data = JSON.parse(Buffer.from(token, 'base64url').toString('utf8'));
    if (data.exp && Date.now() > data.exp) return { valid: false, reason: 'expired' };
    return { valid: true, data };
  } catch (e) {
    return { valid: false, reason: 'invalid' };
  }
}

async function toDataURL(text) {
  return QRCode.toDataURL(text, { margin: 1, width: 300 });
}

module.exports = { generateQrToken, parseQrToken, toDataURL };
