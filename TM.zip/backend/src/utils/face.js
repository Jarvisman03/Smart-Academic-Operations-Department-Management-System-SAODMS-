// Face-descriptor helpers. Descriptors are 128-float vectors produced
// client-side by face-api.js; the server only compares them (no image data
// is stored or transmitted).

const DESCRIPTOR_LENGTH = 128;
// Euclidean distance below this is considered the same person.
// face-api's typical threshold is ~0.6; we use a slightly stricter default.
const DEFAULT_MATCH_THRESHOLD = 0.55;

function isValidDescriptor(desc) {
  return Array.isArray(desc) && desc.length === DESCRIPTOR_LENGTH && desc.every((n) => typeof n === 'number' && Number.isFinite(n));
}

function euclideanDistance(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i += 1) {
    const d = a[i] - b[i];
    sum += d * d;
  }
  return Math.sqrt(sum);
}

// Compare a candidate descriptor to an enrolled one.
function matchFace(enrolled, candidate, threshold = DEFAULT_MATCH_THRESHOLD) {
  if (!isValidDescriptor(enrolled) || !isValidDescriptor(candidate)) {
    return { ok: false, distance: Infinity, score: 0 };
  }
  const distance = euclideanDistance(enrolled, candidate);
  return {
    ok: distance <= threshold,
    distance: Number(distance.toFixed(4)),
    // A friendlier 0-1 confidence for display.
    score: Number(Math.max(0, 1 - distance).toFixed(4)),
  };
}

module.exports = { DESCRIPTOR_LENGTH, DEFAULT_MATCH_THRESHOLD, isValidDescriptor, euclideanDistance, matchFace };
