const cron = require('node-cron');
const statusService = require('../services/statusService');
const attendanceService = require('../services/attendanceService');
const notificationService = require('../services/notificationService');
const Student = require('../models/Student');
const { isWorkingDay } = require('../utils/dateUtils');

// Register scheduled jobs. `io` is passed to broadcast live updates.
function registerJobs(io) {
  // Refresh live faculty/room caches every 5 minutes on working days,
  // and broadcast to the dashboard namespace.
  cron.schedule('*/5 * * * *', async () => {
    if (!isWorkingDay()) return;
    try {
      const snapshot = await statusService.refreshCaches();
      if (io) {
        io.of('/dashboard').emit('status:refresh', {
          at: new Date(),
          facultyCount: Object.keys(snapshot.faculty).length,
          roomCount: Object.keys(snapshot.rooms).length,
        });
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error('[JOB] status refresh failed:', e.message);
    }
  });

  // Daily low-attendance scan at 6:00 PM -> alert HODs and affected students.
  cron.schedule('0 18 * * *', async () => {
    try {
      const { critical, warning, thresholds } = await attendanceService.lowAttendance();
      const flagged = [...critical, ...warning];
      for (const student of flagged) {
        // eslint-disable-next-line no-await-in-loop
        await notificationService.notify({
          recipient: student.user._id || student.user,
          type: 'attendance_alert',
          title: 'Low attendance alert',
          message: `Your attendance is ${student.attendanceSummary.percentage}% (below ${thresholds.minimum}%).`,
          link: '/attendance',
          priority: student.attendanceSummary.percentage < thresholds.critical ? 'critical' : 'high',
        });
      }
      // Alert HODs with a summary.
      await notificationService.notifyByAudience({
        roles: ['hod', 'co_hod'],
        type: 'attendance_alert',
        title: 'Daily attendance alert',
        message: `${critical.length} critical and ${warning.length} warning students below threshold.`,
        link: '/attendance/analytics',
        priority: 'high',
      });
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error('[JOB] low-attendance scan failed:', e.message);
    }
  });

  // eslint-disable-next-line no-console
  console.log('[JOBS] Scheduled jobs registered');
}

module.exports = { registerJobs };
