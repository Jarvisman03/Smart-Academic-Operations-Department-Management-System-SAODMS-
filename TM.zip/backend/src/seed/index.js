/* eslint-disable no-console */
const mongoose = require('mongoose');
const { connectDB, disconnectDB } = require('../config/db');
const env = require('../config/env');
const M = require('../models');
const { ROLES, WORKING_DAYS, PERIODS } = require('../config/constants');
const timetableService = require('../services/timetableService');
const attendanceService = require('../services/attendanceService');

const TEACHING_PERIODS = PERIODS.filter((p) => !p.isBreak);

async function clear() {
  const names = Object.keys(M);
  await Promise.all(names.map((n) => M[n].deleteMany({})));
  console.log('[SEED] Cleared existing collections');
}

const FIRST = ['Aarav', 'Vivaan', 'Aditya', 'Vihaan', 'Arjun', 'Sai', 'Reyansh', 'Krishna', 'Ishaan', 'Rudra', 'Ananya', 'Diya', 'Aadhya', 'Saanvi', 'Pari', 'Anika', 'Navya', 'Riya', 'Myra', 'Sara'];
const LAST = ['Sharma', 'Verma', 'Gupta', 'Yadav', 'Patel', 'Jain', 'Singh', 'Mishra', 'Tiwari', 'Chouhan'];
const rand = (arr) => arr[Math.floor(Math.random() * arr.length)];

async function run() {
  await connectDB();
  await clear();
  const pwd = env.seedDefaultPassword;

  // --- Department & Building ---
  const building = await M.Building.create({ name: 'CSE Block', code: 'CSEB', totalFloors: 4, description: '4-floor CSE department building' });
  const department = await M.Department.create({ name: 'Computer Science & Engineering', code: 'CSE', building: building._id, establishedYear: 2005 });
  building.department = department._id;
  await building.save();

  // --- Settings (Year 4 excluded from shortage) ---
  await M.Settings.create({ scope: 'global' });

  // --- Semester ---
  const semester = await M.Semester.create({ name: 'Odd 2025-26', number: 5, academicYear: '2025-2026', type: 'odd', isCurrent: true, department: department._id });

  // --- Floors & Rooms ---
  const floors = [];
  for (let i = 1; i <= 4; i += 1) {
    // eslint-disable-next-line no-await-in-loop
    floors.push(await M.Floor.create({ building: building._id, number: i, name: `${['Ground', 'First', 'Second', 'Third'][i - 1]} Floor` }));
  }

  const rooms = [];
  const labs = [];
  for (let f = 1; f <= 4; f += 1) {
    const floor = floors[f - 1];
    // 4 classrooms + 1 lab per floor
    for (let r = 1; r <= 4; r += 1) {
      // eslint-disable-next-line no-await-in-loop
      const room = await M.Room.create({
        roomNumber: `${f}0${r}`, name: `Classroom ${f}0${r}`, building: building._id, floor: floor._id, floorNumber: f,
        type: 'classroom', capacity: 70, hasProjector: true, hasAC: f > 2,
      });
      rooms.push(room);
    }
    // eslint-disable-next-line no-await-in-loop
    const labRoom = await M.Room.create({
      roomNumber: `${f}L1`, name: `Lab ${f}L1`, building: building._id, floor: floor._id, floorNumber: f,
      type: 'lab', capacity: 40, hasProjector: true, hasAC: true,
    });
    rooms.push(labRoom);
    const labNames = ['Programming Lab', 'Networking Lab', 'AI/ML Lab', 'Project Lab'];
    // eslint-disable-next-line no-await-in-loop
    const lab = await M.Lab.create({
      room: labRoom._id, name: `${labNames[f - 1]}`, systemsCount: 40, workingSystems: 38,
      software: ['VS Code', 'Python', 'Node.js', 'MongoDB'], specialization: labNames[f - 1], equipmentStatus: 'operational',
    });
    labs.push(lab);
  }

  // --- Subjects (Year 2,3,4) ---
  const subjectDefs = [
    { name: 'Data Structures', code: 'CS201', year: 2, semester: 3, type: 'theory' },
    { name: 'Digital Electronics', code: 'CS202', year: 2, semester: 3, type: 'theory' },
    { name: 'DS Lab', code: 'CS203', year: 2, semester: 3, type: 'lab' },
    { name: 'Database Management', code: 'CS301', year: 3, semester: 5, type: 'theory' },
    { name: 'Operating Systems', code: 'CS302', year: 3, semester: 5, type: 'theory' },
    { name: 'Computer Networks', code: 'CS303', year: 3, semester: 5, type: 'theory' },
    { name: 'DBMS Lab', code: 'CS304', year: 3, semester: 5, type: 'lab' },
    { name: 'Machine Learning', code: 'CS401', year: 4, semester: 7, type: 'theory' },
    { name: 'Cloud Computing', code: 'CS402', year: 4, semester: 7, type: 'theory' },
    { name: 'ML Lab', code: 'CS403', year: 4, semester: 7, type: 'lab' },
  ];
  const subjects = [];
  for (const s of subjectDefs) {
    // eslint-disable-next-line no-await-in-loop
    subjects.push(await M.Subject.create({ ...s, department: department._id, weeklyLectures: s.type === 'lab' ? 2 : 3 }));
  }

  // --- Leadership users ---
  const admin = await M.User.create({ name: 'System Administrator', email: 'admin@sirtcse.edu', password: pwd, role: ROLES.ADMIN, department: department._id });
  const dean = await M.User.create({ name: 'Dr. R. K. Pandey (Dean)', email: 'dean@sirtcse.edu', password: pwd, role: ROLES.DEAN, department: department._id });
  const hod1User = await M.User.create({ name: 'Dr. S. Sharma (HOD)', email: 'hod1@sirtcse.edu', password: pwd, role: ROLES.HOD, department: department._id });
  const hod2User = await M.User.create({ name: 'Dr. M. Verma (HOD)', email: 'hod2@sirtcse.edu', password: pwd, role: ROLES.HOD, department: department._id });
  const coHodUser = await M.User.create({ name: 'Prof. A. Gupta (Co-HOD)', email: 'cohod@sirtcse.edu', password: pwd, role: ROLES.CO_HOD, department: department._id });
  const labAsst = await M.User.create({ name: 'Mr. Ramesh (Lab Assistant)', email: 'lab@sirtcse.edu', password: pwd, role: ROLES.LAB_ASSISTANT, department: department._id });

  department.dean = dean._id;
  department.hod = [hod1User._id, hod2User._id];
  department.coHod = coHodUser._id;
  await department.save();

  // Leadership faculty profiles (HODs/Co-HOD also teach).
  const leaderFaculty = [];
  for (const [i, u] of [hod1User, hod2User, coHodUser].entries()) {
    // eslint-disable-next-line no-await-in-loop
    leaderFaculty.push(await M.Faculty.create({
      user: u._id, employeeId: `EMPL${100 + i}`, department: department._id,
      designation: i < 2 ? 'Professor' : 'Associate Professor', expertise: [subjects[i]._id, subjects[i + 3]._id],
      gender: i === 1 ? 'female' : 'male', cabin: `${i + 1}01`, joiningDate: new Date('2015-07-01'),
    }));
  }

  // --- Faculty pool ---
  const faculties = [...leaderFaculty];
  for (let i = 0; i < 10; i += 1) {
    const name = `${rand(FIRST)} ${rand(LAST)}`;
    // eslint-disable-next-line no-await-in-loop
    const u = await M.User.create({ name: `Prof. ${name}`, email: `faculty${i + 1}@sirtcse.edu`, password: pwd, role: ROLES.FACULTY, department: department._id });
    // Assign 2 random subject expertises.
    const exp = [subjects[i % subjects.length]._id, subjects[(i + 3) % subjects.length]._id];
    // eslint-disable-next-line no-await-in-loop
    faculties.push(await M.Faculty.create({
      user: u._id, employeeId: `EMP${200 + i}`, department: department._id,
      designation: 'Assistant Professor', expertise: exp, gender: i % 3 === 0 ? 'female' : 'male',
      cabin: `${(i % 4) + 1}0${(i % 4) + 2}`, joiningDate: new Date('2019-08-01'),
    }));
  }

  // Assign lab in-charges.
  for (const [i, lab] of labs.entries()) {
    lab.labInCharge = faculties[i % faculties.length]._id;
    lab.labAssistant = labAsst._id;
    // eslint-disable-next-line no-await-in-loop
    await lab.save();
  }

  // --- Sections (Year 2, 3, 4 - Section A) ---
  const sections = [];
  for (const year of [2, 3, 4]) {
    const sem = { 2: 3, 3: 5, 4: 7 }[year];
    // eslint-disable-next-line no-await-in-loop
    const section = await M.Section.create({
      name: 'A', department: department._id, year, semester: sem, batch: `${2026 - year + 1}-${2030 - year + 1}`,
      classTeacher: faculties[year]._id, strength: 0,
    });
    sections.push(section);
  }

  // --- Students (30 per section) ---
  const studentsBySection = {};
  for (const section of sections) {
    studentsBySection[section._id] = [];
    for (let i = 0; i < 30; i += 1) {
      const name = `${rand(FIRST)} ${rand(LAST)}`;
      const gender = i % 2 === 0 ? 'male' : 'female';
      const roll = `${section.year}${String(i + 1).padStart(3, '0')}`;
      // eslint-disable-next-line no-await-in-loop
      const u = await M.User.create({ name, email: `stu${section.year}${i + 1}@sirtcse.edu`, password: pwd, role: ROLES.STUDENT, department: department._id });
      // eslint-disable-next-line no-await-in-loop
      const student = await M.Student.create({
        user: u._id, enrollmentNo: `0101CS${section.year}${String(i + 1).padStart(3, '0')}`, rollNo: roll,
        department: department._id, year: section.year, semester: section.semester, section: section._id,
        batch: section.batch, gender,
      });
      studentsBySection[section._id].push(student);
    }
    section.strength = 30;
    // eslint-disable-next-line no-await-in-loop
    await section.save();
  }
  console.log('[SEED] Created users, faculty, students, sections');

  // --- Timetable (auto-generate per section) ---
  for (const section of sections) {
    // eslint-disable-next-line no-await-in-loop
    const result = await timetableService.generateForSection(section._id, { clearExisting: true });
    console.log(`[SEED] Timetable for Year ${section.year}-A: ${result.created} entries`);
  }

  // --- Sample attendance for the last 10 working days ---
  const today = new Date();
  let sessionsCreated = 0;
  const affectedStudents = new Set();
  for (let d = 0; d < 14; d += 1) {
    const date = new Date(today);
    date.setDate(today.getDate() - d);
    const dayIdx = date.getDay();
    if (dayIdx === 0 || dayIdx === 6) continue; // skip weekends for students
    const dayNm = WORKING_DAYS[dayIdx - 1];

    // eslint-disable-next-line no-await-in-loop
    const entries = await M.Timetable.find({ day: dayNm, isActive: true }).limit(30);
    for (const e of entries) {
      const roster = studentsBySection[e.section] || [];
      if (!roster.length) continue;
      const records = roster.map((s) => {
        const present = Math.random() > 0.18; // ~82% present
        affectedStudents.add(s._id.toString());
        return { student: s._id, status: present ? 'present' : 'absent' };
      });
      const rule = { 4: false }[e.year] === false && e.year === 4 ? false : true;
      // eslint-disable-next-line no-await-in-loop
      await M.Attendance.create({
        department: department._id, section: e.section, year: e.year, subject: e.subject,
        faculty: e.faculty, room: e.room, timetableEntry: e._id, date, period: e.period,
        method: 'manual', records, countsTowardShortage: e.year !== 4, approvalStatus: 'approved',
      });
      sessionsCreated += 1;
    }
  }
  console.log(`[SEED] Created ${sessionsCreated} attendance sessions`);

  // Recompute student summaries.
  await attendanceService.recomputeForStudents([...affectedStudents]);
  console.log('[SEED] Recomputed student attendance summaries');

  // --- Faculty attendance today ---
  for (const [i, f] of faculties.entries()) {
    const checkIn = new Date(today);
    checkIn.setHours(8, 25 + (i % 20), 0, 0);
    // eslint-disable-next-line no-await-in-loop
    await M.FacultyAttendance.create({
      faculty: f._id, department: department._id, date: today, checkIn,
      status: i % 7 === 0 ? 'late' : 'present', method: 'manual', lateByMinutes: i % 7 === 0 ? 15 : 0,
    });
  }

  // --- Announcements, events, meetings ---
  await M.Announcement.create({ title: 'Mid-Semester Exams Schedule Released', body: 'Mid-sem exams begin next Monday. Check the notice board.', department: department._id, author: hod1User._id, priority: 'high', audience: ['all'], pinned: true });
  await M.Announcement.create({ title: 'Placement Drive - TCS', body: 'TCS placement drive on Saturday for final year students.', department: department._id, author: coHodUser._id, priority: 'normal', audience: ['year4'] });
  await M.Event.create({ title: 'Tech Fest 2026', description: 'Annual technical festival', department: department._id, category: 'fest', organizer: coHodUser._id, startDate: new Date(today.getTime() + 7 * 86400000), venue: 'CSE Block' });
  await M.Meeting.create({ title: 'Department Review Meeting', agenda: 'Monthly academic review', department: department._id, organizer: hod1User._id, attendees: faculties.slice(0, 5).map((f) => f.user), date: new Date(today.getTime() + 2 * 86400000), startTime: '11:35', endTime: '12:30', room: rooms[0]._id });

  // --- Sample leave ---
  await M.Leave.create({ applicant: faculties[5].user, faculty: faculties[5]._id, department: department._id, type: 'casual', fromDate: new Date(today.getTime() + 86400000), toDate: new Date(today.getTime() + 86400000), days: 1, reason: 'Personal work', status: 'pending' });

  console.log('\n[SEED] ============================================');
  console.log('[SEED] Seed complete. Login accounts (password below):');
  console.log(`[SEED]   Admin:   admin@sirtcse.edu`);
  console.log(`[SEED]   Dean:    dean@sirtcse.edu`);
  console.log(`[SEED]   HOD:     hod1@sirtcse.edu / hod2@sirtcse.edu`);
  console.log(`[SEED]   Co-HOD:  cohod@sirtcse.edu`);
  console.log(`[SEED]   Faculty: faculty1@sirtcse.edu ... faculty10@sirtcse.edu`);
  console.log(`[SEED]   Lab:     lab@sirtcse.edu`);
  console.log(`[SEED]   Student: stu2001@sirtcse.edu (year2) etc.`);
  console.log(`[SEED]   Password (all): ${pwd}`);
  console.log('[SEED] ============================================');

  await disconnectDB();
  process.exit(0);
}

run().catch((err) => {
  console.error('[SEED] Failed:', err);
  process.exit(1);
});
