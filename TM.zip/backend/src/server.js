const http = require('http');
const { Server } = require('socket.io');
const app = require('./app');
const env = require('./config/env');
const { connectDB } = require('./config/db');
const { initSockets } = require('./sockets');
const { registerJobs } = require('./jobs');

async function start() {
  await connectDB();

  const server = http.createServer(app);
  const io = new Server(server, {
    cors: { origin: env.clientUrl, credentials: true },
  });

  // Make io available to controllers via req.app.get('io').
  app.set('io', io);
  initSockets(io);
  registerJobs(io);

  server.listen(env.port, () => {
    // eslint-disable-next-line no-console
    console.log(`[SERVER] SAODMS API running on http://localhost:${env.port} (${env.nodeEnv})`);
  });

  // Graceful shutdown.
  const shutdown = () => {
    // eslint-disable-next-line no-console
    console.log('\n[SERVER] Shutting down...');
    server.close(() => process.exit(0));
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

start().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('[SERVER] Failed to start:', err);
  process.exit(1);
});
