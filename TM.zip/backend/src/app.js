const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const env = require('./config/env');
const routes = require('./routes');
const { notFound, errorHandler } = require('./middleware/error');

const app = express();

app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({ origin: env.clientUrl, credentials: true }));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
if (env.nodeEnv !== 'test') app.use(morgan('dev'));

// Serve locally-uploaded files when Cloudinary is not configured.
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Basic rate limiting on the API.
app.use(
  '/api',
  rateLimit({ windowMs: 15 * 60 * 1000, max: env.nodeEnv === 'production' ? 500 : 5000, standardHeaders: true, legacyHeaders: false })
);

app.get('/health', (req, res) => res.json({ success: true, status: 'ok', service: 'SAODMS API', time: new Date() }));

app.use('/api', routes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
