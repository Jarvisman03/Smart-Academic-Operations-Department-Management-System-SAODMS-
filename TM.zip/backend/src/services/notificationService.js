const Notification = require('../models/Notification');
const User = require('../models/User');
const emailService = require('./emailService');

let ioRef = null;
function setIo(io) { ioRef = io; }

// Create a notification and push it in real time.
async function notify({ recipient, type, title, message, link, priority = 'normal', meta, createdBy, email = false }) {
  const notification = await Notification.create({ recipient, type, title, message, link, priority, meta, createdBy });
  if (ioRef) {
    ioRef.of('/notifications').to(`user:${recipient}`).emit('notification:new', notification);
  }
  if (email) {
    const user = await User.findById(recipient).select('email name');
    if (user) await emailService.sendMail({ to: user.email, subject: title, html: `<p>${message || ''}</p>` });
  }
  return notification;
}

// Notify many users (fan-out).
async function notifyMany(recipients = [], payload) {
  const docs = recipients.map((r) => ({ ...payload, recipient: r }));
  const created = await Notification.insertMany(docs);
  if (ioRef) {
    created.forEach((n) => ioRef.of('/notifications').to(`user:${n.recipient}`).emit('notification:new', n));
  }
  return created;
}

// Notify all users matching a role / department filter.
async function notifyByAudience({ roles = [], department, ...payload }) {
  const filter = { isActive: true };
  if (roles.length) filter.role = { $in: roles };
  if (department) filter.department = department;
  const users = await User.find(filter).select('_id');
  return notifyMany(users.map((u) => u._id), payload);
}

module.exports = { setIo, notify, notifyMany, notifyByAudience };
