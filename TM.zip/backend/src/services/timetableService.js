const Timetable = require('../models/Timetable');
const Subject = require('../models/Subject');
const Faculty = require('../models/Faculty');
const Room = require('../models/Room');
const Section = require('../models/Section');
const { WORKING_DAYS, TIMETABLE_DAYS, PERIODS } = require('../config/constants');

const TEACHING_PERIODS = PERIODS.filter((p) => !p.isBreak);
const TEACHING_NUMBERS = TEACHING_PERIODS.map((p) => p.period);

// The consecutive teaching periods an entry occupies, given its start + span.
function occupiedPeriods(period, span = 1) {
  const startIdx = TEACHING_NUMBERS.indexOf(Number(period));
  if (startIdx === -1) return [Number(period)];
  return TEACHING_NUMBERS.slice(startIdx, startIdx + Math.max(1, Number(span) || 1));
}

// Start/end clock times for an entry spanning `span` periods from `period`.
function spanTimes(period, span = 1) {
  const occ = occupiedPeriods(period, span);
  const first = TEACHING_PERIODS.find((p) => p.period === occ[0]);
  const last = TEACHING_PERIODS.find((p) => p.period === occ[occ.length - 1]);
  return { start: first?.start, end: (last || first)?.end };
}

// How many consecutive teaching periods a custom [start, end) clock range covers,
// starting from `period`. A period is "occupied" if the class overlaps its window,
// so a 2-hour class from Period 1 reserves Periods 1 & 2 (and 3 if it bleeds in).
function spanFromTimes(period, startTime, endTime) {
  if (!startTime || !endTime) return 1;
  const startIdx = TEACHING_NUMBERS.indexOf(Number(period));
  if (startIdx === -1) return 1;
  let span = 0;
  for (let i = startIdx; i < TEACHING_PERIODS.length; i += 1) {
    const p = TEACHING_PERIODS[i];
    const overlaps = startTime < p.end && endTime > p.start;
    if (overlaps) span += 1;
    else if (i > startIdx) break; // contiguous run has ended
  }
  return Math.max(1, span);
}

// Normalize an entry's timing: if explicit clock times are given, derive the
// period span from them; otherwise fall back to the period template for the span.
function applyTiming(data) {
  if (data.startTime && data.endTime) {
    data.periodSpan = spanFromTimes(data.period, data.startTime, data.endTime);
  } else {
    const { start, end } = spanTimes(data.period, data.periodSpan);
    data.startTime = start;
    data.endTime = end;
    data.periodSpan = data.periodSpan || 1;
  }
}

// Detect conflicts for a proposed entry, accounting for multi-period overlap.
// Two entries clash if they share a resource (faculty/room/section) on the same
// day and their occupied period-sets intersect.
async function detectConflicts({ day, period, periodSpan = 1, faculty, room, section, excludeId }) {
  const wanted = new Set(occupiedPeriods(period, periodSpan));
  const base = { day, isActive: true };
  if (excludeId) base._id = { $ne: excludeId };

  const dims = [];
  if (faculty) dims.push({ type: 'faculty', filter: { ...base, faculty } });
  if (room) dims.push({ type: 'room', filter: { ...base, room } });
  if (section) dims.push({ type: 'section', filter: { ...base, section } });

  const messages = {
    faculty: 'Faculty already teaching in an overlapping slot',
    room: 'Room already occupied in an overlapping slot',
    section: 'Section already has a class in an overlapping slot',
  };

  const conflicts = [];
  for (const dim of dims) {
    // eslint-disable-next-line no-await-in-loop
    const rows = await Timetable.find(dim.filter).populate('subject section', 'name');
    const clash = rows.find((r) => occupiedPeriods(r.period, r.periodSpan).some((p) => wanted.has(p)));
    if (clash) conflicts.push({ type: dim.type, message: messages[dim.type], entry: clash });
  }
  return conflicts;
}

// Create an entry with conflict guard.
async function createEntry(data) {
  applyTiming(data);
  const conflicts = await detectConflicts(data);
  if (conflicts.length) {
    const err = new Error('Timetable conflict detected');
    err.status = 409;
    err.errors = conflicts;
    throw err;
  }
  return Timetable.create(data);
}

// Update an entry with conflict guard + span/time recomputation.
async function updateEntry(id, data) {
  if (data.period != null) applyTiming(data);
  const conflicts = await detectConflicts({ ...data, excludeId: id });
  if (conflicts.length) {
    const err = new Error('Timetable conflict detected');
    err.status = 409;
    err.errors = conflicts;
    throw err;
  }
  return Timetable.findByIdAndUpdate(id, data, { new: true, runValidators: true });
}

// Generic day x period grid for any filter (section / faculty / room).
async function buildGrid(filter) {
  const entries = await Timetable.find({ ...filter, isActive: true })
    .populate({ path: 'faculty', populate: { path: 'user', select: 'name' } })
    .populate('subject', 'name code')
    .populate('room', 'roomNumber')
    .populate('section', 'name year');
  const grid = {};
  for (const day of TIMETABLE_DAYS) {
    grid[day] = {};
    for (const p of TEACHING_PERIODS) grid[day][p.period] = null;
  }
  for (const e of entries) {
    if (!grid[e.day]) continue;
    const occ = occupiedPeriods(e.period, e.periodSpan);
    grid[e.day][occ[0]] = e;
    // Mark the trailing periods so the UI can skip them (start cell colspans).
    for (let i = 1; i < occ.length; i += 1) {
      if (grid[e.day][occ[i]] === null) grid[e.day][occ[i]] = { _covered: true };
    }
  }
  return { periods: TEACHING_PERIODS, days: TIMETABLE_DAYS, grid, entries };
}

const weeklyGrid = (sectionId) => buildGrid({ section: sectionId });
const facultyGrid = (facultyId) => buildGrid({ faculty: facultyId });
const roomGrid = (roomId) => buildGrid({ room: roomId });

// Greedy automatic generator for a section.
// Places each subject's weekly lectures into free slots avoiding conflicts.
async function generateForSection(sectionId, options = {}) {
  const section = await Section.findById(sectionId);
  if (!section) throw new Error('Section not found');

  const subjects = await Subject.find({ department: section.department, year: section.year, semester: section.semester, isActive: true });
  const rooms = await Room.find({ type: { $in: ['classroom', 'lab'] }, isActive: true });
  const faculties = await Faculty.find({ department: section.department, isActive: true }).populate('expertise');

  if (options.clearExisting) {
    await Timetable.deleteMany({ section: sectionId });
  }

  // Track occupancy: keyed by `${scope}:${day}:${period}`.
  const occupied = new Set();
  const existing = await Timetable.find({ isActive: true });
  for (const e of existing) {
    occupied.add(`fac:${e.faculty}:${e.day}:${e.period}`);
    occupied.add(`room:${e.room}:${e.day}:${e.period}`);
    occupied.add(`sec:${e.section}:${e.day}:${e.period}`);
  }

  const created = [];
  const unplaced = [];

  for (const subject of subjects) {
    const facultyForSubject = faculties.find((f) => (f.expertise || []).some((s) => s._id.toString() === subject._id.toString())) || faculties[0];
    const roomPool = subject.type === 'lab' ? rooms.filter((r) => r.type === 'lab') : rooms.filter((r) => r.type === 'classroom');
    let placed = 0;

    for (const day of WORKING_DAYS) {
      if (placed >= (subject.weeklyLectures || 3)) break;
      for (const p of TEACHING_PERIODS) {
        if (placed >= (subject.weeklyLectures || 3)) break;
        const secKey = `sec:${sectionId}:${day}:${p.period}`;
        if (occupied.has(secKey)) continue;
        if (!facultyForSubject) continue;
        const facKey = `fac:${facultyForSubject._id}:${day}:${p.period}`;
        if (occupied.has(facKey)) continue;
        const room = roomPool.find((r) => !occupied.has(`room:${r._id}:${day}:${p.period}`));
        if (!room) continue;

        // eslint-disable-next-line no-await-in-loop
        const entry = await Timetable.create({
          department: section.department,
          section: sectionId,
          year: section.year,
          day,
          period: p.period,
          startTime: p.start,
          endTime: p.end,
          subject: subject._id,
          subjectName: subject.name,
          faculty: facultyForSubject._id,
          room: room._id,
          roomName: room.roomNumber,
          type: subject.type === 'lab' ? 'lab' : 'theory',
        });
        occupied.add(secKey);
        occupied.add(facKey);
        occupied.add(`room:${room._id}:${day}:${p.period}`);
        created.push(entry);
        placed += 1;
      }
    }
    if (placed < (subject.weeklyLectures || 3)) {
      unplaced.push({ subject: subject.name, placed, required: subject.weeklyLectures || 3 });
    }
  }

  return { created: created.length, unplaced };
}

module.exports = {
  detectConflicts,
  createEntry,
  updateEntry,
  weeklyGrid,
  facultyGrid,
  roomGrid,
  generateForSection,
  occupiedPeriods,
};
