const nodemailer = require('nodemailer');
const env = require('../config/env');

let transporter = null;
if (env.smtp.enabled) {
  transporter = nodemailer.createTransport({
    host: env.smtp.host,
    port: env.smtp.port,
    secure: env.smtp.port === 465,
    auth: { user: env.smtp.user, pass: env.smtp.pass },
  });
}

// Sends an email, or logs to console when SMTP is not configured.
async function sendMail({ to, subject, html, text }) {
  if (!transporter) {
    // eslint-disable-next-line no-console
    console.log(`[EMAIL:mock] to=${to} subject="${subject}"`);
    return { mocked: true };
  }
  return transporter.sendMail({ from: env.smtp.from, to, subject, html, text });
}

module.exports = { sendMail, enabled: env.smtp.enabled };
