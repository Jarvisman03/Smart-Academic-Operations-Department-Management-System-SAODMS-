const Timetable = require('../models/Timetable');
const Faculty = require('../models/Faculty');
const Leave = require('../models/Leave');
const { LEAVE_STATUS } = require('../config/constants');
const { startOfDay, endOfDay, dayName } = require('../utils/dateUtils');

// Suggest substitute faculty for a given timetable entry on a date.
// Ranking factors: subject expertise, availability in the slot, department, workload.
async function suggestSubstitutes(timetableEntryId, date = new Date()) {
  const entry = await Timetable.findById(timetableEntryId).populate('subject').populate('faculty');
  if (!entry) throw new Error('Timetable entry not found');

  const day = dayName(date);

  // Candidate pool: active faculty in same department, excluding the original.
  const candidates = await Faculty.find({
    department: entry.department,
    isActive: true,
    _id: { $ne: entry.faculty._id },
  }).populate('user', 'name avatar').populate('expertise', 'name code');

  // Faculty busy in this exact slot (any section).
  const busy = await Timetable.find({ day, period: entry.period, isActive: true }).distinct('faculty');
  const busySet = new Set(busy.map((b) => b.toString()));

  // Faculty on approved leave that day.
  const leaves = await Leave.find({
    status: LEAVE_STATUS.APPROVED,
    fromDate: { $lte: endOfDay(date) },
    toDate: { $gte: startOfDay(date) },
  }).distinct('faculty');
  const leaveSet = new Set(leaves.map((l) => l.toString()));

  // Weekly load per candidate (count of active entries).
  const loadAgg = await Timetable.aggregate([
    { $match: { isActive: true } },
    { $group: { _id: '$faculty', load: { $sum: 1 } } },
  ]);
  const loadMap = {};
  loadAgg.forEach((l) => { loadMap[l._id.toString()] = l.load; });

  const scored = candidates
    .map((c) => {
      const id = c._id.toString();
      const isFree = !busySet.has(id) && !leaveSet.has(id);
      const subjId = entry.subject?._id?.toString();
      const hasExpertise = subjId ? (c.expertise || []).some((s) => s._id.toString() === subjId) : false;
      const load = loadMap[id] || 0;
      const loadRatio = c.maxWeeklyLoad ? load / c.maxWeeklyLoad : 1;

      // Score: expertise 50, free 30, low workload up to 20.
      let score = 0;
      if (hasExpertise) score += 50;
      if (isFree) score += 30;
      score += Math.max(0, 20 - loadRatio * 20);

      return {
        faculty: { _id: c._id, name: c.user?.name, avatar: c.user?.avatar, designation: c.designation },
        isFree,
        hasExpertise,
        weeklyLoad: load,
        maxLoad: c.maxWeeklyLoad,
        score: Math.round(score),
      };
    })
    // Only propose faculty who are actually free.
    .filter((c) => c.isFree)
    .sort((a, b) => b.score - a.score);

  return {
    entry: {
      _id: entry._id,
      subject: entry.subject?.name || entry.subjectName,
      period: entry.period,
      day,
      originalFaculty: entry.faculty?._id,
    },
    suggestions: scored.slice(0, 5),
  };
}

module.exports = { suggestSubstitutes };
