const axios = require('axios');
const env = require('../config/env');
const Faculty = require('../models/Faculty');
const Timetable = require('../models/Timetable');
const Room = require('../models/Room');
const attendanceService = require('./attendanceService');

// ------------------------------------------------------------
// Provider-agnostic text completion. Falls back to a canned
// heuristic response when no provider/key is configured.
// ------------------------------------------------------------
async function complete(prompt, system = 'You are SAODMS AI, an academic operations assistant for SIRT CSE.', fallbackText = '') {
  const provider = env.ai.provider;
  try {
    if (provider === 'gemini' && env.ai.geminiKey) {
      const model = env.ai.model || 'gemini-1.5-flash';
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${env.ai.geminiKey}`;
      const { data } = await axios.post(url, {
        contents: [{ parts: [{ text: `${system}\n\n${prompt}` }] }],
      });
      return data?.candidates?.[0]?.content?.parts?.[0]?.text || 'No response.';
    }
    if (provider === 'openai' && env.ai.openaiKey) {
      const model = env.ai.model || 'gpt-4o-mini';
      const { data } = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        { model, messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }] },
        { headers: { Authorization: `Bearer ${env.ai.openaiKey}` } }
      );
      return data?.choices?.[0]?.message?.content || 'No response.';
    }
    // NVIDIA NIM exposes an OpenAI-compatible chat/completions endpoint.
    if (provider === 'nvidia' && env.ai.nvidiaKey) {
      const model = env.ai.model || 'meta/llama-3.1-8b-instruct';
      const { data } = await axios.post(
        `${env.ai.nvidiaBaseUrl}/chat/completions`,
        { model, messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }] },
        { headers: { Authorization: `Bearer ${env.ai.nvidiaKey}` } }
      );
      return data?.choices?.[0]?.message?.content || 'No response.';
    }
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error('[AI] provider error:', e.message);
    return `AI provider error. Falling back to offline mode.\n\n${heuristicAnswer(fallbackText || prompt)}`;
  }
  return heuristicAnswer(fallbackText || prompt);
}

// Simple offline assistant for demos without an API key. Keys off the user's
// actual message (not the whole transcript) so answers vary per question.
function heuristicAnswer(text) {
  const p = String(text || '').toLowerCase();
  if (/\b(hi|hello|hey|hii+|namaste|good (morning|afternoon|evening))\b/.test(p)) {
    return 'Hello! I am the SAODMS assistant. I can help with attendance, timetables, faculty workload, room utilization, and substitutions. To get smarter answers, set AI_PROVIDER and an API key in backend/.env.';
  }
  if (p.includes('name')) return "I'm SAODMS AI, the academic operations assistant for SIRT CSE. I don't store personal profiles here, but I can help you look up students or faculty from their pages.";
  if (p.includes('attendance') || p.includes('present') || p.includes('shortage')) return 'Attendance below 75% is flagged as shortage for 2nd and 3rd year. 4th year is recorded but excluded from shortage per department rules. Check the Attendance Analytics page for trends.';
  if (p.includes('timetable') || p.includes('time table') || p.includes('schedule') || p.includes('class') || p.includes('period')) return 'Open the Timetable page to view or edit the weekly schedule by section or faculty. Managers can click a slot to add or edit a class and drag to move it.';
  if (p.includes('substitute')) return 'Use the Timetable page to open a class and click "Suggest Substitute". The system ranks free faculty by subject expertise and workload.';
  if (p.includes('workload') || p.includes('load')) return 'Faculty workload is on the AI Assistant panel and Reports. It compares each faculty member\'s weekly teaching load against their max capacity.';
  if (p.includes('room') || p.includes('lab')) return 'Open the Building Monitor for a live 4-floor map. Green = occupied, Gray = free, Yellow = reserved, Red = maintenance.';
  return 'I can help with attendance, timetables, faculty workload, room utilization, and substitutions. Ask me about any of these, or configure an AI provider key in backend/.env for richer answers.';
}

// Which provider is active and whether it has a usable key.
function status() {
  const p = env.ai.provider;
  const keyByProvider = { gemini: env.ai.geminiKey, openai: env.ai.openaiKey, nvidia: env.ai.nvidiaKey };
  return {
    provider: p,
    enabled: p !== 'none' && Boolean(keyByProvider[p]),
    model: env.ai.model || null,
  };
}

// Summarize the department's live state so the model can answer with real numbers.
async function buildDepartmentContext(departmentId) {
  try {
    const [analytics, low, workload, rooms] = await Promise.all([
      attendanceService.analytics(departmentId, 'year').catch(() => []),
      attendanceService.lowAttendance(departmentId).catch(() => ({ critical: [], warning: [] })),
      predictWorkload(departmentId).catch(() => []),
      predictRoomUtilization().catch(() => []),
    ]);
    const lines = [];
    if (analytics?.length) lines.push(`Attendance by year: ${analytics.map((r) => `Y${r.key}=${r.percentage}%`).join(', ')}`);
    lines.push(`Students critical (<50%): ${low.critical?.length || 0}; approaching shortage: ${low.warning?.length || 0}.`);
    const overloaded = (workload || []).filter((w) => w.status === 'overloaded').slice(0, 5);
    if (overloaded.length) lines.push(`Overloaded faculty: ${overloaded.map((w) => `${w.faculty} (${w.utilization}%)`).join(', ')}`);
    const busyRooms = (rooms || []).filter((r) => r.utilization > 80).slice(0, 5);
    if (busyRooms.length) lines.push(`High-utilization rooms: ${busyRooms.map((r) => `${r.room} (${r.utilization}%)`).join(', ')}`);
    return lines.join('\n');
  } catch (e) {
    return '';
  }
}

async function chat(message, context = {}) {
  const { departmentId, role, history } = context;
  const liveContext = departmentId ? await buildDepartmentContext(departmentId) : '';
  const system = [
    'You are SAODMS AI, an academic operations assistant for SIRT, Computer Science & Engineering (CSE) department.',
    'Help with attendance, timetables, faculty workload, room utilization, and substitutions. Be concise and specific.',
    role ? `The user asking is a ${role}.` : '',
    liveContext ? `\nLive department data (use these real numbers when relevant):\n${liveContext}` : '',
  ].filter(Boolean).join('\n');

  // Fold the recent turns into the prompt for lightweight multi-turn memory.
  const transcript = Array.isArray(history) && history.length
    ? `${history.slice(-6).map((h) => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.text}`).join('\n')}\n`
    : '';

  return complete(`${transcript}User: ${message}`, system, message);
}

// Attendance prediction: naive linear projection from recent trend.
async function predictAttendance(departmentId) {
  const analytics = await attendanceService.analytics(departmentId, 'year');
  const predictions = analytics.map((row) => {
    // Project a small decay/growth toward the mean of 78%.
    const projected = Math.round(row.percentage * 0.6 + 78 * 0.4);
    return { year: row.key, current: row.percentage, projectedNextMonth: projected, risk: projected < 75 ? 'high' : 'low' };
  });
  return { predictions, note: 'Projection blends current rate with historical mean (78%).' };
}

// Faculty workload prediction based on weekly timetable load.
async function predictWorkload(departmentId) {
  const faculties = await Faculty.find({ isActive: true, ...(departmentId && { department: departmentId }) }).populate('user', 'name');
  const loadAgg = await Timetable.aggregate([
    { $match: { isActive: true } },
    { $group: { _id: '$faculty', load: { $sum: 1 } } },
  ]);
  const loadMap = {};
  loadAgg.forEach((l) => { loadMap[l._id.toString()] = l.load; });
  return faculties.map((f) => {
    const load = loadMap[f._id.toString()] || 0;
    const ratio = f.maxWeeklyLoad ? load / f.maxWeeklyLoad : 0;
    return {
      faculty: f.user?.name,
      weeklyLoad: load,
      maxLoad: f.maxWeeklyLoad,
      utilization: Math.round(ratio * 100),
      status: ratio > 0.9 ? 'overloaded' : ratio < 0.4 ? 'underutilized' : 'balanced',
    };
  }).sort((a, b) => b.utilization - a.utilization);
}

// Room utilization prediction (share of teaching slots used).
async function predictRoomUtilization() {
  const rooms = await Room.find({ isActive: true, type: { $in: ['classroom', 'lab'] } });
  const usageAgg = await Timetable.aggregate([
    { $match: { isActive: true } },
    { $group: { _id: '$room', slots: { $sum: 1 } } },
  ]);
  const usageMap = {};
  usageAgg.forEach((u) => { usageMap[u._id.toString()] = u.slots; });
  const maxSlots = 5 * 6; // days * teaching periods
  return rooms.map((r) => {
    const slots = usageMap[r._id.toString()] || 0;
    const util = Math.round((slots / maxSlots) * 100);
    return { room: r.roomNumber, type: r.type, weeklySlots: slots, utilization: util, status: util > 80 ? 'high' : util < 30 ? 'low' : 'moderate' };
  }).sort((a, b) => b.utilization - a.utilization);
}

// Risk detection: aggregates multiple signals into an actionable list.
async function detectRisks(departmentId) {
  const risks = [];
  const low = await attendanceService.lowAttendance(departmentId);
  if (low.critical.length) risks.push({ level: 'critical', area: 'attendance', message: `${low.critical.length} students in critical attendance zone.` });
  if (low.warning.length) risks.push({ level: 'high', area: 'attendance', message: `${low.warning.length} students approaching shortage.` });

  const workload = await predictWorkload(departmentId);
  const overloaded = workload.filter((w) => w.status === 'overloaded');
  if (overloaded.length) risks.push({ level: 'medium', area: 'workload', message: `${overloaded.length} faculty overloaded (>90% capacity).` });

  const rooms = await predictRoomUtilization();
  const highUse = rooms.filter((r) => r.utilization > 85);
  if (highUse.length) risks.push({ level: 'low', area: 'resources', message: `${highUse.length} rooms near capacity utilization.` });

  return { risks, generatedAt: new Date() };
}

module.exports = {
  complete,
  chat,
  status,
  predictAttendance,
  predictWorkload,
  predictRoomUtilization,
  detectRisks,
};
