const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');
const { COLLEGE } = require('../config/constants');

// ------------------------------------------------------------
// Report generators return a Buffer + content metadata so the
// controller can stream them with correct headers.
// ------------------------------------------------------------

// Build a PDF from a simple table spec.
function buildPdf({ title, subtitle, columns, rows }) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 40, size: 'A4' });
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    // Header
    doc.fontSize(16).fillColor('#1e293b').text(`${COLLEGE.shortName} - ${COLLEGE.department}`, { align: 'center' });
    doc.moveDown(0.2);
    doc.fontSize(13).fillColor('#4338ca').text(title, { align: 'center' });
    if (subtitle) doc.fontSize(9).fillColor('#64748b').text(subtitle, { align: 'center' });
    doc.moveDown(1);

    const startX = doc.x;
    const colWidth = (doc.page.width - 80) / columns.length;

    // Column headers
    doc.fontSize(9).fillColor('#0f172a');
    columns.forEach((c, i) => doc.text(String(c), startX + i * colWidth, doc.y, { width: colWidth, continued: i < columns.length - 1 }));
    doc.moveDown(0.5);
    doc.moveTo(40, doc.y).lineTo(doc.page.width - 40, doc.y).strokeColor('#cbd5e1').stroke();
    doc.moveDown(0.3);

    // Rows
    doc.fillColor('#334155');
    rows.forEach((row) => {
      const y = doc.y;
      row.forEach((cell, i) => doc.text(String(cell ?? ''), startX + i * colWidth, y, { width: colWidth, continued: i < row.length - 1 }));
      doc.moveDown(0.4);
      if (doc.y > doc.page.height - 60) doc.addPage();
    });

    doc.moveDown(1);
    doc.fontSize(8).fillColor('#94a3b8').text(`Generated on ${new Date().toLocaleString()} by SAODMS`, { align: 'right' });
    doc.end();
  });
}

// Build an Excel workbook from a table spec.
async function buildExcel({ title, columns, rows }) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'SAODMS';
  const ws = wb.addWorksheet(title.slice(0, 30) || 'Report');
  ws.addRow([`${COLLEGE.shortName} - ${COLLEGE.department}`]);
  ws.addRow([title]);
  ws.addRow([]);
  const headerRow = ws.addRow(columns);
  headerRow.font = { bold: true };
  headerRow.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4338CA' } };
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  });
  rows.forEach((r) => ws.addRow(r));
  ws.columns.forEach((col) => { col.width = 20; });
  return wb.xlsx.writeBuffer();
}

// Build CSV text from a table spec.
function buildCsv({ columns, rows }) {
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = [columns.map(esc).join(',')];
  rows.forEach((r) => lines.push(r.map(esc).join(',')));
  return Buffer.from(lines.join('\n'), 'utf8');
}

// Dispatch by format.
async function generate(format, spec) {
  if (format === 'pdf') return { buffer: await buildPdf(spec), mime: 'application/pdf', ext: 'pdf' };
  if (format === 'excel') return { buffer: await buildExcel(spec), mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ext: 'xlsx' };
  return { buffer: buildCsv(spec), mime: 'text/csv', ext: 'csv' };
}

module.exports = { generate, buildPdf, buildExcel, buildCsv };
