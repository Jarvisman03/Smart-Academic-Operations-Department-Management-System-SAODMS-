const Attendance = require('../models/Attendance');
const Student = require('../models/Student');
const Settings = require('../models/Settings');
const { DEFAULT_YEAR_RULES } = require('../config/constants');
const { startOfDay, endOfDay, startOfWeek, startOfMonth } = require('../utils/dateUtils');

// Resolve attendance rules for a year (Settings override -> defaults).
async function rulesForYear(year, departmentId) {
  const settings = await Settings.findOne(departmentId ? { department: departmentId } : { scope: 'global' });
  if (settings && settings.attendanceRules && settings.attendanceRules.get(String(year))) {
    return settings.attendanceRules.get(String(year));
  }
  return DEFAULT_YEAR_RULES[year] || { mandatory: true, countsTowardShortage: true };
}

async function thresholds(departmentId) {
  const settings = await Settings.findOne(departmentId ? { department: departmentId } : { scope: 'global' });
  return settings?.thresholds || { minimum: 75, warning: 65, critical: 50 };
}

// Recompute a student's cumulative attendance summary.
// Only sessions where countsTowardShortage=true are included in the percentage.
async function recomputeStudentSummary(studentId) {
  const student = await Student.findById(studentId);
  if (!student) return null;

  const sessions = await Attendance.find({
    'records.student': student._id,
    countsTowardShortage: true,
  }).select('records');

  let total = 0;
  let attended = 0;
  for (const s of sessions) {
    const rec = s.records.find((r) => r.student.toString() === student._id.toString());
    if (!rec) continue;
    total += 1;
    if (rec.status === 'present' || rec.status === 'late') attended += 1;
  }
  const percentage = total ? Math.round((attended / total) * 100) : 0;
  student.attendanceSummary = { totalClasses: total, attended, percentage, updatedAt: new Date() };
  await student.save();
  return student.attendanceSummary;
}

// Recompute summaries for all students in a set of sessions (bulk).
async function recomputeForStudents(studentIds = []) {
  const results = [];
  for (const id of studentIds) {
    // eslint-disable-next-line no-await-in-loop
    results.push(await recomputeStudentSummary(id));
  }
  return results;
}

// Aggregated attendance stats for dashboards.
async function departmentStats(departmentId, date = new Date()) {
  const match = {};
  if (departmentId) match.department = departmentId;

  const [today, week, month] = await Promise.all([
    aggregateRange({ ...match, date: { $gte: startOfDay(date), $lte: endOfDay(date) } }),
    aggregateRange({ ...match, date: { $gte: startOfWeek(date), $lte: endOfDay(date) } }),
    aggregateRange({ ...match, date: { $gte: startOfMonth(date), $lte: endOfDay(date) } }),
  ]);
  return { today, week, month };
}

async function aggregateRange(match) {
  const [row] = await Attendance.aggregate([
    { $match: match },
    {
      $group: {
        _id: null,
        sessions: { $sum: 1 },
        present: { $sum: '$presentCount' },
        absent: { $sum: '$absentCount' },
        total: { $sum: '$totalStudents' },
      },
    },
  ]);
  const present = row?.present || 0;
  const total = row?.total || 0;
  return {
    sessions: row?.sessions || 0,
    present,
    absent: row?.absent || 0,
    total,
    percentage: total ? Math.round((present / total) * 100) : 0,
  };
}

// Analytics grouped by a dimension (subject, section, year).
async function analytics(departmentId, groupBy = 'year', range = {}) {
  const match = {};
  if (departmentId) match.department = departmentId;
  if (range.from || range.to) {
    match.date = {};
    if (range.from) match.date.$gte = new Date(range.from);
    if (range.to) match.date.$lte = new Date(range.to);
  }
  const field = { subject: '$subject', section: '$section', year: '$year' }[groupBy] || '$year';
  const rows = await Attendance.aggregate([
    { $match: match },
    { $group: { _id: field, present: { $sum: '$presentCount' }, total: { $sum: '$totalStudents' }, sessions: { $sum: 1 } } },
    { $sort: { _id: 1 } },
  ]);
  return rows.map((r) => ({
    key: r._id,
    present: r.present,
    total: r.total,
    sessions: r.sessions,
    percentage: r.total ? Math.round((r.present / r.total) * 100) : 0,
  }));
}

// Students below thresholds (excludes years where countsTowardShortage=false naturally,
// because their sessions don't contribute to percentage).
async function lowAttendance(departmentId) {
  const t = await thresholds(departmentId);
  const filter = { isActive: true, 'attendanceSummary.totalClasses': { $gt: 0 } };
  if (departmentId) filter.department = departmentId;
  const students = await Student.find(filter)
    .populate('user', 'name email avatar')
    .populate('section', 'name')
    .sort('attendanceSummary.percentage');

  const buckets = { critical: [], warning: [], below: [] };
  for (const s of students) {
    const p = s.attendanceSummary.percentage;
    if (p < t.critical) buckets.critical.push(s);
    else if (p < t.warning) buckets.warning.push(s);
    else if (p < t.minimum) buckets.below.push(s);
  }
  return { thresholds: t, ...buckets };
}

module.exports = {
  rulesForYear,
  thresholds,
  recomputeStudentSummary,
  recomputeForStudents,
  departmentStats,
  analytics,
  lowAttendance,
};
