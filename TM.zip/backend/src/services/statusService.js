const Timetable = require('../models/Timetable');
const Room = require('../models/Room');
const Faculty = require('../models/Faculty');
const Leave = require('../models/Leave');
const Meeting = require('../models/Meeting');
const ResourceBooking = require('../models/ResourceBooking');
const Attendance = require('../models/Attendance');
const { FACULTY_STATUS, ROOM_STATUS, LEAVE_STATUS } = require('../config/constants');
const { dayName, currentPeriod, startOfDay, endOfDay } = require('../utils/dateUtils');
const { occupiedPeriods } = require('./timetableService');

function statusColor(status) {
  switch (status) {
    case ROOM_STATUS.OCCUPIED: return 'green';
    case ROOM_STATUS.FREE: return 'gray';
    case ROOM_STATUS.RESERVED: return 'yellow';
    case ROOM_STATUS.MAINTENANCE: return 'red';
    default: return 'gray';
  }
}

// Return the timetable entries scheduled for right now (day + period).
async function currentEntries(date = new Date()) {
  const day = dayName(date);
  const period = currentPeriod(date);
  if (!period || period.isBreak) return { entries: [], period, day };
  // Include multi-period classes still running now (occupied periods cover current).
  const dayEntries = await Timetable.find({ day, isActive: true })
    .populate({ path: 'faculty', populate: { path: 'user', select: 'name avatar' } })
    .populate('subject', 'name code')
    .populate('room', 'roomNumber type')
    .populate('section', 'name year');
  const entries = dayEntries.filter((e) => occupiedPeriods(e.period, e.periodSpan).includes(period.period));
  return { entries, period, day };
}

// Compute live status for every room in a building (or all buildings).
async function computeRoomStatuses(buildingId, date = new Date()) {
  const map = {};
  const roomFilter = { isActive: true };
  if (buildingId) roomFilter.building = buildingId;
  const rooms = await Room.find(roomFilter);

  // Base status (maintenance overrides everything).
  for (const r of rooms) {
    map[r._id.toString()] = { status: r.status === ROOM_STATUS.MAINTENANCE ? ROOM_STATUS.MAINTENANCE : ROOM_STATUS.FREE };
  }

  // Occupied by a running class.
  const { entries } = await currentEntries(date);
  for (const e of entries) {
    if (!e.room) continue;
    const key = e.room._id.toString();
    if (map[key] && map[key].status !== ROOM_STATUS.MAINTENANCE) {
      map[key] = {
        status: ROOM_STATUS.OCCUPIED,
        subject: e.subject?.name || e.subjectName,
        faculty: e.faculty?.user?.name,
        section: e.section ? `${e.section.name} (Yr ${e.section.year})` : undefined,
      };
    }
  }

  // Reserved by an approved booking overlapping now.
  const now = date;
  const bookings = await ResourceBooking.find({
    status: 'approved',
    date: { $gte: startOfDay(now), $lte: endOfDay(now) },
  });
  const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  for (const b of bookings) {
    if (b.startTime <= hhmm && hhmm < b.endTime) {
      const key = b.room.toString();
      if (map[key] && map[key].status === ROOM_STATUS.FREE) {
        map[key] = { status: ROOM_STATUS.RESERVED, purpose: b.purpose };
      }
    }
  }

  return map;
}

// Compute live status for all (active) faculty.
async function computeFacultyStatuses(departmentId, date = new Date()) {
  const filter = { isActive: true };
  if (departmentId) filter.department = departmentId;
  const faculties = await Faculty.find(filter).populate('user', 'name avatar');
  const result = {};
  for (const f of faculties) {
    result[f._id.toString()] = { faculty: f, status: FACULTY_STATUS.AVAILABLE, details: {} };
  }

  // On approved leave today?
  const onLeave = await Leave.find({
    status: LEAVE_STATUS.APPROVED,
    fromDate: { $lte: endOfDay(date) },
    toDate: { $gte: startOfDay(date) },
  });
  for (const l of onLeave) {
    if (l.faculty && result[l.faculty.toString()]) result[l.faculty.toString()].status = FACULTY_STATUS.ON_LEAVE;
  }

  // In a meeting right now?
  const now = date;
  const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const meetings = await Meeting.find({
    status: { $in: ['scheduled', 'ongoing'] },
    date: { $gte: startOfDay(now), $lte: endOfDay(now) },
  });
  for (const m of meetings) {
    if (m.startTime && m.endTime && m.startTime <= hhmm && hhmm < m.endTime) {
      for (const a of m.attendees) {
        // attendees are User ids; match by faculty.user
        const fac = faculties.find((f) => f.user && f.user._id.toString() === a.toString());
        if (fac && result[fac._id.toString()].status === FACULTY_STATUS.AVAILABLE) {
          result[fac._id.toString()].status = FACULTY_STATUS.MEETING;
        }
      }
    }
  }

  // Teaching now?
  const { entries, period } = await currentEntries(date);
  for (const e of entries) {
    if (!e.faculty) continue;
    const key = e.faculty._id.toString();
    if (result[key] && result[key].status === FACULTY_STATUS.AVAILABLE) {
      result[key].status = e.type === 'lab' ? FACULTY_STATUS.LAB_DUTY : FACULTY_STATUS.TEACHING;
      result[key].details = {
        room: e.room?.roomNumber || e.roomName,
        subject: e.subject?.name || e.subjectName,
        section: e.section ? `${e.section.name}` : undefined,
        batch: e.section ? `Year ${e.section.year}` : undefined,
        periodLabel: period?.label,
        time: `${e.startTime}-${e.endTime}`,
      };
    }
  }

  return result;
}

// Persist cached snapshots (called by cron / after attendance).
async function refreshCaches(date = new Date()) {
  const facMap = await computeFacultyStatuses(null, date);
  const facultyOps = Object.values(facMap).map((v) => ({
    updateOne: {
      filter: { _id: v.faculty._id },
      update: {
        liveStatus: {
          status: v.status,
          room: v.details.room,
          subject: v.details.subject,
          section: v.details.section,
          batch: v.details.batch,
          periodLabel: v.details.periodLabel,
          updatedAt: new Date(),
        },
      },
    },
  }));
  if (facultyOps.length) await Faculty.bulkWrite(facultyOps);

  const roomMap = await computeRoomStatuses(null, date);
  const roomOps = Object.entries(roomMap).map(([id, v]) => ({
    updateOne: {
      filter: { _id: id },
      update: { liveStatus: { status: v.status, subject: v.subject, faculty: v.faculty, section: v.section, updatedAt: new Date() } },
    },
  }));
  if (roomOps.length) await Room.bulkWrite(roomOps);

  return { faculty: facMap, rooms: roomMap };
}

// Running classes right now with attendance progress if marked.
async function runningClasses(date = new Date()) {
  const { entries, period } = await currentEntries(date);
  const results = [];
  for (const e of entries) {
    // eslint-disable-next-line no-await-in-loop
    const att = await Attendance.findOne({
      section: e.section?._id,
      subject: e.subject?._id,
      period: e.period,
      date: { $gte: startOfDay(date), $lte: endOfDay(date) },
    });
    results.push({
      timetableId: e._id,
      room: e.room?.roomNumber || e.roomName,
      roomType: e.room?.type,
      subject: e.subject?.name || e.subjectName,
      faculty: e.faculty?.user?.name,
      section: e.section?.name,
      year: e.section?.year,
      time: `${e.startTime}-${e.endTime}`,
      period: period.label,
      type: e.type,
      attendanceMarked: Boolean(att),
      present: att ? att.presentCount : null,
      absent: att ? att.absentCount : null,
      total: att ? att.totalStudents : null,
    });
  }
  return results;
}

module.exports = {
  statusColor,
  currentEntries,
  computeRoomStatuses,
  computeFacultyStatuses,
  refreshCaches,
  runningClasses,
};
