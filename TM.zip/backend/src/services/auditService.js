const AuditLog = require('../models/AuditLog');

// Fire-and-forget audit logging. Never blocks the request flow.
async function log(req, { action, entity, entityId, description, meta, status = 'success' }) {
  try {
    await AuditLog.create({
      actor: req.user ? req.user._id : undefined,
      actorRole: req.user ? req.user.role : undefined,
      action,
      entity,
      entityId,
      description,
      meta,
      status,
      ip: req.ip,
      userAgent: req.headers ? req.headers['user-agent'] : undefined,
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('[AUDIT] failed to write log:', err.message);
  }
}

module.exports = { log };
