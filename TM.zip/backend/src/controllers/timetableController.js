const Timetable = require('../models/Timetable');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const timetableService = require('../services/timetableService');
const substituteService = require('../services/substituteService');
const auditService = require('../services/auditService');

exports.list = asyncHandler(async (req, res) => {
  const filter = { isActive: true };
  if (req.query.section) filter.section = req.query.section;
  if (req.query.faculty) filter.faculty = req.query.faculty;
  if (req.query.room) filter.room = req.query.room;
  if (req.query.day) filter.day = req.query.day;
  const items = await Timetable.find(filter)
    .populate({ path: 'faculty', populate: { path: 'user', select: 'name' } })
    .populate('subject', 'name code')
    .populate('room', 'roomNumber')
    .populate('section', 'name year')
    .sort('day period');
  return success(res, { data: items });
});

exports.weekly = asyncHandler(async (req, res) => {
  const data = await timetableService.weeklyGrid(req.params.sectionId);
  return success(res, { data });
});

// Weekly grid for a single faculty member.
exports.facultyWeekly = asyncHandler(async (req, res) => {
  const data = await timetableService.facultyGrid(req.params.facultyId);
  return success(res, { data });
});

// Weekly grid for a single room.
exports.roomWeekly = asyncHandler(async (req, res) => {
  const data = await timetableService.roomGrid(req.params.roomId);
  return success(res, { data });
});

// The logged-in faculty member's own weekly grid.
exports.myWeekly = asyncHandler(async (req, res) => {
  const Faculty = require('../models/Faculty');
  const faculty = await Faculty.findOne({ user: req.user._id });
  if (!faculty) throw new ApiError(404, 'No faculty profile linked to your account');
  const data = await timetableService.facultyGrid(faculty._id);
  return success(res, { data: { ...data, facultyId: faculty._id } });
});

exports.checkConflict = asyncHandler(async (req, res) => {
  const conflicts = await timetableService.detectConflicts(req.body);
  return success(res, { data: { hasConflict: conflicts.length > 0, conflicts } });
});

exports.create = asyncHandler(async (req, res) => {
  const entry = await timetableService.createEntry(req.body);
  await auditService.log(req, { action: 'timetable.create', entity: 'Timetable', entityId: entry._id });
  const io = req.app.get('io');
  if (io) io.of('/dashboard').emit('timetable:change', { action: 'create', entryId: entry._id, section: entry.section });
  return created(res, { data: entry, message: 'Timetable entry created' });
});

exports.update = asyncHandler(async (req, res) => {
  const entry = await timetableService.updateEntry(req.params.id, req.body);
  if (!entry) throw new ApiError(404, 'Timetable entry not found');
  await auditService.log(req, { action: 'timetable.update', entity: 'Timetable', entityId: entry._id });
  const io = req.app.get('io');
  if (io) io.of('/dashboard').emit('timetable:change', { action: 'update', entryId: entry._id, section: entry.section });
  return success(res, { data: entry, message: 'Timetable entry updated' });
});

exports.remove = asyncHandler(async (req, res) => {
  const entry = await Timetable.findByIdAndDelete(req.params.id);
  if (!entry) throw new ApiError(404, 'Timetable entry not found');
  await auditService.log(req, { action: 'timetable.delete', entity: 'Timetable', entityId: entry._id });
  const io = req.app.get('io');
  if (io) io.of('/dashboard').emit('timetable:change', { action: 'delete', entryId: entry._id, section: entry.section });
  return success(res, { message: 'Timetable entry deleted' });
});

exports.generate = asyncHandler(async (req, res) => {
  const result = await timetableService.generateForSection(req.body.section, { clearExisting: req.body.clearExisting });
  await auditService.log(req, { action: 'timetable.generate', entity: 'Section', entityId: req.body.section, meta: result });
  return success(res, { data: result, message: 'Timetable generated' });
});

// Substitute suggestions for an entry on a date.
exports.substitutes = asyncHandler(async (req, res) => {
  const data = await substituteService.suggestSubstitutes(req.params.id, req.query.date ? new Date(req.query.date) : new Date());
  return success(res, { data });
});

// Apply a substitution / cancellation for a specific date.
exports.applySubstitution = asyncHandler(async (req, res) => {
  const { date, substituteFaculty, room, reason, cancelled } = req.body;
  const entry = await Timetable.findById(req.params.id);
  if (!entry) throw new ApiError(404, 'Timetable entry not found');
  entry.substitutions.push({ date, originalFaculty: entry.faculty, substituteFaculty, room, reason, cancelled });
  await entry.save();
  await auditService.log(req, { action: cancelled ? 'timetable.cancel_class' : 'timetable.substitute', entity: 'Timetable', entityId: entry._id });
  const io = req.app.get('io');
  if (io) {
    io.of('/dashboard').emit('timetable:change', { action: cancelled ? 'cancel' : 'substitute', entryId: entry._id });
  }
  return success(res, { data: entry, message: cancelled ? 'Class cancelled' : 'Substitution applied' });
});
