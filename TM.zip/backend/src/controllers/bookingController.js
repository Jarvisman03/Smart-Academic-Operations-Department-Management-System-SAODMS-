const ResourceBooking = require('../models/ResourceBooking');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { startOfDay, endOfDay } = require('../utils/dateUtils');
const auditService = require('../services/auditService');

// Check overlap for a room/date/time window.
async function hasOverlap({ room, date, startTime, endTime, excludeId }) {
  const filter = {
    room,
    status: { $in: ['approved', 'pending'] },
    date: { $gte: startOfDay(new Date(date)), $lte: endOfDay(new Date(date)) },
  };
  if (excludeId) filter._id = { $ne: excludeId };
  const bookings = await ResourceBooking.find(filter);
  return bookings.some((b) => startTime < b.endTime && endTime > b.startTime);
}

exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.room) filter.room = req.query.room;
  if (req.query.status) filter.status = req.query.status;
  if (req.query.date) filter.date = { $gte: startOfDay(new Date(req.query.date)), $lte: endOfDay(new Date(req.query.date)) };
  const items = await ResourceBooking.find(filter)
    .populate('room', 'roomNumber type')
    .populate('bookedBy', 'name role')
    .sort('-date startTime');
  return success(res, { data: items });
});

exports.create = asyncHandler(async (req, res) => {
  const overlap = await hasOverlap(req.body);
  if (overlap) throw new ApiError(409, 'Room already booked for this time window');
  const booking = await ResourceBooking.create({ ...req.body, bookedBy: req.user._id });
  await auditService.log(req, { action: 'booking.create', entity: 'ResourceBooking', entityId: booking._id });
  const io = req.app.get('io');
  if (io) io.of('/dashboard').emit('room:status', { roomId: booking.room, status: 'reserved' });
  return created(res, { data: booking, message: 'Booking created' });
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const booking = await ResourceBooking.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status, approvedBy: req.user._id },
    { new: true }
  );
  if (!booking) throw new ApiError(404, 'Booking not found');
  await auditService.log(req, { action: 'booking.status', entity: 'ResourceBooking', entityId: booking._id, meta: { status: req.body.status } });
  return success(res, { data: booking, message: 'Booking updated' });
});

exports.remove = asyncHandler(async (req, res) => {
  const booking = await ResourceBooking.findByIdAndUpdate(req.params.id, { status: 'cancelled' }, { new: true });
  if (!booking) throw new ApiError(404, 'Booking not found');
  return success(res, { message: 'Booking cancelled' });
});
