const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const auditService = require('../services/auditService');

// Generates standard CRUD handlers for a Mongoose model.
// options: { populate, searchFields, filterFields, defaultFilter, entity }
function crudFactory(Model, options = {}) {
  const {
    populate = '',
    searchFields = [],
    filterFields = [],
    entity = Model.modelName,
  } = options;

  const list = asyncHandler(async (req, res) => {
    const { page, limit, skip, sort } = parsePagination(req.query);
    const filter = {};

    // Exact-match filters from allowed fields.
    for (const f of filterFields) {
      if (req.query[f] !== undefined && req.query[f] !== '') filter[f] = req.query[f];
    }
    // Text search across configured fields.
    if (req.query.search && searchFields.length) {
      filter.$or = searchFields.map((f) => ({ [f]: { $regex: req.query.search, $options: 'i' } }));
    }
    // Optional department scoping when provided.
    if (req.query.department) filter.department = req.query.department;

    const [items, total] = await Promise.all([
      Model.find(filter).populate(populate).sort(sort).skip(skip).limit(limit),
      Model.countDocuments(filter),
    ]);
    return success(res, { data: items, meta: buildMeta(page, limit, total) });
  });

  const getOne = asyncHandler(async (req, res) => {
    const item = await Model.findById(req.params.id).populate(populate);
    if (!item) throw new ApiError(404, `${entity} not found`);
    return success(res, { data: item });
  });

  const createOne = asyncHandler(async (req, res) => {
    const item = await Model.create(req.body);
    await auditService.log(req, { action: `${entity.toLowerCase()}.create`, entity, entityId: item._id });
    return created(res, { data: item, message: `${entity} created` });
  });

  const updateOne = asyncHandler(async (req, res) => {
    const item = await Model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }).populate(populate);
    if (!item) throw new ApiError(404, `${entity} not found`);
    await auditService.log(req, { action: `${entity.toLowerCase()}.update`, entity, entityId: item._id });
    return success(res, { data: item, message: `${entity} updated` });
  });

  const removeOne = asyncHandler(async (req, res) => {
    const item = await Model.findByIdAndDelete(req.params.id);
    if (!item) throw new ApiError(404, `${entity} not found`);
    await auditService.log(req, { action: `${entity.toLowerCase()}.delete`, entity, entityId: item._id });
    return success(res, { message: `${entity} deleted` });
  });

  return { list, getOne, createOne, updateOne, removeOne };
}

module.exports = crudFactory;
