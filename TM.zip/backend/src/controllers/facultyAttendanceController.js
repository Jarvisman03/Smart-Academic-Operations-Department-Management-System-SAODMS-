const FacultyAttendance = require('../models/FacultyAttendance');
const Faculty = require('../models/Faculty');
const asyncHandler = require('../utils/asyncHandler');
const { success, ApiError } = require('../utils/apiResponse');
const { startOfDay, endOfDay, toMinutes } = require('../utils/dateUtils');
const auditService = require('../services/auditService');
const Settings = require('../models/Settings');

// Faculty check-in.
exports.checkIn = asyncHandler(async (req, res) => {
  const { facultyId, method = 'manual', location } = req.body;
  const faculty = await Faculty.findById(facultyId);
  if (!faculty) throw new ApiError(404, 'Faculty not found');

  const now = new Date();
  const filter = { faculty: facultyId, date: { $gte: startOfDay(now), $lte: endOfDay(now) } };
  let record = await FacultyAttendance.findOne(filter);
  if (record && record.checkIn) throw new ApiError(409, 'Already checked in today');

  const settings = await Settings.findOne({ scope: 'global' });
  const lateThreshold = settings?.lateThresholdMinutes || 10;
  const startMins = toMinutes(settings?.college?.startTime || '08:30');
  const nowMins = now.getHours() * 60 + now.getMinutes();
  const lateBy = Math.max(0, nowMins - startMins - lateThreshold);

  if (!record) {
    record = new FacultyAttendance({ faculty: facultyId, department: faculty.department, date: now });
  }
  record.checkIn = now;
  record.method = method;
  record.location = location;
  record.status = lateBy > 0 ? 'late' : 'present';
  record.lateByMinutes = lateBy;
  await record.save();
  await auditService.log(req, { action: 'faculty_attendance.checkin', entity: 'FacultyAttendance', entityId: record._id });
  return success(res, { data: record, message: 'Checked in' });
});

// Faculty check-out.
exports.checkOut = asyncHandler(async (req, res) => {
  const { facultyId } = req.body;
  const now = new Date();
  const record = await FacultyAttendance.findOne({ faculty: facultyId, date: { $gte: startOfDay(now), $lte: endOfDay(now) } });
  if (!record || !record.checkIn) throw new ApiError(400, 'No check-in found for today');
  record.checkOut = now;
  record.workedMinutes = Math.round((now - record.checkIn) / 60000);
  await record.save();
  return success(res, { data: record, message: 'Checked out' });
});

exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.department) filter.department = req.query.department;
  if (req.query.faculty) filter.faculty = req.query.faculty;
  if (req.query.date) {
    filter.date = { $gte: startOfDay(new Date(req.query.date)), $lte: endOfDay(new Date(req.query.date)) };
  }
  const items = await FacultyAttendance.find(filter)
    .populate({ path: 'faculty', populate: { path: 'user', select: 'name avatar' } })
    .sort('-date');
  return success(res, { data: items });
});

// Today snapshot: present/absent counts for dashboard.
exports.today = asyncHandler(async (req, res) => {
  const now = new Date();
  const filter = { date: { $gte: startOfDay(now), $lte: endOfDay(now) } };
  if (req.query.department) filter.department = req.query.department;
  const [records, totalFaculty] = await Promise.all([
    FacultyAttendance.find(filter),
    Faculty.countDocuments({ isActive: true, ...(req.query.department && { department: req.query.department }) }),
  ]);
  const present = records.filter((r) => ['present', 'late', 'half_day'].includes(r.status)).length;
  return success(res, {
    data: {
      totalFaculty,
      present,
      absent: totalFaculty - present,
      late: records.filter((r) => r.status === 'late').length,
      onLeave: records.filter((r) => r.status === 'on_leave').length,
    },
  });
});
