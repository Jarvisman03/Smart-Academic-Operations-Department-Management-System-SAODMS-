const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const auditService = require('../services/auditService');

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip, sort } = parsePagination(req.query);
  const filter = {};
  if (req.query.role) filter.role = req.query.role;
  if (req.query.department) filter.department = req.query.department;
  if (req.query.isActive !== undefined) filter.isActive = req.query.isActive === 'true';
  if (req.query.search) {
    filter.$or = [
      { name: { $regex: req.query.search, $options: 'i' } },
      { email: { $regex: req.query.search, $options: 'i' } },
    ];
  }
  const [items, total] = await Promise.all([
    User.find(filter).populate('department', 'name code').sort(sort).skip(skip).limit(limit),
    User.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
});

exports.getOne = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id).populate('department', 'name code');
  if (!user) throw new ApiError(404, 'User not found');
  return success(res, { data: user });
});

exports.create = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const exists = await User.findOne({ email: email.toLowerCase() });
  if (exists) throw new ApiError(409, 'Email already registered');
  const user = await User.create(req.body);
  await auditService.log(req, { action: 'user.create', entity: 'User', entityId: user._id });
  return created(res, { data: user.toSafeJSON(), message: 'User created' });
});

exports.update = asyncHandler(async (req, res) => {
  const payload = { ...req.body };
  delete payload.password; // password changes go through dedicated flow
  const user = await User.findByIdAndUpdate(req.params.id, payload, { new: true, runValidators: true });
  if (!user) throw new ApiError(404, 'User not found');
  await auditService.log(req, { action: 'user.update', entity: 'User', entityId: user._id });
  return success(res, { data: user, message: 'User updated' });
});

exports.setActive = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndUpdate(req.params.id, { isActive: req.body.isActive }, { new: true });
  if (!user) throw new ApiError(404, 'User not found');
  await auditService.log(req, { action: 'user.set_active', entity: 'User', entityId: user._id, meta: { isActive: req.body.isActive } });
  return success(res, { data: user, message: `User ${req.body.isActive ? 'activated' : 'deactivated'}` });
});

exports.resetPassword = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, 'User not found');
  user.password = req.body.newPassword;
  user.refreshTokens = [];
  await user.save();
  await auditService.log(req, { action: 'user.reset_password', entity: 'User', entityId: user._id });
  return success(res, { message: 'Password reset' });
});

exports.remove = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) throw new ApiError(404, 'User not found');
  await auditService.log(req, { action: 'user.delete', entity: 'User', entityId: user._id });
  return success(res, { message: 'User deleted' });
});
