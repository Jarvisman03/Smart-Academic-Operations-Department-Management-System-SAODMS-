const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Faculty = require('../models/Faculty');
const Student = require('../models/Student');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const { permissionsForRole } = require('../config/permissions');
const auditService = require('../services/auditService');
const env = require('../config/env');

const cookieOpts = {
  httpOnly: true,
  secure: env.nodeEnv === 'production',
  sameSite: 'lax',
  maxAge: 7 * 24 * 60 * 60 * 1000,
};

async function issueTokens(user) {
  const payload = { sub: user._id.toString(), role: user.role };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);
  const hashed = await bcrypt.hash(refreshToken, 10);
  user.refreshTokens.push({ token: hashed });
  // Cap stored sessions to the 5 most recent.
  if (user.refreshTokens.length > 5) user.refreshTokens = user.refreshTokens.slice(-5);
  user.lastLogin = new Date();
  await user.save();
  return { accessToken, refreshToken };
}

// Attach the role-specific profile (faculty/student) to the response.
async function attachProfile(user) {
  const base = user.toSafeJSON();
  base.permissions = permissionsForRole(user.role);
  if (['faculty', 'hod', 'co_hod', 'dean', 'lab_assistant'].includes(user.role)) {
    base.facultyProfile = await Faculty.findOne({ user: user._id }).populate('expertise', 'name code');
  }
  if (user.role === 'student') {
    base.studentProfile = await Student.findOne({ user: user._id }).populate('section', 'name year');
  }
  return base;
}

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password, role, phone, department } = req.body;
  const exists = await User.findOne({ email: email.toLowerCase() });
  if (exists) throw new ApiError(409, 'Email already registered');

  const user = await User.create({ name, email, password, role, phone, department });
  await auditService.log(req, { action: 'user.register', entity: 'User', entityId: user._id, description: `Registered ${email}` });
  return created(res, { data: user.toSafeJSON(), message: 'Account created' });
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user) throw new ApiError(401, 'Invalid credentials');
  if (!user.isActive) throw new ApiError(403, 'Account is deactivated');

  const match = await user.comparePassword(password);
  if (!match) {
    await auditService.log(req, { action: 'auth.login', description: `Failed login ${email}`, status: 'failure' });
    throw new ApiError(401, 'Invalid credentials');
  }

  const { accessToken, refreshToken } = await issueTokens(user);
  res.cookie('refreshToken', refreshToken, cookieOpts);
  await auditService.log(req, { action: 'auth.login', entity: 'User', entityId: user._id, description: `Login ${email}` });

  const profile = await attachProfile(user);
  return success(res, { data: { user: profile, accessToken, refreshToken }, message: 'Login successful' });
});

exports.refresh = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken || req.body.refreshToken;
  if (!token) throw new ApiError(401, 'Refresh token required');

  let decoded;
  try {
    decoded = verifyRefreshToken(token);
  } catch (e) {
    throw new ApiError(401, 'Invalid refresh token');
  }

  const user = await User.findById(decoded.sub).select('+refreshTokens');
  if (!user) throw new ApiError(401, 'User not found');

  // Verify the presented token matches a stored hashed token.
  let valid = false;
  for (const rt of user.refreshTokens) {
    // eslint-disable-next-line no-await-in-loop
    if (await bcrypt.compare(token, rt.token)) { valid = true; break; }
  }
  if (!valid) throw new ApiError(401, 'Refresh token revoked');

  const accessToken = signAccessToken({ sub: user._id.toString(), role: user.role });
  return success(res, { data: { accessToken }, message: 'Token refreshed' });
});

exports.logout = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken || req.body.refreshToken;
  if (token && req.user) {
    const user = await User.findById(req.user._id).select('+refreshTokens');
    if (user) {
      const kept = [];
      for (const rt of user.refreshTokens) {
        // eslint-disable-next-line no-await-in-loop
        const same = await bcrypt.compare(token, rt.token);
        if (!same) kept.push(rt);
      }
      user.refreshTokens = kept;
      await user.save();
    }
  }
  res.clearCookie('refreshToken');
  return success(res, { message: 'Logged out' });
});

exports.me = asyncHandler(async (req, res) => {
  const profile = await attachProfile(req.user);
  return success(res, { data: profile });
});

exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user._id).select('+password');
  const match = await user.comparePassword(currentPassword);
  if (!match) throw new ApiError(400, 'Current password is incorrect');
  user.password = newPassword;
  user.refreshTokens = []; // force re-login on all devices
  await user.save();
  await auditService.log(req, { action: 'auth.change_password', entity: 'User', entityId: user._id });
  return success(res, { message: 'Password updated. Please log in again.' });
});

exports.updateProfile = asyncHandler(async (req, res) => {
  const { name, phone, avatar, fcmToken } = req.body;
  const user = await User.findById(req.user._id);
  if (name) user.name = name;
  if (phone) user.phone = phone;
  if (avatar) user.avatar = avatar;
  if (fcmToken) user.fcmToken = fcmToken;
  await user.save();
  return success(res, { data: user.toSafeJSON(), message: 'Profile updated' });
});
