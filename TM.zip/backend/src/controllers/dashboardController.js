const Faculty = require('../models/Faculty');
const Room = require('../models/Room');
const Lab = require('../models/Lab');
const Leave = require('../models/Leave');
const Meeting = require('../models/Meeting');
const FacultyAttendance = require('../models/FacultyAttendance');
const Student = require('../models/Student');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const statusService = require('../services/statusService');
const attendanceService = require('../services/attendanceService');
const { FACULTY_STATUS, ROOM_STATUS, COLLEGE, PERIODS } = require('../config/constants');
const { currentPeriod, dayName, startOfDay, endOfDay } = require('../utils/dateUtils');

// Quick statistics block (Dashboard Section 3).
exports.overview = asyncHandler(async (req, res) => {
  const dept = req.query.department;
  const now = new Date();

  const [facStatuses, roomMap, facAttToday, students, pendingLeaves, upcomingMeetings, attStats] = await Promise.all([
    statusService.computeFacultyStatuses(dept, now),
    statusService.computeRoomStatuses(dept, now),
    FacultyAttendance.find({ date: { $gte: startOfDay(now), $lte: endOfDay(now) }, ...(dept && { department: dept }) }),
    Student.countDocuments({ isActive: true, ...(dept && { department: dept }) }),
    Leave.countDocuments({ status: 'pending', ...(dept && { department: dept }) }),
    Meeting.find({ date: { $gte: now }, status: 'scheduled', ...(dept && { department: dept }) }).sort('date').limit(5).populate('organizer', 'name'),
    attendanceService.departmentStats(dept, now),
  ]);

  const facValues = Object.values(facStatuses);
  const roomValues = Object.values(roomMap);
  const period = currentPeriod(now);

  const facultyPresent = facAttToday.filter((f) => ['present', 'late', 'half_day'].includes(f.status)).length;

  const stats = {
    studentsTotal: students,
    studentsPresent: attStats.today.present,
    studentsAbsent: attStats.today.absent,
    facultyPresent,
    facultyAbsent: facValues.length - facultyPresent,
    classesRunning: facValues.filter((f) => f.status === FACULTY_STATUS.TEACHING || f.status === FACULTY_STATUS.LAB_DUTY).length,
    labsOccupied: roomValues.filter((r) => r.status === ROOM_STATUS.OCCUPIED).length, // approximate
    labsAvailable: roomValues.filter((r) => r.status === ROOM_STATUS.FREE).length,
    freeFaculty: facValues.filter((f) => f.status === FACULTY_STATUS.AVAILABLE).length,
    roomsAvailable: roomValues.filter((r) => r.status === ROOM_STATUS.FREE).length,
    roomsOccupied: roomValues.filter((r) => r.status === ROOM_STATUS.OCCUPIED).length,
    pendingLeaves,
    upcomingMeetingsCount: upcomingMeetings.length,
  };

  return success(res, {
    data: {
      college: COLLEGE,
      now,
      day: dayName(now),
      currentPeriod: period,
      periods: PERIODS,
      stats,
      upcomingMeetings,
      attendance: attStats,
    },
  });
});

// Live faculty monitoring (Dashboard Section 4 & 8).
exports.facultyMonitor = asyncHandler(async (req, res) => {
  const map = await statusService.computeFacultyStatuses(req.query.department, new Date());
  const cards = Object.values(map).map((v) => ({
    id: v.faculty._id,
    name: v.faculty.user?.name,
    avatar: v.faculty.user?.avatar,
    designation: v.faculty.designation,
    cabin: v.faculty.cabin,
    status: v.status,
    ...v.details,
  }));

  const availability = {
    available: cards.filter((c) => c.status === FACULTY_STATUS.AVAILABLE),
    teaching: cards.filter((c) => c.status === FACULTY_STATUS.TEACHING || c.status === FACULTY_STATUS.LAB_DUTY),
    meeting: cards.filter((c) => c.status === FACULTY_STATUS.MEETING),
    onLeave: cards.filter((c) => c.status === FACULTY_STATUS.ON_LEAVE),
  };

  return success(res, { data: { cards, availability } });
});

// Running classes (Dashboard Section 5).
exports.running = asyncHandler(async (req, res) => {
  const data = await statusService.runningClasses(new Date());
  return success(res, { data });
});

// Lab monitoring (Dashboard Section 6).
exports.labMonitor = asyncHandler(async (req, res) => {
  const now = new Date();
  const roomMap = await statusService.computeRoomStatuses(req.query.department, now);
  const labs = await Lab.find().populate('room', 'roomNumber capacity floorNumber').populate({ path: 'labInCharge', populate: { path: 'user', select: 'name' } });
  const cards = labs.map((lab) => {
    const live = lab.room ? roomMap[lab.room._id.toString()] : null;
    return {
      id: lab._id,
      name: lab.name,
      roomNumber: lab.room?.roomNumber,
      capacity: lab.room?.capacity,
      systems: lab.systemsCount,
      workingSystems: lab.workingSystems,
      equipmentStatus: lab.equipmentStatus,
      inCharge: lab.labInCharge?.user?.name,
      status: live ? live.status : 'free',
      subject: live?.subject,
      faculty: live?.faculty,
      section: live?.section,
    };
  });
  return success(res, { data: cards });
});

// Attendance dashboard + analytics summary (Sections 10-12).
exports.attendanceSummary = asyncHandler(async (req, res) => {
  const dept = req.query.department;
  const [stats, byYear, bySection, low, facToday] = await Promise.all([
    attendanceService.departmentStats(dept, new Date()),
    attendanceService.analytics(dept, 'year'),
    attendanceService.analytics(dept, 'section'),
    attendanceService.lowAttendance(dept),
    (async () => {
      const now = new Date();
      const recs = await FacultyAttendance.find({ date: { $gte: startOfDay(now), $lte: endOfDay(now) }, ...(dept && { department: dept }) });
      const totalFaculty = await Faculty.countDocuments({ isActive: true, ...(dept && { department: dept }) });
      const present = recs.filter((r) => ['present', 'late', 'half_day'].includes(r.status)).length;
      return { totalFaculty, present, absent: totalFaculty - present };
    })(),
  ]);
  return success(res, {
    data: {
      student: stats,
      byYear,
      bySection,
      lowAttendance: {
        thresholds: low.thresholds,
        critical: low.critical.length,
        warning: low.warning.length,
        below: low.below.length,
        criticalList: low.critical.slice(0, 10),
      },
      faculty: facToday,
    },
  });
});
