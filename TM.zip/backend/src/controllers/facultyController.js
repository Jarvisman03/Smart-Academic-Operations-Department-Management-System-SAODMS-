const mongoose = require('mongoose');
const User = require('../models/User');
const Faculty = require('../models/Faculty');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const auditService = require('../services/auditService');
const env = require('../config/env');

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip, sort } = parsePagination(req.query);
  const filter = { isActive: req.query.isActive !== undefined ? req.query.isActive === 'true' : true };
  if (req.query.department) filter.department = req.query.department;
  if (req.query.designation) filter.designation = req.query.designation;

  let query = Faculty.find(filter)
    .populate('user', 'name email avatar phone role')
    .populate('expertise', 'name code')
    .sort(sort);

  if (req.query.search) {
    // Search via linked users.
    const users = await User.find({ name: { $regex: req.query.search, $options: 'i' } }).select('_id');
    filter.user = { $in: users.map((u) => u._id) };
    query = Faculty.find(filter).populate('user', 'name email avatar phone role').populate('expertise', 'name code').sort(sort);
  }

  const [items, total] = await Promise.all([
    query.skip(skip).limit(limit),
    Faculty.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
});

exports.getOne = asyncHandler(async (req, res) => {
  const faculty = await Faculty.findById(req.params.id)
    .populate('user', 'name email avatar phone role')
    .populate('expertise', 'name code')
    .populate('department', 'name code');
  if (!faculty) throw new ApiError(404, 'Faculty not found');
  return success(res, { data: faculty });
});

// Create User account + Faculty profile together.
exports.create = asyncHandler(async (req, res) => {
  const { name, email, phone, password, role = 'faculty', department, ...facultyData } = req.body;
  const exists = await User.findOne({ email: email.toLowerCase() });
  if (exists) throw new ApiError(409, 'Email already registered');

  const session = await mongoose.startSession();
  let faculty;
  try {
    await session.withTransaction(async () => {
      const [user] = await User.create([{ name, email, phone, password: password || env.seedDefaultPassword, role, department }], { session });
      [faculty] = await Faculty.create([{ ...facultyData, user: user._id, department }], { session });
    });
  } finally {
    session.endSession();
  }
  faculty = await Faculty.findById(faculty._id).populate('user', 'name email avatar role');
  await auditService.log(req, { action: 'faculty.create', entity: 'Faculty', entityId: faculty._id });
  return created(res, { data: faculty, message: 'Faculty created' });
});

exports.update = asyncHandler(async (req, res) => {
  const { name, phone, avatar, ...facultyData } = req.body;
  const faculty = await Faculty.findByIdAndUpdate(req.params.id, facultyData, { new: true, runValidators: true }).populate('user', 'name email');
  if (!faculty) throw new ApiError(404, 'Faculty not found');
  if (name || phone || avatar) {
    await User.findByIdAndUpdate(faculty.user._id, { ...(name && { name }), ...(phone && { phone }), ...(avatar && { avatar }) });
  }
  await auditService.log(req, { action: 'faculty.update', entity: 'Faculty', entityId: faculty._id });
  return success(res, { data: faculty, message: 'Faculty updated' });
});

exports.remove = asyncHandler(async (req, res) => {
  const faculty = await Faculty.findById(req.params.id);
  if (!faculty) throw new ApiError(404, 'Faculty not found');
  await Faculty.findByIdAndUpdate(faculty._id, { isActive: false });
  await User.findByIdAndUpdate(faculty.user, { isActive: false });
  await auditService.log(req, { action: 'faculty.deactivate', entity: 'Faculty', entityId: faculty._id });
  return success(res, { message: 'Faculty deactivated' });
});
