const Attendance = require('../models/Attendance');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Section = require('../models/Section');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const { startOfDay, endOfDay } = require('../utils/dateUtils');
const attendanceService = require('../services/attendanceService');
const auditService = require('../services/auditService');
const { generateQrToken, parseQrToken, toDataURL } = require('../utils/qr');
const { ATTENDANCE_STATUS } = require('../config/constants');

// Roster for a section (to pre-fill a marking sheet).
exports.roster = asyncHandler(async (req, res) => {
  const { sectionId } = req.params;
  const students = await Student.find({ section: sectionId, isActive: true })
    .populate('user', 'name avatar')
    .sort('rollNo');
  return success(res, { data: students });
});

// Mark / upsert an attendance session.
exports.mark = asyncHandler(async (req, res) => {
  const {
    section, subject, faculty, room, date, period, method = 'manual',
    records = [], timetableEntry, location, year,
  } = req.body;

  const sec = await Section.findById(section);
  if (!sec) throw new ApiError(404, 'Section not found');
  const effYear = year || sec.year;
  const rule = await attendanceService.rulesForYear(effYear, sec.department);

  const day = startOfDay(new Date(date));
  const filter = { section, subject, date: { $gte: day, $lte: endOfDay(new Date(date)) }, period };

  let attendance = await Attendance.findOne(filter);
  const payload = {
    department: sec.department,
    section,
    year: effYear,
    subject,
    faculty,
    room,
    timetableEntry,
    date: new Date(date),
    period,
    method,
    records,
    location,
    countsTowardShortage: rule.countsTowardShortage,
    approvalStatus: 'submitted',
  };

  if (attendance) {
    Object.assign(attendance, payload);
  } else {
    attendance = new Attendance(payload);
  }
  await attendance.save();

  // Recompute summaries for affected students.
  const studentIds = records.map((r) => r.student);
  await attendanceService.recomputeForStudents(studentIds);

  await auditService.log(req, { action: 'attendance.mark', entity: 'Attendance', entityId: attendance._id, meta: { section, subject, period } });

  // Realtime broadcast.
  const io = req.app.get('io');
  if (io) {
    io.of('/dashboard').emit('attendance:update', {
      attendanceId: attendance._id,
      section,
      subject,
      present: attendance.presentCount,
      absent: attendance.absentCount,
      total: attendance.totalStudents,
    });
  }

  return created(res, { data: attendance, message: 'Attendance recorded' });
});

// Generate a QR token for a class session (faculty displays it).
exports.generateQr = asyncHandler(async (req, res) => {
  const { section, subject, period, faculty } = req.body;
  const token = generateQrToken({ section, subject, period, faculty }, 300);
  const dataUrl = await toDataURL(token);
  return success(res, { data: { token, qrImage: dataUrl, expiresInSeconds: 300 } });
});

// Student marks own presence by scanning QR.
exports.scanQr = asyncHandler(async (req, res) => {
  const { token, studentId, location } = req.body;
  const parsed = parseQrToken(token);
  if (!parsed.valid) throw new ApiError(400, `QR ${parsed.reason}`);
  const { section, subject, period, faculty } = parsed.data;

  const sec = await Section.findById(section);
  const rule = await attendanceService.rulesForYear(sec.year, sec.department);

  const now = new Date();
  const filter = { section, subject, date: { $gte: startOfDay(now), $lte: endOfDay(now) }, period };
  let attendance = await Attendance.findOne(filter);
  if (!attendance) {
    attendance = new Attendance({
      department: sec.department, section, year: sec.year, subject, faculty, date: now, period,
      method: 'qr', records: [], countsTowardShortage: rule.countsTowardShortage, location,
    });
  }
  const existing = attendance.records.find((r) => r.student.toString() === studentId);
  if (existing) existing.status = ATTENDANCE_STATUS.PRESENT;
  else attendance.records.push({ student: studentId, status: ATTENDANCE_STATUS.PRESENT });
  attendance.method = 'qr';
  await attendance.save();
  await attendanceService.recomputeStudentSummary(studentId);

  const io = req.app.get('io');
  if (io) io.of('/dashboard').emit('attendance:update', { attendanceId: attendance._id, section, subject });

  return success(res, { message: 'Marked present via QR' });
});

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip, sort } = parsePagination(req.query);
  const filter = {};
  if (req.query.department) filter.department = req.query.department;
  if (req.query.section) filter.section = req.query.section;
  if (req.query.subject) filter.subject = req.query.subject;
  if (req.query.faculty) filter.faculty = req.query.faculty;
  if (req.query.year) filter.year = Number(req.query.year);
  if (req.query.date) {
    filter.date = { $gte: startOfDay(new Date(req.query.date)), $lte: endOfDay(new Date(req.query.date)) };
  }
  const [items, total] = await Promise.all([
    Attendance.find(filter)
      .populate('subject', 'name code')
      .populate('section', 'name year')
      .populate({ path: 'faculty', populate: { path: 'user', select: 'name' } })
      .sort(sort).skip(skip).limit(limit),
    Attendance.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
});

exports.getOne = asyncHandler(async (req, res) => {
  const att = await Attendance.findById(req.params.id)
    .populate('subject section')
    .populate({ path: 'records.student', populate: { path: 'user', select: 'name' } });
  if (!att) throw new ApiError(404, 'Attendance not found');
  return success(res, { data: att });
});

// Request a correction (faculty) - creates an entry for approver.
exports.requestCorrection = asyncHandler(async (req, res) => {
  const att = await Attendance.findById(req.params.id);
  if (!att) throw new ApiError(404, 'Attendance not found');
  att.corrections.push({ requestedBy: req.user._id, reason: req.body.reason });
  att.approvalStatus = 'correction_requested';
  await att.save();
  await auditService.log(req, { action: 'attendance.correction_request', entity: 'Attendance', entityId: att._id });
  return success(res, { data: att, message: 'Correction requested' });
});

// Apply a correction to records (HOD/Co-HOD).
exports.correct = asyncHandler(async (req, res) => {
  const att = await Attendance.findById(req.params.id);
  if (!att) throw new ApiError(404, 'Attendance not found');
  att.records = req.body.records;
  att.approvalStatus = 'corrected';
  att.corrections.forEach((c) => { c.resolved = true; });
  await att.save();
  await attendanceService.recomputeForStudents(att.records.map((r) => r.student));
  await auditService.log(req, { action: 'attendance.correct', entity: 'Attendance', entityId: att._id });
  return success(res, { data: att, message: 'Attendance corrected' });
});

// Approve an attendance session.
exports.approve = asyncHandler(async (req, res) => {
  const att = await Attendance.findByIdAndUpdate(
    req.params.id,
    { approvalStatus: 'approved', approvedBy: req.user._id },
    { new: true }
  );
  if (!att) throw new ApiError(404, 'Attendance not found');
  await auditService.log(req, { action: 'attendance.approve', entity: 'Attendance', entityId: att._id });
  return success(res, { data: att, message: 'Attendance approved' });
});

// A student's own attendance history + percentage.
exports.studentHistory = asyncHandler(async (req, res) => {
  const studentId = req.params.studentId;
  const sessions = await Attendance.find({ 'records.student': studentId })
    .populate('subject', 'name code')
    .sort('-date');
  const history = sessions.map((s) => {
    const rec = s.records.find((r) => r.student.toString() === studentId);
    return {
      date: s.date, subject: s.subject?.name, period: s.period,
      status: rec?.status, countsTowardShortage: s.countsTowardShortage,
    };
  });
  const summary = await attendanceService.recomputeStudentSummary(studentId);
  return success(res, { data: { summary, history } });
});

// Dashboard stats (today/week/month).
exports.stats = asyncHandler(async (req, res) => {
  const data = await attendanceService.departmentStats(req.query.department, new Date());
  return success(res, { data });
});

// Analytics grouped by dimension.
exports.analytics = asyncHandler(async (req, res) => {
  const data = await attendanceService.analytics(req.query.department, req.query.groupBy, {
    from: req.query.from, to: req.query.to,
  });
  return success(res, { data });
});

// Low-attendance predictions / buckets.
exports.low = asyncHandler(async (req, res) => {
  const data = await attendanceService.lowAttendance(req.query.department);
  return success(res, { data });
});
