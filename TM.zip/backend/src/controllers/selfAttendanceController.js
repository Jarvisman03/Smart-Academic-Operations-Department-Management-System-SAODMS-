const User = require('../models/User');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Attendance = require('../models/Attendance');
const FacultyAttendance = require('../models/FacultyAttendance');
const Timetable = require('../models/Timetable');
const Settings = require('../models/Settings');
const asyncHandler = require('../utils/asyncHandler');
const { success, ApiError } = require('../utils/apiResponse');
const { startOfDay, endOfDay, dayName, currentPeriod } = require('../utils/dateUtils');
const { withinRadius } = require('../utils/geo');
const { isValidDescriptor, matchFace } = require('../utils/face');
const attendanceService = require('../services/attendanceService');
const { occupiedPeriods } = require('../services/timetableService');
const auditService = require('../services/auditService');
const { ATTENDANCE_STATUS, ATTENDANCE_METHODS } = require('../config/constants');

const FACULTY_ROLES = ['faculty', 'hod', 'co_hod', 'dean', 'lab_assistant'];

async function getGlobalSettings() {
  return (await Settings.findOne({ scope: 'global' })) || (await Settings.create({ scope: 'global' }));
}

// Enroll (or re-enroll) the caller's face descriptor.
exports.enrollFace = asyncHandler(async (req, res) => {
  const { descriptor } = req.body;
  if (!isValidDescriptor(descriptor)) {
    throw new ApiError(400, 'Invalid face descriptor (expected 128 numbers). Try capturing again.');
  }
  const user = await User.findById(req.user._id);
  user.faceDescriptor = descriptor;
  user.faceEnrolledAt = new Date();
  await user.save();
  await auditService.log(req, { action: 'attendance.face_enroll', entity: 'User', entityId: user._id });
  return success(res, { data: { enrolledAt: user.faceEnrolledAt }, message: 'Face enrolled successfully' });
});

// Status: is the caller enrolled + what campus geofence/features apply.
exports.status = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('+faceDescriptor');
  const settings = await getGlobalSettings();
  return success(res, {
    data: {
      enrolled: Array.isArray(user.faceDescriptor) && user.faceDescriptor.length > 0,
      enrolledAt: user.faceEnrolledAt || null,
      faceRequired: !!settings.features?.faceRecognition,
      geofence: {
        enabled: !!settings.geofence?.enabled,
        lat: settings.geofence?.lat ?? null,
        lng: settings.geofence?.lng ?? null,
        radiusMeters: settings.geofence?.radiusMeters ?? 200,
      },
      mode: req.user.role === 'student' ? 'per_lecture' : 'daily',
    },
  });
});

// Shared verification: geofence + face.
async function verify(req, settings) {
  const { descriptor, location } = req.body;

  // 1. Geofence (only if enabled and configured).
  if (settings.geofence?.enabled) {
    const check = withinRadius(
      { lat: settings.geofence.lat, lng: settings.geofence.lng },
      location,
      settings.geofence.radiusMeters || 200
    );
    if (!check.ok) {
      throw new ApiError(403, `You appear to be ${check.distance}m from campus. Move inside the campus and try again.`);
    }
  }

  // 2. Face match (only if face recognition feature is on).
  let faceScore = null;
  if (settings.features?.faceRecognition) {
    const user = await User.findById(req.user._id).select('+faceDescriptor');
    if (!user.faceDescriptor || user.faceDescriptor.length === 0) {
      throw new ApiError(400, 'No face enrolled. Please enroll your face first.');
    }
    const result = matchFace(user.faceDescriptor, descriptor);
    if (!result.ok) {
      throw new ApiError(401, 'Face not recognized. Please try again in good lighting.');
    }
    faceScore = result.score;
  }
  return { faceScore };
}

// Student: mark present in the currently-scheduled lecture.
async function checkInStudent(req, settings) {
  const student = await Student.findOne({ user: req.user._id });
  if (!student) throw new ApiError(404, 'Student profile not found');
  if (!student.section) throw new ApiError(400, 'You are not assigned to a section');

  const now = new Date();
  const period = currentPeriod(now);
  if (!period) throw new ApiError(409, 'No class is scheduled at this time.');

  // A class may span multiple periods, so match any entry whose occupied
  // periods include the current one (not just entries anchored to it).
  const dayEntries = await Timetable.find({
    section: student.section,
    day: dayName(now),
    isActive: true,
  }).populate('subject', 'name code');
  const entry = dayEntries.find((e) => occupiedPeriods(e.period, e.periodSpan).includes(period.period));
  if (!entry) throw new ApiError(409, 'No class is scheduled for your section this period.');

  // The attendance session is anchored to the class's starting period.
  const sessionPeriod = entry.period;

  // Respect a cancellation for today.
  const cancelledToday = (entry.substitutions || []).some(
    (s) => s.cancelled && s.date && startOfDay(s.date).getTime() === startOfDay(now).getTime()
  );
  if (cancelledToday) throw new ApiError(409, 'This class has been cancelled for today.');

  const { faceScore } = await verify(req, settings);

  // Subject may be a free-text entry (no catalog ref) or a linked Subject doc.
  const subjectId = entry.subject?._id;
  const subjectLabel = entry.subject?.name || entry.subjectName || 'your class';
  // Only carry a real Room ObjectId; free-text rooms have no ref.
  const roomRef = entry.room && entry.room._id ? entry.room._id : entry.room;

  const rule = await attendanceService.rulesForYear(student.year, student.department);
  // Identify the session by its subject when linked, otherwise by the timetable slot.
  const filter = {
    section: student.section,
    date: { $gte: startOfDay(now), $lte: endOfDay(now) },
    period: sessionPeriod,
  };
  if (subjectId) filter.subject = subjectId;
  else filter.timetableEntry = entry._id;

  let attendance = await Attendance.findOne(filter);
  if (!attendance) {
    attendance = new Attendance({
      department: student.department,
      section: student.section,
      year: student.year,
      subject: subjectId,
      subjectName: subjectLabel,
      faculty: entry.faculty,
      room: roomRef,
      timetableEntry: entry._id,
      date: now,
      period: sessionPeriod,
      method: ATTENDANCE_METHODS.FACE,
      records: [],
      countsTowardShortage: rule.countsTowardShortage,
      location: req.body.location,
    });
  }
  const existing = attendance.records.find((r) => r.student.toString() === student._id.toString());
  if (existing) existing.status = ATTENDANCE_STATUS.PRESENT;
  else attendance.records.push({ student: student._id, status: ATTENDANCE_STATUS.PRESENT });
  await attendance.save();
  await attendanceService.recomputeStudentSummary(student._id);

  const io = req.app.get('io');
  if (io) io.of('/dashboard').emit('attendance:update', { attendanceId: attendance._id, section: student.section, subject: subjectId });

  return {
    message: `Marked present in ${subjectLabel}`,
    subject: subjectLabel,
    period: period.period,
    at: now,
    faceScore,
  };
}

// Faculty/staff: daily check-in.
async function checkInFaculty(req, settings) {
  const faculty = await Faculty.findOne({ user: req.user._id });
  if (!faculty) throw new ApiError(404, 'Faculty profile not found');

  const now = new Date();
  const existing = await FacultyAttendance.findOne({
    faculty: faculty._id,
    date: { $gte: startOfDay(now), $lte: endOfDay(now) },
  });
  if (existing && existing.checkIn) throw new ApiError(409, 'You have already checked in today.');

  const { faceScore } = await verify(req, settings);

  const startMins = (() => {
    const t = settings.college?.startTime || '08:30';
    const [h, m] = t.split(':').map(Number);
    return h * 60 + m;
  })();
  const nowMins = now.getHours() * 60 + now.getMinutes();
  const lateBy = Math.max(0, nowMins - startMins - (settings.lateThresholdMinutes || 10));

  const record = existing || new FacultyAttendance({ faculty: faculty._id, department: faculty.department, date: now });
  record.checkIn = now;
  record.method = ATTENDANCE_METHODS.FACE;
  record.location = req.body.location;
  record.status = lateBy > 0 ? 'late' : 'present';
  record.lateByMinutes = lateBy;
  await record.save();

  return {
    message: lateBy > 0 ? `Checked in (late by ${lateBy} min)` : 'Checked in',
    status: record.status,
    at: now,
    faceScore,
  };
}

// Unified self check-in dispatcher.
exports.checkIn = asyncHandler(async (req, res) => {
  const settings = await getGlobalSettings();

  const { descriptor, location } = req.body;
  if (settings.features?.faceRecognition && !isValidDescriptor(descriptor)) {
    throw new ApiError(400, 'A valid face capture is required.');
  }
  if (settings.geofence?.enabled && (!location || location.lat == null || location.lng == null)) {
    throw new ApiError(400, 'Location is required. Please allow location access and try again.');
  }

  const result = req.user.role === 'student'
    ? await checkInStudent(req, settings)
    : await checkInFaculty(req, settings);

  await auditService.log(req, {
    action: 'attendance.self_checkin',
    entity: 'User',
    entityId: req.user._id,
    meta: { role: req.user.role, method: 'face', faceScore: result.faceScore },
  });

  return success(res, { data: result, message: result.message });
});
