const Attendance = require('../models/Attendance');
const Faculty = require('../models/Faculty');
const Student = require('../models/Student');
const Report = require('../models/Report');
const asyncHandler = require('../utils/asyncHandler');
const { ApiError } = require('../utils/apiResponse');
const reportService = require('../services/reportService');
const aiService = require('../services/aiService');
const auditService = require('../services/auditService');
const { startOfDay, endOfDay } = require('../utils/dateUtils');

// Build the table spec for a given report type.
async function buildSpec(type, query) {
  switch (type) {
    case 'attendance': {
      const filter = {};
      if (query.department) filter.department = query.department;
      if (query.from || query.to) {
        filter.date = {};
        if (query.from) filter.date.$gte = startOfDay(new Date(query.from));
        if (query.to) filter.date.$lte = endOfDay(new Date(query.to));
      }
      const sessions = await Attendance.find(filter)
        .populate('subject', 'name').populate('section', 'name year')
        .populate({ path: 'faculty', populate: { path: 'user', select: 'name' } })
        .sort('-date').limit(1000);
      return {
        title: 'Attendance Report',
        columns: ['Date', 'Subject', 'Section', 'Year', 'Faculty', 'Present', 'Absent', 'Total', '%'],
        rows: sessions.map((s) => [
          new Date(s.date).toLocaleDateString(), s.subject?.name, s.section?.name, s.year,
          s.faculty?.user?.name, s.presentCount, s.absentCount, s.totalStudents,
          s.totalStudents ? Math.round((s.presentCount / s.totalStudents) * 100) : 0,
        ]),
      };
    }
    case 'student': {
      const filter = { isActive: true };
      if (query.department) filter.department = query.department;
      if (query.year) filter.year = Number(query.year);
      const students = await Student.find(filter).populate('user', 'name email').populate('section', 'name').sort('rollNo');
      return {
        title: 'Student Report',
        columns: ['Enrollment', 'Name', 'Year', 'Section', 'Attendance %'],
        rows: students.map((s) => [s.enrollmentNo, s.user?.name, s.year, s.section?.name, s.attendanceSummary?.percentage || 0]),
      };
    }
    case 'faculty':
    case 'workload': {
      const workload = await aiService.predictWorkload(query.department);
      return {
        title: type === 'workload' ? 'Faculty Workload Report' : 'Faculty Report',
        columns: ['Faculty', 'Weekly Load', 'Max Load', 'Utilization %', 'Status'],
        rows: workload.map((w) => [w.faculty, w.weeklyLoad, w.maxLoad, w.utilization, w.status]),
      };
    }
    case 'room_usage':
    case 'lab_usage': {
      const rooms = await aiService.predictRoomUtilization();
      const filtered = type === 'lab_usage' ? rooms.filter((r) => r.type === 'lab') : rooms;
      return {
        title: type === 'lab_usage' ? 'Lab Usage Report' : 'Room Usage Report',
        columns: ['Room', 'Type', 'Weekly Slots', 'Utilization %', 'Status'],
        rows: filtered.map((r) => [r.room, r.type, r.weeklySlots, r.utilization, r.status]),
      };
    }
    default:
      throw new ApiError(400, `Unsupported report type: ${type}`);
  }
}

exports.generate = asyncHandler(async (req, res) => {
  const { type, format = 'pdf' } = req.query;
  const spec = await buildSpec(type, req.query);
  spec.subtitle = `Generated ${new Date().toLocaleString()}`;

  const { buffer, mime, ext } = await reportService.generate(format, spec);

  await Report.create({
    title: spec.title, type, format, department: req.query.department || undefined,
    generatedBy: req.user._id, filters: req.query, rowCount: spec.rows.length,
  });
  await auditService.log(req, { action: 'report.generate', entity: 'Report', meta: { type, format } });

  res.setHeader('Content-Type', mime);
  res.setHeader('Content-Disposition', `attachment; filename="${type}-report.${ext}"`);
  return res.send(buffer);
});

exports.history = asyncHandler(async (req, res) => {
  const reports = await Report.find(req.query.department ? { department: req.query.department } : {})
    .populate('generatedBy', 'name').sort('-createdAt').limit(50);
  return res.json({ success: true, data: reports });
});
