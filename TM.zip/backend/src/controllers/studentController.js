const mongoose = require('mongoose');
const User = require('../models/User');
const Student = require('../models/Student');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const auditService = require('../services/auditService');
const env = require('../config/env');

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip, sort } = parsePagination(req.query);
  const filter = { isActive: true };
  if (req.query.department) filter.department = req.query.department;
  if (req.query.year) filter.year = Number(req.query.year);
  if (req.query.section) filter.section = req.query.section;
  if (req.query.gender) filter.gender = req.query.gender;
  if (req.query.lowAttendance === 'true') {
    filter['attendanceSummary.percentage'] = { $lt: Number(req.query.threshold) || 75 };
  }

  let userIds;
  if (req.query.search) {
    const users = await User.find({
      $or: [{ name: { $regex: req.query.search, $options: 'i' } }, { email: { $regex: req.query.search, $options: 'i' } }],
    }).select('_id');
    userIds = users.map((u) => u._id);
    filter.$or = [{ user: { $in: userIds } }, { enrollmentNo: { $regex: req.query.search, $options: 'i' } }];
  }

  const [items, total] = await Promise.all([
    Student.find(filter).populate('user', 'name email avatar').populate('section', 'name').sort(sort).skip(skip).limit(limit),
    Student.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
});

exports.getOne = asyncHandler(async (req, res) => {
  const student = await Student.findById(req.params.id)
    .populate('user', 'name email avatar phone')
    .populate('section', 'name year')
    .populate('department', 'name code');
  if (!student) throw new ApiError(404, 'Student not found');
  return success(res, { data: student });
});

exports.create = asyncHandler(async (req, res) => {
  const { name, email, phone, password, department, ...studentData } = req.body;
  const exists = await User.findOne({ email: email.toLowerCase() });
  if (exists) throw new ApiError(409, 'Email already registered');

  const session = await mongoose.startSession();
  let student;
  try {
    await session.withTransaction(async () => {
      const [user] = await User.create([{ name, email, phone, password: password || env.seedDefaultPassword, role: 'student', department }], { session });
      [student] = await Student.create([{ ...studentData, user: user._id, department }], { session });
    });
  } finally {
    session.endSession();
  }
  student = await Student.findById(student._id).populate('user', 'name email');
  await auditService.log(req, { action: 'student.create', entity: 'Student', entityId: student._id });
  return created(res, { data: student, message: 'Student created' });
});

exports.update = asyncHandler(async (req, res) => {
  const { name, phone, avatar, ...studentData } = req.body;
  const student = await Student.findByIdAndUpdate(req.params.id, studentData, { new: true, runValidators: true }).populate('user', 'name email');
  if (!student) throw new ApiError(404, 'Student not found');
  if (name || phone || avatar) {
    await User.findByIdAndUpdate(student.user._id, { ...(name && { name }), ...(phone && { phone }), ...(avatar && { avatar }) });
  }
  await auditService.log(req, { action: 'student.update', entity: 'Student', entityId: student._id });
  return success(res, { data: student, message: 'Student updated' });
});

exports.remove = asyncHandler(async (req, res) => {
  const student = await Student.findById(req.params.id);
  if (!student) throw new ApiError(404, 'Student not found');
  await Student.findByIdAndUpdate(student._id, { isActive: false });
  await User.findByIdAndUpdate(student.user, { isActive: false });
  await auditService.log(req, { action: 'student.deactivate', entity: 'Student', entityId: student._id });
  return success(res, { message: 'Student deactivated' });
});
