const Notification = require('../models/Notification');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const notificationService = require('../services/notificationService');

exports.myNotifications = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = { recipient: req.user._id };
  if (req.query.unread === 'true') filter.isRead = false;
  const [items, total, unread] = await Promise.all([
    Notification.find(filter).sort('-createdAt').skip(skip).limit(limit),
    Notification.countDocuments(filter),
    Notification.countDocuments({ recipient: req.user._id, isRead: false }),
  ]);
  return success(res, { data: items, meta: { ...buildMeta(page, limit, total), unread } });
});

exports.markRead = asyncHandler(async (req, res) => {
  await Notification.findOneAndUpdate({ _id: req.params.id, recipient: req.user._id }, { isRead: true, readAt: new Date() });
  return success(res, { message: 'Marked as read' });
});

exports.markAllRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ recipient: req.user._id, isRead: false }, { isRead: true, readAt: new Date() });
  return success(res, { message: 'All marked as read' });
});

// Broadcast a notification to an audience (HOD/Dean/Admin/Co-HOD).
exports.broadcast = asyncHandler(async (req, res) => {
  const { roles, department, title, message, type, link, priority } = req.body;
  const created = await notificationService.notifyByAudience({
    roles: roles || ['faculty', 'student'],
    department: department || req.user.department,
    title, message, type, link, priority, createdBy: req.user._id,
  });
  return success(res, { data: { count: created.length }, message: 'Notification sent' });
});
