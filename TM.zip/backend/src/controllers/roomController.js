const Room = require('../models/Room');
const Lab = require('../models/Lab');
const Building = require('../models/Building');
const Floor = require('../models/Floor');
const asyncHandler = require('../utils/asyncHandler');
const { success, created, ApiError } = require('../utils/apiResponse');
const { parsePagination, buildMeta } = require('../utils/queryFeatures');
const auditService = require('../services/auditService');
const statusService = require('../services/statusService');

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip, sort } = parsePagination(req.query);
  const filter = { isActive: true };
  if (req.query.type) filter.type = req.query.type;
  if (req.query.building) filter.building = req.query.building;
  if (req.query.floorNumber) filter.floorNumber = Number(req.query.floorNumber);
  if (req.query.status) filter.status = req.query.status;
  if (req.query.search) filter.roomNumber = { $regex: req.query.search, $options: 'i' };

  const [items, total] = await Promise.all([
    Room.find(filter).populate('building', 'name code').sort(sort).skip(skip).limit(limit),
    Room.countDocuments(filter),
  ]);
  return success(res, { data: items, meta: buildMeta(page, limit, total) });
});

exports.getOne = asyncHandler(async (req, res) => {
  const room = await Room.findById(req.params.id).populate('building floor');
  if (!room) throw new ApiError(404, 'Room not found');
  return success(res, { data: room });
});

exports.create = asyncHandler(async (req, res) => {
  const room = await Room.create(req.body);
  await auditService.log(req, { action: 'room.create', entity: 'Room', entityId: room._id });
  return created(res, { data: room, message: 'Room created' });
});

exports.update = asyncHandler(async (req, res) => {
  const room = await Room.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!room) throw new ApiError(404, 'Room not found');
  await auditService.log(req, { action: 'room.update', entity: 'Room', entityId: room._id });
  return success(res, { data: room, message: 'Room updated' });
});

exports.remove = asyncHandler(async (req, res) => {
  const room = await Room.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
  if (!room) throw new ApiError(404, 'Room not found');
  return success(res, { message: 'Room removed' });
});

// Set base status e.g. maintenance / reserved.
exports.setStatus = asyncHandler(async (req, res) => {
  const room = await Room.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!room) throw new ApiError(404, 'Room not found');
  await auditService.log(req, { action: 'room.set_status', entity: 'Room', entityId: room._id, meta: { status: req.body.status } });
  const io = req.app.get('io');
  if (io) io.of('/dashboard').emit('room:status', { roomId: room._id, status: room.status });
  return success(res, { data: room, message: 'Room status updated' });
});

// Building floor-map: rooms grouped by floor with live status + color coding.
exports.buildingMap = asyncHandler(async (req, res) => {
  const buildingId = req.params.buildingId || req.query.building;
  const building = buildingId ? await Building.findById(buildingId) : await Building.findOne();
  if (!building) throw new ApiError(404, 'Building not found');

  const [floors, rooms, liveMap] = await Promise.all([
    Floor.find({ building: building._id }).sort('number'),
    Room.find({ building: building._id, isActive: true }).sort('floorNumber roomNumber'),
    statusService.computeRoomStatuses(building._id),
  ]);

  const floorData = floors.map((floor) => ({
    floor: floor.toObject(),
    rooms: rooms
      .filter((r) => r.floorNumber === floor.number)
      .map((r) => {
        const live = liveMap[r._id.toString()];
        return {
          ...r.toObject(),
          liveStatus: live || { status: r.status },
          color: statusService.statusColor(live ? live.status : r.status),
        };
      }),
  }));

  return success(res, { data: { building, floors: floorData } });
});

exports.availability = asyncHandler(async (req, res) => {
  const buildingId = req.query.building;
  const filter = { isActive: true };
  if (buildingId) filter.building = buildingId;
  const liveMap = await statusService.computeRoomStatuses(buildingId);
  const rooms = await Room.find(filter);
  const result = rooms.map((r) => {
    const live = liveMap[r._id.toString()];
    return { room: r, status: live ? live.status : r.status };
  });
  const summary = {
    total: rooms.length,
    occupied: result.filter((r) => r.status === 'occupied').length,
    free: result.filter((r) => r.status === 'free').length,
    reserved: result.filter((r) => r.status === 'reserved').length,
    maintenance: result.filter((r) => r.status === 'maintenance').length,
  };
  return success(res, { data: { rooms: result, summary } });
});
