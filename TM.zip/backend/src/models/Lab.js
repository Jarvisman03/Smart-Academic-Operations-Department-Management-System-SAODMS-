const mongoose = require('mongoose');

const labSchema = new mongoose.Schema(
  {
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true, unique: true },
    name: { type: String, required: true, trim: true }, // e.g. "AI/ML Lab"
    labInCharge: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty' },
    labAssistant: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    systemsCount: { type: Number, default: 30 },
    workingSystems: { type: Number, default: 30 },
    software: [String],
    equipment: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Equipment' }],
    equipmentStatus: {
      type: String,
      enum: ['operational', 'partial', 'down'],
      default: 'operational',
    },
    specialization: String, // e.g. "AI", "Networking"
  },
  { timestamps: true }
);

module.exports = mongoose.model('Lab', labSchema);
