const mongoose = require('mongoose');

const announcementSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    body: { type: String, required: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    priority: { type: String, enum: ['low', 'normal', 'high', 'critical'], default: 'normal' },
    audience: [{ type: String, enum: ['all', 'faculty', 'students', 'year2', 'year3', 'year4', 'hod', 'staff'] }],
    pinned: { type: Boolean, default: false },
    attachments: [{ name: String, url: String }],
    expiresAt: Date,
    readBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: true }
);

announcementSchema.index({ department: 1, createdAt: -1 });

module.exports = mongoose.model('Announcement', announcementSchema);
