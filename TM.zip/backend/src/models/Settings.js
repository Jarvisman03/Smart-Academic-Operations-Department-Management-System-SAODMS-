const mongoose = require('mongoose');
const { DEFAULT_YEAR_RULES, ATTENDANCE_THRESHOLDS, COLLEGE } = require('../config/constants');

// Singleton-style settings document (one per department, or one global).
const settingsSchema = new mongoose.Schema(
  {
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', unique: true, sparse: true },
    scope: { type: String, enum: ['global', 'department'], default: 'global' },
    college: {
      name: { type: String, default: COLLEGE.name },
      shortName: { type: String, default: COLLEGE.shortName },
      startTime: { type: String, default: COLLEGE.startTime },
      endTime: { type: String, default: COLLEGE.endTime },
    },
    // Per-year attendance rules. Year 4 excluded from shortage by default.
    attendanceRules: {
      type: Map,
      of: new mongoose.Schema(
        {
          mandatory: Boolean,
          countsTowardShortage: Boolean,
        },
        { _id: false }
      ),
      default: () => new Map(Object.entries(DEFAULT_YEAR_RULES)),
    },
    thresholds: {
      minimum: { type: Number, default: ATTENDANCE_THRESHOLDS.MINIMUM },
      warning: { type: Number, default: ATTENDANCE_THRESHOLDS.WARNING },
      critical: { type: Number, default: ATTENDANCE_THRESHOLDS.CRITICAL },
    },
    lateThresholdMinutes: { type: Number, default: 10 },
    // Campus geofence for GPS attendance. When enabled, self check-in must
    // originate within `radiusMeters` of (lat,lng).
    geofence: {
      enabled: { type: Boolean, default: false },
      lat: { type: Number },
      lng: { type: Number },
      radiusMeters: { type: Number, default: 200 },
    },
    features: {
      qrAttendance: { type: Boolean, default: true },
      gpsAttendance: { type: Boolean, default: true },
      faceRecognition: { type: Boolean, default: false },
      aiAssistant: { type: Boolean, default: true },
    },
    workingDays: { type: [String], default: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] },
    facultyWorkingDays: { type: [String], default: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Settings', settingsSchema);
