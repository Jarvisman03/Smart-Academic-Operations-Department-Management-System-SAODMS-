const mongoose = require('mongoose');
const { FACULTY_STATUS } = require('../config/constants');

// ============================================================
// Faculty - extended profile for teaching/lab staff.
// `liveStatus` is a cached snapshot maintained by statusService,
// while the authoritative status is derived from timetable + leaves.
// ============================================================
const facultySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    employeeId: { type: String, required: true, unique: true, trim: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true, index: true },
    designation: {
      type: String,
      enum: ['Professor', 'Associate Professor', 'Assistant Professor', 'Lab Assistant', 'Guest Faculty'],
      default: 'Assistant Professor',
    },
    // Subjects this faculty can teach (drives substitute suggestions).
    expertise: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Subject' }],
    qualifications: [String],
    joiningDate: Date,
    gender: { type: String, enum: ['male', 'female', 'other'] },
    // Cabin / seat location for "current location" display.
    cabin: { type: String, default: '' },
    maxWeeklyLoad: { type: Number, default: 24 }, // periods per week
    // Cached live status snapshot for fast dashboard reads.
    liveStatus: {
      status: { type: String, enum: Object.values(FACULTY_STATUS), default: FACULTY_STATUS.AVAILABLE },
      room: String,
      subject: String,
      batch: String,
      section: String,
      periodLabel: String,
      updatedAt: Date,
    },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

facultySchema.index({ department: 1, isActive: 1 });

module.exports = mongoose.model('Faculty', facultySchema);
