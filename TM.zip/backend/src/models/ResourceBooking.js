const mongoose = require('mongoose');

const resourceBookingSchema = new mongoose.Schema(
  {
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true, index: true },
    lab: { type: mongoose.Schema.Types.ObjectId, ref: 'Lab' },
    bookedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    purpose: { type: String, required: true },
    date: { type: Date, required: true, index: true },
    startTime: { type: String, required: true },
    endTime: { type: String, required: true },
    status: { type: String, enum: ['pending', 'approved', 'rejected', 'cancelled'], default: 'approved', index: true },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    attendeesCount: Number,
    notes: String,
  },
  { timestamps: true }
);

// Prevent obvious double-booking of the same room/date/slot.
resourceBookingSchema.index({ room: 1, date: 1, startTime: 1, endTime: 1 });

module.exports = mongoose.model('ResourceBooking', resourceBookingSchema);
