const mongoose = require('mongoose');

const floorSchema = new mongoose.Schema(
  {
    building: { type: mongoose.Schema.Types.ObjectId, ref: 'Building', required: true, index: true },
    number: { type: Number, required: true }, // 1..4 (ground = 1)
    name: { type: String, trim: true }, // e.g. "Ground Floor"
    description: String,
  },
  { timestamps: true }
);

floorSchema.index({ building: 1, number: 1 }, { unique: true });

module.exports = mongoose.model('Floor', floorSchema);
