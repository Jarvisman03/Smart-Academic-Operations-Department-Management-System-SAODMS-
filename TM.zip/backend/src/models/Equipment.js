const mongoose = require('mongoose');

const equipmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    tag: { type: String, unique: true, sparse: true, trim: true }, // asset tag
    category: { type: String, enum: ['computer', 'projector', 'network', 'furniture', 'other'], default: 'computer' },
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', index: true },
    lab: { type: mongoose.Schema.Types.ObjectId, ref: 'Lab', index: true },
    status: { type: String, enum: ['operational', 'faulty', 'maintenance', 'retired'], default: 'operational' },
    purchaseDate: Date,
    lastServiced: Date,
    notes: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Equipment', equipmentSchema);
