const mongoose = require('mongoose');

const semesterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true }, // e.g. "Odd 2025-26"
    number: { type: Number, min: 1, max: 8, required: true },
    academicYear: { type: String, required: true }, // "2025-2026"
    type: { type: String, enum: ['odd', 'even'], required: true },
    startDate: Date,
    endDate: Date,
    isCurrent: { type: Boolean, default: false, index: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Semester', semesterSchema);
