const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: String,
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    assignedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assignedTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },
    status: { type: String, enum: ['todo', 'in_progress', 'done', 'blocked'], default: 'todo' },
    dueDate: { type: Date, index: true },
    completedAt: Date,
    tags: [String],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Task', taskSchema);
