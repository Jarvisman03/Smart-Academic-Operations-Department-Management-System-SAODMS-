const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: String,
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    category: { type: String, enum: ['seminar', 'workshop', 'fest', 'placement', 'exam', 'holiday', 'other'], default: 'other' },
    organizer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    startDate: { type: Date, required: true, index: true },
    endDate: Date,
    venue: String,
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
    banner: String,
    audience: [{ type: String, enum: ['all', 'faculty', 'students', 'year2', 'year3', 'year4'] }],
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Event', eventSchema);
