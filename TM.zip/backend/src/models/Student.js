const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    enrollmentNo: { type: String, required: true, unique: true, trim: true },
    rollNo: { type: String, trim: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true, index: true },
    year: { type: Number, enum: [1, 2, 3, 4], required: true, index: true },
    semester: { type: Number, min: 1, max: 8, required: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', index: true },
    batch: { type: String, trim: true }, // e.g. "2022-2026"
    gender: { type: String, enum: ['male', 'female', 'other'], index: true },
    dob: Date,
    guardianName: String,
    guardianPhone: String,
    address: String,
    admissionYear: Number,
    // Denormalized attendance summary for fast lists (recomputed by service).
    attendanceSummary: {
      totalClasses: { type: Number, default: 0 },
      attended: { type: Number, default: 0 },
      percentage: { type: Number, default: 0 },
      updatedAt: Date,
    },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

studentSchema.index({ department: 1, year: 1, section: 1 });
studentSchema.index({ 'attendanceSummary.percentage': 1 });

module.exports = mongoose.model('Student', studentSchema);
