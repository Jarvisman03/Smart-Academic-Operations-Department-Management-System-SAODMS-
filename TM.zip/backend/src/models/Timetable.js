const mongoose = require('mongoose');
const { TIMETABLE_DAYS } = require('../config/constants');

// ============================================================
// Timetable entry - one scheduled lecture/lab slot.
// A weekly timetable is the set of entries for a section+semester.
// Conflict detection queries this collection by (day, period, faculty/room/section).
// ============================================================
const timetableSchema = new mongoose.Schema(
  {
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true, index: true },
    semester: { type: mongoose.Schema.Types.ObjectId, ref: 'Semester', index: true },
    academicYear: { type: String, index: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', required: true, index: true },
    year: { type: Number, enum: [1, 2, 3, 4], required: true },
    day: { type: String, enum: TIMETABLE_DAYS, required: true, index: true },
    period: { type: Number, required: true }, // starting period; matches constants.PERIODS[].period
    // Number of consecutive teaching periods this entry occupies (labs span 2-3).
    periodSpan: { type: Number, default: 1, min: 1 },
    startTime: { type: String, required: true },
    endTime: { type: String, required: true },
    // Subject + room are free-text: teachers type the name directly. The optional
    // refs are kept for legacy / auto-generated entries that link the catalog.
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject' },
    subjectName: { type: String, trim: true },
    faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty', required: true, index: true },
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
    roomName: { type: String, trim: true },
    type: { type: String, enum: ['theory', 'lab', 'tutorial', 'library'], default: 'theory' },
    // Substitution overrides for a specific date.
    substitutions: [
      {
        date: Date,
        originalFaculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty' },
        substituteFaculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty' },
        room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
        reason: String,
        cancelled: { type: Boolean, default: false },
      },
    ],
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// A section can only have one class per (day, period).
timetableSchema.index({ section: 1, day: 1, period: 1, isActive: 1 });
// Fast conflict checks.
timetableSchema.index({ faculty: 1, day: 1, period: 1 });
timetableSchema.index({ room: 1, day: 1, period: 1 });

module.exports = mongoose.model('Timetable', timetableSchema);
