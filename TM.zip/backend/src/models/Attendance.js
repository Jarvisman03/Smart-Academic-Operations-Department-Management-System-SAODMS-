const mongoose = require('mongoose');
const { ATTENDANCE_STATUS, ATTENDANCE_METHODS } = require('../config/constants');

// ============================================================
// Attendance - one document per (class session) holding a roster
// of student marks. This session-oriented shape keeps reads cheap
// for dashboards and avoids a document explosion.
// ============================================================
const recordSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    status: { type: String, enum: Object.values(ATTENDANCE_STATUS), default: ATTENDANCE_STATUS.ABSENT },
    lateByMinutes: { type: Number, default: 0 },
  },
  { _id: false }
);

const attendanceSchema = new mongoose.Schema(
  {
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true, index: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', required: true, index: true },
    year: { type: Number, enum: [1, 2, 3, 4], required: true, index: true },
    // Subject may be a free-text timetable subject (no catalog link), so the
    // ref is optional and a display name is stored alongside it.
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', index: true },
    subjectName: { type: String },
    faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty', required: true, index: true },
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
    timetableEntry: { type: mongoose.Schema.Types.ObjectId, ref: 'Timetable' },
    date: { type: Date, required: true, index: true },
    period: { type: Number, required: true },
    method: { type: String, enum: Object.values(ATTENDANCE_METHODS), default: ATTENDANCE_METHODS.MANUAL },
    records: [recordSchema],
    // Denormalized counts for fast dashboard reads.
    totalStudents: { type: Number, default: 0 },
    presentCount: { type: Number, default: 0 },
    absentCount: { type: Number, default: 0 },
    lateCount: { type: Number, default: 0 },
    // Whether this session counts toward shortage (4th year excluded per rules).
    countsTowardShortage: { type: Boolean, default: true },
    // Approval / correction workflow.
    approvalStatus: { type: String, enum: ['submitted', 'approved', 'correction_requested', 'corrected'], default: 'submitted' },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    corrections: [
      {
        requestedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        reason: String,
        createdAt: { type: Date, default: Date.now },
        resolved: { type: Boolean, default: false },
      },
    ],
    // GPS / QR metadata when applicable.
    location: { lat: Number, lng: Number },
    qrToken: String,
  },
  { timestamps: true }
);

// One attendance session per (section, subject, date, period).
attendanceSchema.index({ section: 1, subject: 1, date: 1, period: 1 }, { unique: true });
attendanceSchema.index({ date: 1, department: 1 });
attendanceSchema.index({ faculty: 1, date: 1 });

// Keep denormalized counts in sync.
attendanceSchema.pre('save', function computeCounts(next) {
  if (this.isModified('records')) {
    this.totalStudents = this.records.length;
    this.presentCount = this.records.filter((r) => r.status === 'present' || r.status === 'late').length;
    this.lateCount = this.records.filter((r) => r.status === 'late').length;
    this.absentCount = this.records.filter((r) => r.status === 'absent').length;
  }
  next();
});

module.exports = mongoose.model('Attendance', attendanceSchema);
