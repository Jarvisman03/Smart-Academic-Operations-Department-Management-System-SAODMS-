const mongoose = require('mongoose');

const sectionSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true }, // e.g. "A", "B"
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true, index: true },
    year: { type: Number, enum: [1, 2, 3, 4], required: true },
    semester: { type: Number, min: 1, max: 8, required: true },
    batch: { type: String, trim: true },
    classTeacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty' },
    strength: { type: Number, default: 0 },
    homeRoom: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
  },
  { timestamps: true }
);

sectionSchema.index({ department: 1, year: 1, name: 1 }, { unique: true });

module.exports = mongoose.model('Section', sectionSchema);
