const mongoose = require('mongoose');

const documentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    description: String,
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    category: { type: String, enum: ['notes', 'syllabus', 'circular', 'policy', 'form', 'result', 'other'], default: 'other' },
    url: { type: String, required: true },
    fileType: String,
    size: Number,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    visibility: [{ type: String, enum: ['all', 'faculty', 'students', 'hod', 'staff'] }],
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject' },
    tags: [String],
    downloads: { type: Number, default: 0 },
  },
  { timestamps: true }
);

documentSchema.index({ name: 'text', description: 'text', tags: 'text' });

module.exports = mongoose.model('Document', documentSchema);
