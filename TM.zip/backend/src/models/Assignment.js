const mongoose = require('mongoose');

const submissionSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student' },
    fileUrl: String,
    submittedAt: { type: Date, default: Date.now },
    grade: String,
    feedback: String,
    status: { type: String, enum: ['submitted', 'graded', 'late'], default: 'submitted' },
  },
  { _id: false }
);

const assignmentSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: String,
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty', required: true, index: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', index: true },
    year: { type: Number, enum: [1, 2, 3, 4] },
    dueDate: { type: Date, index: true },
    maxMarks: { type: Number, default: 10 },
    attachments: [{ name: String, url: String }],
    submissions: [submissionSchema],
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Assignment', assignmentSchema);
