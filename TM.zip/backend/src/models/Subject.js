const mongoose = require('mongoose');

const subjectSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    code: { type: String, required: true, unique: true, uppercase: true, trim: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true, index: true },
    year: { type: Number, enum: [1, 2, 3, 4], required: true },
    semester: { type: Number, min: 1, max: 8, required: true },
    credits: { type: Number, default: 3 },
    type: { type: String, enum: ['theory', 'lab', 'elective', 'project'], default: 'theory' },
    weeklyLectures: { type: Number, default: 3 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

subjectSchema.index({ department: 1, year: 1, semester: 1 });

module.exports = mongoose.model('Subject', subjectSchema);
