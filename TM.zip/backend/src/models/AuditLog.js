const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema(
  {
    actor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
    actorRole: String,
    action: { type: String, required: true }, // e.g. "attendance.mark", "user.create"
    entity: String, // collection/entity name
    entityId: mongoose.Schema.Types.ObjectId,
    description: String,
    ip: String,
    userAgent: String,
    meta: mongoose.Schema.Types.Mixed,
    status: { type: String, enum: ['success', 'failure'], default: 'success' },
  },
  { timestamps: true }
);

auditLogSchema.index({ createdAt: -1 });
auditLogSchema.index({ action: 1, createdAt: -1 });

module.exports = mongoose.model('AuditLog', auditLogSchema);
