const mongoose = require('mongoose');
const { ROOM_STATUS, ROOM_TYPES } = require('../config/constants');

// ============================================================
// Room - a classroom/seminar/office. Labs are Rooms with a
// linked Lab document for equipment details (type = 'lab').
// `liveStatus` is a cached snapshot refreshed by statusService.
// ============================================================
const roomSchema = new mongoose.Schema(
  {
    roomNumber: { type: String, required: true, trim: true },
    name: { type: String, trim: true },
    building: { type: mongoose.Schema.Types.ObjectId, ref: 'Building', required: true, index: true },
    floor: { type: mongoose.Schema.Types.ObjectId, ref: 'Floor', required: true, index: true },
    floorNumber: { type: Number, required: true },
    type: { type: String, enum: Object.values(ROOM_TYPES), default: ROOM_TYPES.CLASSROOM },
    capacity: { type: Number, default: 60 },
    hasProjector: { type: Boolean, default: false },
    hasAC: { type: Boolean, default: false },
    // Base status; occupancy is computed live from timetable/bookings.
    status: { type: String, enum: Object.values(ROOM_STATUS), default: ROOM_STATUS.FREE },
    liveStatus: {
      status: { type: String, enum: Object.values(ROOM_STATUS), default: ROOM_STATUS.FREE },
      subject: String,
      faculty: String,
      section: String,
      strength: Number,
      updatedAt: Date,
    },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

roomSchema.index({ building: 1, floorNumber: 1, roomNumber: 1 }, { unique: true });
roomSchema.index({ type: 1, status: 1 });

module.exports = mongoose.model('Room', roomSchema);
