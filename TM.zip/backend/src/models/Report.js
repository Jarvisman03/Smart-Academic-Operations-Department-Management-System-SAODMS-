const mongoose = require('mongoose');

// Record of a generated report (for history / re-download).
const reportSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    type: {
      type: String,
      enum: ['attendance', 'faculty', 'department', 'room_usage', 'lab_usage', 'student', 'workload', 'meeting', 'assignment'],
      required: true,
    },
    format: { type: String, enum: ['pdf', 'excel', 'csv'], required: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    generatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    filters: mongoose.Schema.Types.Mixed,
    url: String, // Cloudinary/local path if persisted
    rowCount: Number,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Report', reportSchema);
