const mongoose = require('mongoose');
const { LEAVE_STATUS } = require('../config/constants');

const leaveSchema = new mongoose.Schema(
  {
    applicant: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty' },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    type: { type: String, enum: ['casual', 'medical', 'earned', 'duty', 'other'], default: 'casual' },
    fromDate: { type: Date, required: true },
    toDate: { type: Date, required: true },
    days: { type: Number, default: 1 },
    reason: { type: String, required: true },
    status: { type: String, enum: Object.values(LEAVE_STATUS), default: LEAVE_STATUS.PENDING, index: true },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    approverRemarks: String,
    // If approved, classes in this window may need substitutes.
    affectedClasses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Timetable' }],
    attachment: String,
  },
  { timestamps: true }
);

leaveSchema.index({ department: 1, status: 1, fromDate: 1 });

module.exports = mongoose.model('Leave', leaveSchema);
