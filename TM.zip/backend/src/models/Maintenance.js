const mongoose = require('mongoose');

const maintenanceSchema = new mongoose.Schema(
  {
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', index: true },
    lab: { type: mongoose.Schema.Types.ObjectId, ref: 'Lab' },
    equipment: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment' },
    title: { type: String, required: true },
    description: String,
    reportedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },
    status: { type: String, enum: ['open', 'in_progress', 'resolved', 'closed'], default: 'open', index: true },
    scheduledDate: Date,
    resolvedDate: Date,
    cost: Number,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Maintenance', maintenanceSchema);
