const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    code: { type: String, required: true, unique: true, uppercase: true, trim: true },
    hod: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // supports 2 HODs
    coHod: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    dean: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    building: { type: mongoose.Schema.Types.ObjectId, ref: 'Building' },
    establishedYear: Number,
    description: String,
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Department', departmentSchema);
