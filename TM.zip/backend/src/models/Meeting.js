const mongoose = require('mongoose');

const meetingSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    agenda: String,
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    organizer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    attendees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    date: { type: Date, required: true, index: true },
    startTime: String,
    endTime: String,
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
    mode: { type: String, enum: ['offline', 'online', 'hybrid'], default: 'offline' },
    meetingLink: String,
    status: { type: String, enum: ['scheduled', 'ongoing', 'completed', 'cancelled'], default: 'scheduled' },
    minutes: String, // minutes of meeting
    attachments: [{ name: String, url: String }],
  },
  { timestamps: true }
);

meetingSchema.index({ date: 1, department: 1 });

module.exports = mongoose.model('Meeting', meetingSchema);
