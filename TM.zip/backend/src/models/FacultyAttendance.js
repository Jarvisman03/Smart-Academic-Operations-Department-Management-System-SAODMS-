const mongoose = require('mongoose');
const { ATTENDANCE_METHODS } = require('../config/constants');

// Faculty daily attendance (check-in / check-out). Saturday is a
// working day for faculty; Sunday is a holiday.
const facultyAttendanceSchema = new mongoose.Schema(
  {
    faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty', required: true, index: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    date: { type: Date, required: true, index: true },
    checkIn: Date,
    checkOut: Date,
    status: { type: String, enum: ['present', 'absent', 'late', 'half_day', 'on_leave'], default: 'absent' },
    method: { type: String, enum: Object.values(ATTENDANCE_METHODS), default: ATTENDANCE_METHODS.MANUAL },
    lateByMinutes: { type: Number, default: 0 },
    workedMinutes: { type: Number, default: 0 },
    location: { lat: Number, lng: Number },
    notes: String,
  },
  { timestamps: true }
);

facultyAttendanceSchema.index({ faculty: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('FacultyAttendance', facultyAttendanceSchema);
