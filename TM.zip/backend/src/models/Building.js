const mongoose = require('mongoose');

const buildingSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    code: { type: String, required: true, unique: true, uppercase: true, trim: true },
    totalFloors: { type: Number, default: 4 },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    description: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Building', buildingSchema);
