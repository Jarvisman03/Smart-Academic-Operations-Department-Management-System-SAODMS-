const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const env = require('../config/env');
const { ROLES } = require('../config/constants');

// ============================================================
// User - base account for every person in the system.
// Faculty/Student carry extended profile in their own collections
// linked via `user`.
// ============================================================
const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Name is required'], trim: true, maxlength: 120 },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Invalid email'],
    },
    password: { type: String, required: true, minlength: 6, select: false },
    role: {
      type: String,
      enum: Object.values(ROLES),
      required: true,
      index: true,
    },
    phone: { type: String, trim: true },
    avatar: { type: String, default: '' },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', index: true },
    isActive: { type: Boolean, default: true },
    lastLogin: { type: Date },
    // Face-recognition enrollment: a 128-float descriptor computed client-side
    // (face-api.js). Never send it on normal reads; load explicitly when matching.
    faceDescriptor: { type: [Number], select: false, default: undefined },
    faceEnrolledAt: { type: Date },
    // Hashed refresh tokens for session management (rotation + revocation).
    refreshTokens: [{ token: String, createdAt: { type: Date, default: Date.now } }],
    // Optional device token for FCM push.
    fcmToken: { type: String, default: '' },
  },
  { timestamps: true }
);

userSchema.index({ role: 1, department: 1 });
userSchema.index({ name: 'text', email: 'text' });

userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, env.bcryptSaltRounds);
  return next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toSafeJSON = function toSafeJSON() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.refreshTokens;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
